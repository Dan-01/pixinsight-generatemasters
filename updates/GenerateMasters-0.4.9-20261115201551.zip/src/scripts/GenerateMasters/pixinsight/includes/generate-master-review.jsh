function gmMasterReviewDialog(result, operator) {
   var review = JSON.parse(File.readTextFile(result.masterReviewPath));
   if (review.groups.length !== result.groups)
      throw new Error("Master review group count changed");
   var dialog = daUiDialog();
   dialog.windowTitle = "GenerateMasters — master acceptance";
   var heading = new Label(dialog); heading.wordWrapping = true;
   heading.text = review.groups.length + " master group(s) are ready for full-size inspection. " +
      result.registrationFlags + " registered frame(s) have review flags; " +
      review.failedRegistrations.length + " failed registration.";
   var table = new TreeBox(dialog);
   table.numberOfColumns = 7; table.headerVisible = true;
   table.rootDecoration = false; table.alternateRowColor = true;
   var headers = ["Group", "Frames", "Rejected low", "Rejected high", "Noise", "Ref. reduction", "Policy"];
   for (var h = 0; h < headers.length; ++h) table.setHeaderText(h, headers[h]);
   for (var i = 0; i < review.groups.length; ++i) {
      var group = review.groups[i], node = new TreeBoxNode(table);
      var stats = group.statistics;
      var cells = [group.key, String(group.sourceFrames.length),
         String(stats.totalRejectedLow), String(stats.totalRejectedHigh),
         String(stats.finalNoiseEstimate), String(stats.referenceNoiseReduction),
         group.policy.normalization + "/" + group.policy.weighting + "/" + group.policy.rejection];
      for (var c = 0; c < cells.length; ++c) node.setText(c, cells[c]);
      node.setToolTip(0, group.master.path + "\n" + group.rejectionLow.path +
         "\n" + group.rejectionHigh.path);
   }
   for (var column = 0; column < headers.length; ++column)
      table.setColumnWidth(column, daUiLabelWidth(table, [headers[column]], column === 6 ? 240 : 115));
   table.setFixedWidth(daUiPixels(dialog, 1000)); table.setFixedHeight(daUiPixels(dialog, 210));
   var registration = new TreeBox(dialog);
   registration.numberOfColumns = 2; registration.headerVisible = true;
   registration.rootDecoration = false; registration.alternateRowColor = true;
   registration.setHeaderText(0, "Registration frame");
   registration.setHeaderText(1, "Review issue");
   var issueCount = 0;
   for (var r = 0; r < review.registrationReview.length; ++r) {
      var frame = review.registrationReview[r];
      if (!frame.flags.length) continue;
      ++issueCount;
      var issue = new TreeBoxNode(registration);
      issue.setText(0, File.extractName(frame.sourcePath));
      issue.setText(1, frame.flags.join(", "));
      issue.setToolTip(0, frame.sourcePath);
   }
   for (var f = 0; f < review.failedRegistrations.length; ++f) {
      ++issueCount;
      var failed = review.failedRegistrations[f], failure = new TreeBoxNode(registration);
      failure.setText(0, File.extractName(failed.path));
      failure.setText(1, "Registration failed; excluded from integration");
      failure.setToolTip(0, failed.path);
   }
   if (!issueCount) {
      var clear = new TreeBoxNode(registration);
      clear.setText(0, "All registered frames");
      clear.setText(1, "No review flags");
   }
   registration.setColumnWidth(0, daUiPixels(dialog, 470));
   registration.setColumnWidth(1, daUiPixels(dialog, 480));
   registration.setFixedWidth(daUiPixels(dialog, 1000)); registration.setFixedHeight(daUiPixels(dialog, 105));
   var chooser = new ComboBox(dialog);
   daUiHelp(chooser, "Master group to inspect", "Select the integrated filter/exposure group and its low/high rejection maps.", "Inspect all groups. Rejection should remove defects rather than coherent galaxy, nebular or crowded cluster structure.");
   for (var g = 0; g < review.groups.length; ++g) chooser.addItem(review.groups[g].key);
   var paths = new Label(dialog); paths.useRichText = false; paths.wordWrapping = true;
   function show(index) {
      var group = review.groups[index];
      paths.text = "Master: " + group.master.path + "\nLow rejection: " +
         group.rejectionLow.path + "\nHigh rejection: " + group.rejectionHigh.path;
      if (group.conventionalMaster) paths.text += "\nNormal comparison: " + group.conventionalMaster.path +
         "\nDrizzle coverage: " + group.drizzleWeight.path;
   }
   chooser.onItemSelected = show; show(0);
   var inspect = new PushButton(dialog); inspect.text = "Open selected master and maps";
   inspect.onClick = function() {
      var group = review.groups[chooser.currentItem];
      var images = [group.master.path, group.rejectionLow.path, group.rejectionHigh.path];
      if (group.conventionalMaster) images.push(group.conventionalMaster.path, group.drizzleWeight.path);
      for (var path of images) {
         var windows = ImageWindow.open(path);
         if (windows.length !== 1) throw new Error("Could not open review image " + path);
      }
   };
   var rationale = new Edit(dialog); rationale.minWidth = 700;
   var draftPath = result.masterReviewPath + ".draft.json";
   if (File.exists(draftPath)) {
      var draft = JSON.parse(File.readTextFile(draftPath));
      if (draft.reviewChecksum !== result.masterReviewChecksum)
         throw new Error("Saved master acceptance differs from these integrated masters");
      if (draft.acceptancePath) return draft.acceptancePath;
      rationale.text = draft.note || "";
   }
   function saveDraft(path) {
      File.writeTextFile(draftPath, JSON.stringify({ reviewChecksum: result.masterReviewChecksum,
         note: rationale.text, acceptancePath: path || null }, null, 2) + "\n");
   }
   daUiHelp(rationale, "Master inspection notes (optional)", "Optional notes about the masters, rejection maps and registration flags. Clicking Accept and save masters records your approval; no minimum note length is required.", "Check cores and faint outskirts for galaxies/nebulae, and crowded stars for clusters; describe the checks rather than only writing that it looks good.");
   var status = daUiNotice(dialog, "Inspect every group at full size, including both rejection maps and flagged registrations.", "info", "Review before saving");
   var acceptancePath = null;
   var accept = new PushButton(dialog); daUiEmphasis(accept, "primary"); accept.text = "Accept and save masters";
   daUiHelp(accept, accept.text, "Accept these integrated masters and save them to the final masters folder, then open the Process workspace. Inspection notes are optional. Your approval is saved for resuming if publication fails.", "Inspect each filter's master and rejection maps before accepting. Clicking this button explicitly approves this exact set.");
   accept.onClick = function() {
      try {
      accept.enabled = false; daUiSetNotice(status, "info", "Saving your acceptance and publishing masters…", "Saving masters");
      var note = rationale.text.trim();
      var approval = "Operator explicitly accepted the integrated masters for publication using Accept and save masters.";
      var stamp = (new Date().toISOString()).replace(/[^0-9]/g, "");
      acceptancePath = result.masterReviewPath.replace(/\.master-review\.json$/,
         ".master-acceptance-" + stamp + ".json");
      if (File.exists(acceptancePath)) throw new Error("Acceptance file already exists");
      File.writeTextFile(acceptancePath, JSON.stringify({ version: 1,
         kind: "one-run-master-acceptance", fingerprint: review.fingerprint,
         reviewChecksum: result.masterReviewChecksum, operator: operator,
         decision: "ACCEPT", rationale: approval + (note ? " Inspection notes: " + note : "") }, null, 2) + "\n");
      saveDraft(acceptancePath);
      dialog.ok();
      } catch (error) {
         acceptancePath = null; accept.enabled = true; daUiSetNotice(status, "error", String(error), "Masters could not be saved");
         console.criticalln("Save masters: " + String(error));
         new MessageBox("Could not save your master acceptance.\n\n" + String(error),
            "GenerateMasters — save masters", StdIcon_Error, StdButton_Ok).execute();
      }
   };
   var pause = new PushButton(dialog); pause.text = "Pause for inspection or revision";
   pause.onClick = function() { saveDraft(); dialog.cancel(); };
   var buttons = new HorizontalSizer; buttons.add(inspect); buttons.addStretch();
   buttons.add(pause); buttons.add(accept);
   var layout = new VerticalSizer; layout.margin = 12; layout.spacing = 8;
   layout.add(daUiHeader(dialog, "GenerateMasters", "Master acceptance"));
   layout.add(heading); layout.add(table); layout.add(registration);
   if (result.drizzleRecommendations) layout.add(daUiNotice(dialog,
      gmDrizzleRecommendationText(result.drizzleRecommendations) +
      "\nScreening heuristics only. Compare detail, stars, noise and coverage at the same image scale. Rejection maps use the normal resolution.", "info", "Drizzle assessment"));
   var decisionGroup = daUiGroup(dialog, "Inspect and accept");
   decisionGroup.sizer.add(chooser);
   decisionGroup.sizer.add(paths);
   decisionGroup.sizer.add(daUiText(dialog, "Inspection notes (optional)"));
   decisionGroup.sizer.add(rationale);
   layout.add(decisionGroup);
   layout.add(status); layout.add(daUiRule(dialog)); layout.add(buttons);
   dialog.sizer = layout; dialog.adjustToContents(); dialog.execute();
   return acceptancePath;
}
