var gmPendingBlink = null;

function gmLaunchPendingBlink() {
   if (!gmPendingBlink) return;
   var request = gmPendingBlink; gmPendingBlink = null;
   console.noteln("Blink review folder: " + request.directory);
   if (request.rebuiltMissingSet)
      console.noteln("The previous review folder was removed. Prepared " + request.frames + " fresh review copies from verified calibration files.");
   console.noteln("Add the XISF files from this folder to Blink. Move unwanted copies into its Rejected subfolder. When inspection is finished, reopen DanAstroPhoto, Generate masters, then Generate / resume masters to apply the saved choices and continue.");
   var command = File.fullPath(gmScriptDirectory + "includes/open-blink.scp");
   if (!ExternalProcess.startDetached(CoreApplication.filePath,
       ["--execute=" + CoreApplication.instance + ":" + command]))
      throw new Error("Could not send the native Blink launch command");
   if (File.exists("/usr/bin/open")) ExternalProcess.startDetached("/usr/bin/open", [request.directory]);
   else if (File.exists("/usr/bin/xdg-open")) ExternalProcess.startDetached("/usr/bin/xdg-open", [request.directory]);
}

function gmBlinkAction(action, result, filter, note, confirmed, node, operator) {
   var helper = File.fullPath(gmScriptDirectory + "../scripts/one-run/blink-review.mjs");
   var process = new ExternalProcess;
   var args = [helper, action, result.qualityReviewPath, result.qualityReviewChecksum,
      filter, note || "", confirmed ? "true" : "false"];
   if (operator) args.push(operator);
   process.start(node, args);
   if (!process.waitForStarted(10000)) throw new Error("Could not start Blink review preparation");
   var output = "";
   while (!process.waitForFinished(250)) {
      output += process.outputData.toString();
      CoreApplication.processEvents();
   }
   output += process.outputData.toString();
   if (process.exitCode !== 0 || process.exitStatus !== 0)
      throw new Error(output.trim() || "Blink review helper stopped (exit " + process.exitCode +
         ", status " + process.exitStatus + "). Your review files and decisions are preserved.");
   try { return JSON.parse(output); }
   catch (error) { throw new Error("Blink review returned an invalid response: " + output.trim()); }
}

function gmQualityFlagsText(flags) {
   var explanations = {
      FWHM_HIGH_RELATIVE_TO_STACK: "Stars are over 1.5 times broader than the filter/exposure group median; inspect focus, seeing and trailing.",
      ECCENTRICITY_HIGH: "Star eccentricity exceeds 0.7; inspect elongated stars and tracking.",
      SNR_LOW_RELATIVE_TO_STACK: "SNR measure is below half the group median; inspect clouds and lost faint signal.",
      NOISE_HIGH_RELATIVE_TO_STACK: "Noise exceeds 1.5 times the group median; inspect background and gradients.",
      STAR_COUNT_LOW_RELATIVE_TO_STACK: "Detected stars are below half the group median; inspect clouds, focus and star detection."
   };
   return flags.map(function(flag) {
      return flag === "PSF_SIGNAL_WEIGHT_UNAVAILABLE" ?
         "PSF signal weight unavailable: inspect stars and background for clouds or poor signal. Other measurements are valid; this is not an automatic rejection." : (explanations[flag] || flag);
   }).join(", ");
}

function gmDecisionFileButton(dialog, edit, caption) {
   var button = new PushButton(dialog); button.text = "Browse";
   button.onClick = function() {
      var picker = new OpenFileDialog;
      picker.caption = caption || "Select saved quality decisions";
      picker.filters = [["JSON files", "*.json"]];
      if (picker.execute()) edit.text = picker.filePath;
   };
   return button;
}

function gmQualityReviewDialog(result, operator, nodePath, setupHost) {
   var review = JSON.parse(File.readTextFile(result.qualityReviewPath));
   var pending = review.frames.filter(function(frame) { return frame.needsDecision; });
   if (pending.length !== result.pendingFrames)
      throw new Error("Quality review frame count changed");
   var dialog = daUiBase(new Dialog);
   dialog.windowTitle = "GenerateMasters — measured frame review";
   var heading = new Label(dialog);
   var flaggedCount = pending.filter(function(frame) { return frame.flags.length > 0; }).length;
   heading.text = pending.length + " review frames: " + flaggedCount +
      " flagged by measurements, " + (pending.length - flaggedCount) + " without measurement flags.";
   var table = new TreeBox(dialog);
   table.numberOfColumns = 9; table.headerVisible = true;
   table.rootDecoration = false; table.alternateRowColor = true;
   var headers = ["Filter", "Frame", "FWHM", "Ecc.", "SNR", "Noise", "Stars", "Decision", "Measurements"];
   for (var h = 0; h < headers.length; ++h) table.setHeaderText(h, headers[h]);
   var nodes = [];
   for (var i = 0; i < pending.length; ++i) {
      var frame = pending[i], node = new TreeBoxNode(table);
      var cells = [frame.filter, File.extractName(frame.sourcePath),
         frame.metrics.fwhm.toFixed(2), frame.metrics.eccentricity.toFixed(3),
         frame.metrics.snrWeightMetric.toFixed(2), frame.metrics.noise.toFixed(4),
         String(frame.metrics.stars), "Review", frame.flags.length ? "Inspect — " + frame.flags.length + " cue(s)" : "No flags"];
      for (var c = 0; c < cells.length; ++c) node.setText(c, cells[c]);
      node.setToolTip(1, frame.sourcePath + "\nSHA-256 " + frame.sourceChecksum);
      node.setToolTip(7, frame.flags.length ? gmQualityFlagsText(frame.flags) :
         "Passes measured quality checks. Flagged-only Blink review includes this frame when applied; inspect the whole stack when conditions varied.");
      node.setToolTip(8, node.toolTip(7));
      nodes.push(node);
   }
   table.setFixedWidth(1000); table.setFixedHeight(240);
   var chooser = new ComboBox(dialog);
   daUiHelp(chooser, "Frame to review", "Select an individual calibrated frame to inspect and classify.", "Inspect stars, background and target signal at full size; compare measurements within the same filter/exposure group.");
   for (var f = 0; f < pending.length; ++f)
      chooser.addItem((f + 1) + ". " + pending[f].filter + " — " +
         File.extractName(pending[f].sourcePath));
   var detail = new Label(dialog), rationale = new Edit(dialog);
   rationale.minWidth = 600;
   var classification = new ComboBox(dialog);
   var classes = ["ACCEPT", "SUSPECT", "REJECT"];
   for (var name of ["Accept — include this frame", "Suspect — leave out for now", "Reject — exclude this frame"]) classification.addItem(name);
   daUiHelp(classification, "Frame decision", "Accept includes this frame; Suspect leaves it out for now; Reject excludes it. Each decision needs its own inspection note.", "Check trailing, clouds and gradients, plus galaxy outskirts, faint nebulae or cluster star profiles. A metric flag is a review cue, not an automatic rejection.");
   daUiHelp(rationale, "Frame inspection notes", "Required specific reason of at least 12 characters, saved with this frame decision.", "Record what you observed, such as round stars, cloud gradients or retained faint signal. Explain exclusions so a later review can reproduce the choice.");
   var decisions = {}, status = daUiNotice(dialog, "", "info");
   var savedBlinkFilter = flaggedCount ? "FLAGGED" : "ALL", savedBlinkNote = "";
   var blinkResume = null, finalDecisionPath = null, resumeError = "";
   status.wordWrapping = true;
   var draftPath = result.qualityReviewPath + ".draft.json";
   if (File.exists(draftPath)) {
      var draft = JSON.parse(File.readTextFile(draftPath));
      if (draft.reviewChecksum !== result.qualityReviewChecksum)
         throw new Error("Saved frame-review draft differs from this measured run");
      savedBlinkFilter = draft.blinkFilter || savedBlinkFilter;
      blinkResume = draft.blinkResume || null; finalDecisionPath = draft.finalDecisionPath || null; savedBlinkNote = draft.blinkNote || "";
      for (var item of draft.decisions || [])
         if (pending.some(function(frame) { return frame.sourceChecksum === item.sourceChecksum; }) &&
             classes.indexOf(item.classification) >= 0 && typeof item.rationale === "string" && item.rationale.trim().length >= 12)
            decisions[item.sourceChecksum] = item;
   }
   var resume = null;
   if (File.exists(draftPath)) {
      try {
         resume = gmBlinkAction("resume", result, savedBlinkFilter, "", false, nodePath);
         if (resume.state === "COMPLETED") return resume.decisionPath;
      } catch (error) { resumeError = String(error); }
   }
   var awaitingBlink = resume && resume.state === "AWAITING_BLINK";
   if (awaitingBlink) {
      dialog.windowTitle = "GenerateMasters — resume Blink review";
      heading.text = "Resume saved Blink review: " + resume.accepted + " retained, " + resume.rejected +
         " removed / excluded. " + resume.measurementAccepted + " other frames pass measured quality checks.\n" +
         "Apply Blink choices to include retained copies and the frames that pass measurements, then continue processing.";
   } else heading.text += "\nAccept measured recommendations to continue now, or inspect frames in Blink / Individual frames.";
   function saveDraft() {
      File.writeTextFile(draftPath, JSON.stringify({ reviewChecksum: result.qualityReviewChecksum,
         blinkFilter: blinkFilter ? blinkFilters[blinkFilter.currentItem] : savedBlinkFilter,
         blinkNote: blinkNote ? blinkNote.text : savedBlinkNote,
         blinkResume: blinkResume, finalDecisionPath: finalDecisionPath,
         decisions: Object.keys(decisions).map(function(key) { return decisions[key]; }) }, null, 2));
   }
   function show(index) {
      var frame = pending[index];
      detail.text = frame.sourcePath + "\n" +
         (frame.flags.length ? "Review cues: " + gmQualityFlagsText(frame.flags) :
            "No relative metric flag") +
         (frame.priorApproval ? " — previous approval exists" : " — new frame");
      rationale.text = decisions[frame.sourceChecksum] ?
         decisions[frame.sourceChecksum].rationale : "";
      classification.currentItem = decisions[frame.sourceChecksum] ?
         classes.indexOf(decisions[frame.sourceChecksum].classification) : 0;
   }
   chooser.onItemSelected = show;
   show(0);
   var inspect = new PushButton(dialog); inspect.text = "Open selected calibrated frame";
   inspect.onClick = function() {
      var path = pending[chooser.currentItem].metrics.filePath;
      if (!File.exists(path)) throw new Error("Calibrated review frame is missing: " + path);
      var windows = ImageWindow.open(path);
      if (windows.length !== 1) throw new Error("Could not open review frame: " + path);
   };
   var save = new PushButton(dialog); save.text = "Save this frame decision";
   var finish = new PushButton(dialog); daUiEmphasis(finish, "primary"); finish.text = "Continue processing";
   function insufficientGroups() {
      var counts = {};
      for (var frame of review.frames) {
         var key = frame.filter + " " + frame.exposureSeconds + "s";
         if (counts[key] === undefined) counts[key] = 0;
         var decision = decisions[frame.sourceChecksum];
         if ((decision && decision.classification === "ACCEPT") ||
             (!frame.needsDecision && frame.priorApproval)) ++counts[key];
      }
      return Object.keys(counts).filter(function(key) { return counts[key] < 3; }).map(function(key) {
         return key + ": " + counts[key] + " accepted";
      });
   }
   function refreshDecisions() {
      for (var index = 0; index < pending.length; ++index)
         nodes[index].setText(7, decisions[pending[index].sourceChecksum] ? decisions[pending[index].sourceChecksum].classification : "Review");
      var count = Object.keys(decisions).length;
      status.text = count + " of " + pending.length + " decisions recorded.";
      var insufficient = insufficientGroups();
      var useBlink = awaitingBlink && (!reviewModes || reviewModes.currentPageIndex === 0);
      finish.text = useBlink ? "Apply Blink choices and continue" : "Continue processing";
      finish.enabled = useBlink || (count === pending.length && insufficient.length === 0);
      if (useBlink) status.text = "Saved Blink group: " + resume.filter + ". " + resume.accepted + " retained, " + resume.rejected + " removed; " + resume.measurementAccepted + " pass measurements. Click Apply when your Blink review is finished.";
      if (resumeError) status.text += " " + resumeError;
      if (count === pending.length && insufficient.length)
         status.text += " At least 3 accepted frames per filter/exposure are needed. " + insufficient.join("; ") +
            ". Use Individual frames to amend decisions, or restore review copies you moved unintentionally and import again.";
      daUiSetNotice(status, resumeError || (count === pending.length && insufficient.length) ? "warning" : useBlink ? "info" : finish.enabled ? "success" : "info", status.text, useBlink ? "Resume Blink review" : "Frame decisions");
   }
   refreshDecisions();
   save.onClick = function() {
      var index = chooser.currentItem, frame = pending[index];
      if (rationale.text.trim().length < 12) {
         daUiSetNotice(status, "warning", "Give a specific reason of at least 12 characters for this frame.", "Add an inspection note");
         return;
      }
      decisions[frame.sourceChecksum] = { sourceChecksum: frame.sourceChecksum,
         classification: classes[classification.currentItem],
         rationale: rationale.text.trim() };
      saveDraft(); refreshDecisions();
      var count = Object.keys(decisions).length;
      if (count < pending.length)
         for (var next = 0; next < pending.length; ++next)
            if (!decisions[pending[next].sourceChecksum]) {
               chooser.currentItem = next; show(next); break;
            }
   };
   var decisionPath = null;
   function finishCompletedReview(completed) {
      var completedDraft = JSON.parse(File.readTextFile(draftPath));
      finalDecisionPath = completedDraft.finalDecisionPath; blinkResume = completedDraft.blinkResume || null;
      for (var item of completedDraft.decisions) decisions[item.sourceChecksum] = item;
      decisionPath = completed.decisionPath;
      dialog.ok();
   }
   var recommend = new PushButton(dialog); recommend.text = "Accept recommendations and continue";
   daUiHelp(recommend, recommend.text, "Include frames that pass measured quality checks and exclude quality outliers, then immediately continue registration and integration. No manual inspection or notes are required. Existing individual decisions and copies removed from Blink are preserved.", "Missing PSF weight alone does not exclude a frame. At least three accepted frames per filter/exposure are required. Decisions record that measured recommendations were used; they do not claim visual inspection.");
   recommend.onClick = function() {
      try {
         recommend.enabled = false; finish.enabled = false;
         saveDraft();
         finishCompletedReview(gmBlinkAction("recommend", result, "ALL", "", true, nodePath, operator));
      } catch (error) {
         recommend.enabled = true; refreshDecisions();
         daUiSetNotice(status, "error", String(error), "Could not apply recommendations");
         new MessageBox(String(error), "GenerateMasters — accept recommendations", StdIcon_Error, StdButton_Ok).execute();
      }
   };
   daUiHelp(finish, "Apply review and continue", "Apply the saved Blink set: retained copies are included and copies moved out or deleted are excluded. In flagged-only review, undecided frames without measurement flags are included by measured quality checks. Save the complete decision and immediately resume registration and integration.", "Finish moving unwanted copies before clicking. At least three accepted frames per filter/exposure are required. Decisions survive closing the launcher and native processing failures.");
   finish.onClick = function() {
      if (awaitingBlink && (!reviewModes || reviewModes.currentPageIndex === 0)) {
         try {
            finish.enabled = false;
            finishCompletedReview(gmBlinkAction("complete", result, resume.filter,
               blinkNote.text, true, nodePath, operator));
         } catch (error) {
            daUiSetNotice(status, "error", String(error), "Blink action failed"); finish.enabled = true;
            new MessageBox(String(error), "GenerateMasters — finish Blink review", StdIcon_Error, StdButton_Ok).execute();
         }
         return;
      }
      if (Object.keys(decisions).length !== pending.length || insufficientGroups().length) return;
      var stamp = (new Date().toISOString()).replace(/[^0-9]/g, "");
      decisionPath = result.qualityReviewPath.replace(/\.quality-review\.json$/,
         ".quality-decisions-" + stamp + ".json");
      if (File.exists(decisionPath)) throw new Error("Decision file already exists");
      File.writeTextFile(decisionPath, JSON.stringify({ version: 1,
         kind: "one-run-quality-decisions", fingerprint: review.fingerprint,
         reviewChecksum: result.qualityReviewChecksum, operator: operator,
         decisions: pending.map(function(frame) {
            return decisions[frame.sourceChecksum];
         }) }, null, 2) + "\n");
      finalDecisionPath = decisionPath; saveDraft();
      dialog.ok();
   };
   var pause = new PushButton(dialog); pause.text = "Pause";
   pause.onClick = function() { saveDraft(); dialog.cancel(); };
   var blinkGroup = daUiGroup(dialog, "Blink review");
   var blinkFilter = new ComboBox(dialog), blinkFilters = ["ALL"];
   blinkFilter.addItem("All pending frames");
   if (flaggedCount) {
      blinkFilters.push("FLAGGED"); blinkFilter.addItem("Measurement-flagged frames only (" + flaggedCount + ")");
   }
   for (var frame of pending) if (blinkFilters.indexOf(frame.filter) < 0) {
      blinkFilters.push(frame.filter); blinkFilter.addItem(frame.filter + " frames");
   }
   blinkFilter.currentItem = Math.max(0, blinkFilters.indexOf(savedBlinkFilter));
   daUiHelp(blinkFilter, "Blink frame group", "Choose flagged frames for the recommended review, all frames for visual inspection of the whole stack, or one filter for advanced review. The saved Blink set is remembered when you return.", "Flagged-only review includes undecided frames without measurement flags when you apply Blink choices. Compare one filter at a time for cloud transparency and background changes; use all frames for a whole-stack inspection when conditions varied.");
   var blink = new PushButton(dialog); blink.text = "Open review set in Blink";
   daUiHelp(blink, blink.text, "Create separate calibrated review copies and open native Blink plus their folder. Add the XISF files from that folder to Blink. The workflow pauses so Blink can be used.", "Use Blink's Move selected files action to put unwanted copies in the Rejected subfolder, or delete those copies in your file manager. Closing a row in Blink alone does not reject it. Original FITS and verified calibration files are preserved.");
   var acceptUnflagged = new PushButton(dialog); acceptUnflagged.text = "Accept frames without measurement flags";
   daUiHelp(acceptUnflagged, acceptUnflagged.text, "Accept undecided frames with no FWHM, eccentricity, SNR, noise, star-count or missing-PSF flag. Leave flagged frames for inspection and preserve existing decisions.", "Useful for large captures. Measurements cannot detect every cloud, gradient or artifact; use Blink to check the whole stack when conditions varied. Explicit Blink rejections take precedence.");
   acceptUnflagged.onClick = function() {
      for (var frame of pending) if (!frame.flags.length && !decisions[frame.sourceChecksum])
         decisions[frame.sourceChecksum] = { sourceChecksum: frame.sourceChecksum, classification: "ACCEPT",
            rationale: "Accepted by operator using measured quality checks: no FWHM, eccentricity, SNR, noise, star-count or PSF availability flags." };
      saveDraft(); refreshDecisions(); show(chooser.currentItem);
   };
   var blinkNote = new Edit(dialog);
   blinkNote.text = savedBlinkNote;
   blinkNote.minWidth = 600;
   daUiHelp(blinkNote, "Blink inspection notes (optional)", "Optional note saved with the imported decisions. Leaving it blank records that the decisions came from retained and removed Blink review copies.", "Add details about clouds, trailing or background differences when useful. For galaxies and reflection nebulae inspect faint outer signal; for clusters inspect star profiles.");
   var importBlink = new PushButton(dialog); importBlink.text = "Import selected group (advanced)";
   daUiHelp(importBlink, importBlink.text, "Click after reviewing in Blink: accept remaining review copies and reject copies moved out or deleted. Notes are optional. Existing decisions in this group are replaced by the current Blink set.", "Advanced individual-frame action: choose the prepared group to import. For the usual workflow, use Apply Blink choices and continue. Moving every copy rejects the entire group; at least 3 accepted frames per filter/exposure are needed to continue. Individual decisions can be amended. Original files are preserved.");
   blink.onClick = function() {
      try {
         if (typeof Blink === "undefined") throw new Error("PixInsight Blink is not installed");
         blink.enabled = false; daUiSetNotice(status, "info", "Preparing calibrated Blink review copies…", "Opening Blink");
         var set = gmBlinkAction("prepare", result, blinkFilters[blinkFilter.currentItem], "", false, nodePath);
         blinkResume = { state: "AWAITING_BLINK", filter: set.filter,
            manifestPath: set.manifestPath, manifestChecksum: set.manifestChecksum };
         finalDecisionPath = null;
         saveDraft(); gmPendingBlink = set;
         dialog.cancel();
         if (setupHost) setupHost.cancel();
      } catch (error) {
         daUiSetNotice(status, "error", String(error), "Blink action failed"); blink.enabled = true;
         console.criticalln("Open in Blink: " + String(error));
         new MessageBox("Could not open the Blink review set.\n\n" + String(error),
            "GenerateMasters — Blink review", StdIcon_Error, StdButton_Ok).execute();
      }
   };
   importBlink.onClick = function() {
      try {
         importBlink.enabled = false; blink.enabled = false;
         daUiSetNotice(status, "info", "Importing retained and removed Blink review copies…", "Importing review");
         var note = blinkNote.text.trim();
         if (note.length < 12) note = "Imported from Blink review copies; retained files included and moved or deleted files excluded." + (note ? " " + note : "");
         var imported = gmBlinkAction("import", result, blinkFilters[blinkFilter.currentItem], note, true, nodePath);
         for (var decision of imported.decisions) decisions[decision.sourceChecksum] = decision;
         saveDraft(); refreshDecisions(); show(chooser.currentItem);
         status.text += " Blink group: " + imported.accepted + " accepted, " + imported.rejected + " rejected.";
      } catch (error) { daUiSetNotice(status, "error", String(error), "Blink action failed"); console.criticalln("Blink import: " + String(error)); }
      finally { importBlink.enabled = true; blink.enabled = true; }
   };
   blinkGroup.sizer.add(blinkFilter); blinkGroup.sizer.add(blink);
   blinkGroup.sizer.add(daUiText(dialog, "In Blink: move unwanted copies into Rejected. When finished, reopen Generate masters and click Generate / resume masters. The saved choices are applied automatically and processing continues."));
   blinkGroup.sizer.add(daUiText(dialog, "Blink inspection notes (optional)")); blinkGroup.sizer.add(blinkNote);

   var buttons = new HorizontalSizer; buttons.add(inspect); buttons.addStretch();
   buttons.add(save); buttons.add(pause); buttons.add(finish);
   var layout = new VerticalSizer; layout.margin = 12; layout.spacing = 8;
   layout.add(daUiHeader(dialog, "GenerateMasters", "Measured frame review"));
   layout.add(heading); layout.add(table);
   if (result.drizzleRecommendations) layout.add(daUiNotice(dialog,
      gmDrizzleRecommendationText(result.drizzleRecommendations) +
      "\nThis is an advisory assessment. Subpixel coverage is checked after registration on drizzle runs.", "info", "Drizzle sampling"));
   var decisionGroup = daUiGroup(dialog, "Individual frame decision");
   decisionGroup.sizer.add(acceptUnflagged); decisionGroup.sizer.add(importBlink);
   decisionGroup.sizer.add(chooser);
   decisionGroup.sizer.add(detail);
   decisionGroup.sizer.add(daUiText(dialog, "Frame decision"));
   decisionGroup.sizer.add(classification);
   decisionGroup.sizer.add(daUiText(dialog, "Inspection notes — required for each frame"));
   decisionGroup.sizer.add(rationale);
   var reviewModes = new TabBox(dialog), blinkPage = new Control(reviewModes), individualPage = new Control(reviewModes);
   blinkPage.sizer = new VerticalSizer; blinkPage.sizer.add(blinkGroup);
   individualPage.sizer = new VerticalSizer; individualPage.sizer.add(decisionGroup);
   reviewModes.addPage(blinkPage, "Blink review"); reviewModes.addPage(individualPage, "Individual frames");
   reviewModes.onPageSelected = function(index) { inspect.visible = index === 1; save.visible = index === 1; refreshDecisions(); };
   inspect.visible = false; save.visible = false;
   layout.add(recommend);
   layout.add(daUiText(dialog, "Include frames that pass quality checks; exclude measured outliers. Keep existing decisions. Missing PSF weight alone does not exclude a frame."));
   layout.add(reviewModes); refreshDecisions();
   layout.add(status); layout.add(daUiRule(dialog)); layout.add(buttons);
   dialog.onClose = function() { saveDraft(); return true; };
   dialog.sizer = layout; dialog.adjustToContents(); dialog.execute();
   return decisionPath;
}
