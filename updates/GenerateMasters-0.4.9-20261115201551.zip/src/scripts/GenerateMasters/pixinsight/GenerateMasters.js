#ifgteq __PI_VERSION__ 1.9.4
#engine v8
#endif
#ifndef DANASTROPHOTO_LIBRARY
#feature-id DanAstroPhoto > GenerateMasters
#feature-icon GenerateMasters.svg
#feature-info Generate calibrated, registered and integrated linear masters from immutable source frames.
#endif
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/DataType.jsh>

/* The durable Node runner owns the journal and files. Native processes execute
 * here in the current PixInsight instance while the front end pumps commands. */
var gmScriptDirectory = File.extractDrive( #__FILE__ ) + File.extractDirectory( #__FILE__ );
if (gmScriptDirectory.charAt(gmScriptDirectory.length - 1) !== "/")
   gmScriptDirectory += "/";
var gmRunner = File.fullPath( gmScriptDirectory + "../scripts/one-run.mjs" );
var gmBundledConfig = File.fullPath( gmScriptDirectory + "../config.yaml" );
if (!File.exists(gmBundledConfig))
   gmBundledConfig = File.fullPath( gmScriptDirectory + "../packaging/config.yaml" );

#ifndef DANASTROPHOTO_PROTOCOL_VERSIONS
#define DANASTROPHOTO_PROTOCOL_VERSIONS
#include "includes/protocol-versions.jsh"
#endif
#include "includes/runner-protocol.jsh"
#include "includes/generate-settings.jsh"
#ifndef DANASTROPHOTO_SHARED_PRESENTATION
#define DANASTROPHOTO_SHARED_PRESENTATION
#include "includes/ui-style.jsh"
#include "includes/console-brand.jsh"
#endif

#include "includes/generate-node.jsh"

function gmNodePath() {
   var candidates = [
      File.homeDirectory + "/Library/Application Support/GenerateMasters/node/bin/node",
      File.homeDirectory + "/.local/share/GenerateMasters/node/bin/node",
      File.fullPath(gmScriptDirectory + "../runtime/node/bin/node"),
      File.fullPath(gmScriptDirectory + "../node_modules/node/bin/node"),
      "/opt/homebrew/opt/node@26/bin/node",
      "/usr/local/opt/node@26/bin/node",
      "/opt/homebrew/bin/node", "/usr/local/bin/node", "node"
   ];
   for (var candidate of candidates)
      if ((candidate === "node" || File.exists(candidate)) &&
          gmNodeSupportedVersion(gmNodeVersion(candidate))) return candidate;
   return "node";
}
function gmNodeVersion(path) {
   try {
      var probe = new ExternalProcess;
      probe.start(path, ["--version"]);
      if (!probe.waitForStarted(5000) || !probe.waitForFinished(5000) ||
          probe.exitCode !== 0) return "";
      return probe.stdout.toString().trim();
   } catch (_) { return ""; }
}

function gmStorageSummaryText(summary) {
   function gib(bytes) { return (bytes / 1073741824).toFixed(1) + " GiB"; }
   if (!summary.storage)
      return "Light intermediates need at least " + gib(summary.minimumWorkingBytes) +
         "; source snapshots, master preparation and PixInsight working files need additional space.";
   var storage = summary.storage;
   return "Worker images: " + storage.staging.location + "\n" +
      gib(storage.staging.availableBytes) + " free; " + gib(storage.staging.minimumBytes) +
      " minimum; " + gib(storage.staging.estimatedPeakBytes) + " estimated peak.\n" +
      "Final masters: " + storage.output.location + "\n" +
      gib(storage.output.availableBytes) + " free; " + gib(storage.output.estimatedBytes) + " estimated output." +
      (storage.sameDevice ? "\nThese folders share a disk: " + gib(storage.combinedMinimumBytes) +
         " combined minimum; " + gib(storage.combinedEstimatedPeakBytes) + " estimated peak." : "") +
      "\nWorker images use bridge.path in the runtime settings file. PixInsight working files may need additional space.";
}

function gmPreflightDialog(summary, preflightOnly) {
   var dialog = daUiBase(new Dialog);
   dialog.windowTitle = "GenerateMasters — input review";
   var heading = new Label(dialog); heading.wordWrapping = true;
   daUiEmphasis(heading, "section");
   heading.text = summary.target + " — " + summary.status;
   var table = new TreeBox(dialog);
   table.numberOfColumns = 8;
   table.headerVisible = true;
   table.rootDecoration = false;
   table.alternateRowColor = true;
   var headers = ["Filter", "Lights", "Excluded", "Unreviewed",
      "Light exp.", "UTC dates", "Flats / dark-flats", "Light darks"];
   for (var c = 0; c < headers.length; ++c)
      table.setHeaderText(c, headers[c]);
   var widths = [65, 60, 65, 80, 80, 250, 190, 85];
   for (var w = 0; w < widths.length; ++w)
      table.setColumnWidth(w, daUiLabelWidth(table, [headers[w]], widths[w]));
   table.setFixedWidth(920);
   table.setFixedHeight(Math.min(280, 55 + 28*summary.inventoryByFilter.length));
   for (var item of summary.inventoryByFilter) {
      var row = new TreeBoxNode(table);
      var flatText = item.flats === null ? "Saved masters" :
         item.flats + " / " + item.darkFlats + " at " +
         item.flatExposureSeconds + "s" +
         (item.flatExposureSelection === "auto" ? " (auto)" : "");
      if (item.darkFlatExposureApproval)
         flatText += " — approved dark-flats " + item.darkFlatExposureSeconds + "s";
      var dateText = item.utcDates.length > 2 ?
         item.utcDates.length + " dates: " + item.utcDates[0] + " – " +
            item.utcDates[item.utcDates.length - 1] : item.utcDates.join(", ");
      var cells = [item.filter, String(item.selectedLights),
         String(item.excludedLights), String(item.unreviewedLights),
         item.lightExposureSeconds + "s", dateText,
         flatText, item.lightDarks === null ? "Saved" : String(item.lightDarks)];
      for (var i = 0; i < cells.length; ++i) row.setText(i, cells[i]);
      row.setToolTip(5, item.utcDates.join(", "));
      row.setToolTip(6, flatText + (item.darkFlatExposureApproval ?
         "\n" + item.darkFlatExposureApproval.operator + ": " + item.darkFlatExposureApproval.reason : ""));
      if (item.savedDarkPath) row.setToolTip(7, "Verified saved master dark: " + item.savedDarkPath);
   }
   var detail = new Label(dialog); detail.wordWrapping = true;
   detail.text = "Reference: " + summary.referenceFilter + "   Calibration: " +
      (summary.usingPreparedMasters ? "validated saved masters" :
         summary.rawCalibrationFrames + " raw frames") +
      "   New calibration frames: " + summary.newCalibrationFrames;
   if (summary.savedMasterDarks && summary.savedMasterDarks.length)
      detail.text += "   Saved master darks: " + summary.savedMasterDarks.length;
   if (summary.nativeCapabilities)
      detail.text += "   PixInsight: " + summary.nativeCapabilities.version;
   var acquisition = new Label(dialog); acquisition.wordWrapping = true;
   var settings = summary.acquisition.settings;
   acquisition.text = "Acquisition: " + (settings.mode === "NUMERIC" ?
      "gain " + settings.gain + ", offset " + settings.offset :
      "camera driver / readout mode / EGAIN") +
      "; measured temperature " +
      (summary.acquisition.measuredLightTemperatureRangeC ?
         summary.acquisition.measuredLightTemperatureRangeC.join(" to ") + " C" : "unavailable") +
      "; dark tolerance " + summary.acquisition.temperatureToleranceC + " C";
   var space = new Label(dialog); space.wordWrapping = true;
   space.text = gmStorageSummaryText(summary);
   var drizzleNote = daUiNotice(dialog, summary.drizzle ?
      (summary.drizzle.enabled ? "2× drizzle selected. Masters have twice the width and height; normal comparison masters are retained.\n" : "Drizzle is off.\n") +
      gmDrizzleRecommendationText(summary.drizzle.recommendations) +
      "\nAdvisory only. Frame-count and sampling thresholds are screening heuristics; measured star profiles and subpixel offsets are assessed later." : "", "info", "Drizzle");
   var note = daUiNotice(dialog, "", "info");
   note.text = summary.status === "READY" ?
      "Inputs are ready. Generate masters now, or close to keep this as a preflight." :
      summary.blockers.join("\n");
   if (summary.warnings && summary.warnings.length)
      note.text += "\n\n" + summary.warnings.join("\n");
   daUiSetNotice(note, summary.status !== "READY" ? "warning" : summary.warnings && summary.warnings.length ? "warning" : "success", note.text, summary.status === "READY" ? "Input review" : "Resolve before generating");
   var close = new PushButton(dialog); close.text = "Close review";
   close.onClick = function() { dialog.ok(); };
   var generateRequested = false;
   var buttons = new HorizontalSizer; buttons.addStretch(); buttons.add(close);
   if (summary.status === "READY" && !preflightOnly) {
      var generate = new PushButton(dialog); daUiEmphasis(generate, "primary"); generate.text = "Generate masters";
      generate.onClick = function() { generateRequested = true; dialog.ok(); };
      buttons.add(generate);
   }
   var layout = new VerticalSizer; layout.margin = 12; layout.spacing = 8;
   layout.add(daUiHeader(dialog, "GenerateMasters", "Input review"));
   layout.add(heading); layout.add(table);
   var summaryGroup = daUiGroup(dialog, "Acquisition and resources");
   summaryGroup.sizer.add(detail);
   summaryGroup.sizer.add(acquisition);
   summaryGroup.sizer.add(space);
   layout.add(summaryGroup);
   layout.add(drizzleNote);
   layout.add(note); layout.add(daUiRule(dialog)); layout.add(buttons);
   dialog.sizer = layout; dialog.adjustToContents();
   dialog.execute();
   return generateRequested;
}

function gmRememberPublication(path) {
   if (!path || !File.exists(path)) return;
   var recent = [];
   try {
      recent = JSON.parse(Settings.read("DanAstroPhoto/recentMasters",
         DataType.String) || "[]");
      if (!Array.isArray(recent)) recent = [];
   } catch (_) { recent = []; }
   recent = [path].concat(recent.filter(function(item) {
      return typeof item === "string" && item !== path && File.exists(item);
   })).slice(0, 8);
   Settings.write("DanAstroPhoto/recentMasters", DataType.String,
      JSON.stringify(recent));
}

function gmDirectoryButton(dialog, edit, caption) {
   var button = new PushButton(dialog);
   button.text = "Browse";
   button.onClick = function() {
      var picker = new GetDirectoryDialog;
      picker.caption = caption;
      picker.initialPath = edit.text;
      if (picker.execute()) {
         edit.text = picker.directoryPath;
         if (edit.onTextUpdated) edit.onTextUpdated(edit.text);
         else dialog.validateInputs();
      }
   };
   return button;
}

#include "includes/generate-dialog.jsh"
#include "includes/generate-quality-review.jsh"
#include "includes/generate-master-review.jsh"
#include "bridge/service.jsh"

function gmRun(dialog, forceDryRun, forceGenerate) {
   if (!dialog.validateInputs()) throw new Error(dialog.validation.text);
   if (!Parameters.has("generateMastersSelfTest")) gmSavePreferences(dialog);
   var dryRun = !forceGenerate && Boolean(forceDryRun || dialog.dryRun.checked);
   var version = gmNodeVersion(dialog.nodeEdit.text);
   if (!gmNodeSupportedVersion(version))
      throw new Error("GenerateMasters requires Node.js 26.13.1 or a newer Node 26 patch. The selected executable " +
         dialog.nodeEdit.text + " reported " + (version || "no version") +
         ". Choose a Node 26 executable in the setup dialog.");
   if (!File.exists(gmRunner)) throw new Error("Runner missing: " + gmRunner);
   var args = [gmRunner, "--events", "--auto-calibration", "--current-instance",
      "--source", dialog.sourceEdit.text.trim(),
      "--calibration-source", dialog.calibrationSourceEdit.text.trim(),
      "--pixinsight-executable", CoreApplication.filePath];
   if (dialog.outputEdit.text.trim()) args.push("--output", dialog.outputEdit.text.trim());
   if (dialog.operatorEdit.text.trim()) args.push("--operator", dialog.operatorEdit.text.trim());
   if (dialog.configEdit.text.trim())
      args.push("--config", dialog.configEdit.text);
   if (dialog.qualityDecisionsEdit.text.trim())
      args.push("--quality-decisions", dialog.qualityDecisionsEdit.text);
   if (dialog.masterAcceptanceEdit.text.trim())
      args.push("--master-acceptance", dialog.masterAcceptanceEdit.text);
   if (dryRun) args.push("--dry-run", "--check-native");
   if (dialog.confirmCalibrationIdentity.checked) args.push("--confirm-calibration-identity");
   if (dialog.retryFailed.checked) args.push("--retry-failed");
   if (dialog.drizzle && dialog.drizzle.checked) args.push("--drizzle", "2x");
   if (!Parameters.has("generateMastersSelfTest")) console.show();
   console.noteln("GenerateMasters: running a verified, resumable job. Original FITS files remain untouched.");
   var progress = daUiBase(new Dialog); progress.windowTitle = "GenerateMasters — processing";
   var stageLabel = new Label(progress); daUiEmphasis(stageLabel, "section"); stageLabel.text = "Starting runner…";
   var journalLabel = new Label(progress); journalLabel.text = "Journal will be shown after input verification.";
   var progressLayout = new VerticalSizer; progressLayout.margin = 12; progressLayout.spacing = 8;
   progressLayout.add(daUiHeader(progress, "GenerateMasters", "Processing"));
   progressLayout.add(stageLabel); progressLayout.add(journalLabel); progress.sizer = progressLayout;
   var running = true;
   var currentBridge = null;
   progress.onClose = function() { return !running; };
   progress.adjustToContents();
   var setupHost = daActiveWorkspaceDialog || dialog;
   setupHost.enabled = false;
   try {
   if (!Parameters.has("generateMastersSelfTest")) progress.open();
   var worker = new ExternalProcess;
   worker.start(dialog.nodeEdit.text, args);
   if (!worker.waitForStarted(30000))
      throw new Error("Node did not start within 30 seconds: " + dialog.nodeEdit.text);
   var summary = null, result = null, qualityReview = null, masterReview = null,
      runnerError = null, protocolError = null;
   var parser = gmEventParser(function(event) {
      if (event.type === "preflight") summary = event.data;
      if (event.type === "result") result = event.data;
      if (event.type === "quality-review") qualityReview = event.data;
      if (event.type === "master-review") masterReview = event.data;
      if (event.data.operator) dialog.operatorEdit.text = event.data.operator;
      if (event.type === "error") runnerError = event.data.message;
      if (event.type === "info" && event.data.currentInstanceBridge) {
         if (currentBridge) throw new Error("The current-instance bridge is already connected");
         currentBridge = createPixInsightBridge(event.data.currentInstanceBridge);
         currentBridge.start();
      }
      if (event.type === "info" && event.data.currentInstanceBridgeStop && currentBridge) {
         currentBridge.stop(); currentBridge = null;
      }
      if (event.type === "stage") {
         stageLabel.text = event.data.stage + (event.data.frames === undefined ? "" : " — " + event.data.frames + " frames");
         console.noteln("Stage: " + stageLabel.text);
      }
      if (event.type === "info" && event.data.message) stageLabel.text = event.data.message;
      if (event.type === "info" && event.data.resetReviews) {
         dialog.qualityDecisionsEdit.text = "";
         dialog.masterAcceptanceEdit.text = "";
      }
      if (event.data.journalPath) {
         journalLabel.text = "Journal: " + event.data.journalPath +
            (event.data.logPath ? "\nWorker log: " + event.data.logPath : "");
         progress.adjustToContents();
      }
      if (event.data.journalPath) console.noteln("Journal: " + event.data.journalPath);
   });
   function consume(chunk) {
      // Drain the worker even if its protocol is invalid; abandoning the handle could interrupt a durable stage.
      if (!protocolError) try { parser.push(chunk); } catch (error) { protocolError = error; }
      console.write(chunk);
   }
   while (!worker.waitForFinished(100)) {
      var out = worker.stdout.toString();
      var error = worker.stderr.toString();
      if (out) consume(out);
      if (error) console.warning(error);
      if (currentBridge) try { currentBridge.poll(); }
      catch (error) { protocolError = protocolError || error; worker.terminate(); }
      if (!Parameters.has("generateMastersSelfTest")) CoreApplication.processEvents();
   }
   var finalOut = worker.stdout.toString();
   var finalError = worker.stderr.toString();
   if (finalOut) consume(finalOut);
   if (finalError) console.warning(finalError);
   if (protocolError) throw protocolError;
   parser.finish();
   if (worker.exitCode !== 0)
      throw new Error(runnerError || "GenerateMasters failed (exit " + worker.exitCode + "). See the Process Console and run journal.");
   } finally {
      try { if (currentBridge) currentBridge.stop(); }
      finally {
         running = false;
         progress.cancel();
         setupHost.enabled = true;
      }
   }
   if (qualityReview) {
      if (Parameters.has("generateMastersSelfTest")) return qualityReview;
      var qualityDecisionPath = gmQualityReviewDialog(qualityReview,
         dialog.operatorEdit.text, dialog.nodeEdit.text, setupHost);
      if (!qualityDecisionPath) return qualityReview;
      dialog.qualityDecisionsEdit.text = qualityDecisionPath;
      dialog.masterAcceptanceEdit.text = "";
      return gmRun(dialog, false, true);
   }
   if (masterReview) {
      if (Parameters.has("generateMastersSelfTest")) return masterReview;
      var masterAcceptancePath = gmMasterReviewDialog(masterReview,
         dialog.operatorEdit.text);
      if (!masterAcceptancePath) return masterReview;
      dialog.masterAcceptanceEdit.text = masterAcceptancePath;
      return gmRun(dialog, false, true);
   }
   if (dryRun) {
      if (!summary) throw new Error("Runner did not return a preflight event");
      if (!Parameters.has("generateMastersSelfTest") && gmPreflightDialog(summary, dialog.dryRun.checked))
         return gmRun(dialog, false, true);
      return summary;
   }
   console.noteln("GenerateMasters completed.");
   if (!result) throw new Error("Runner did not return a publication event");
   {
      try { gmRememberPublication(result.manifestPath); }
      catch (error) { console.warningln("Could not remember latest masters: " + error); }
      if (!Parameters.has("generateMastersSelfTest")) {
         var message = "Masters: " + result.finalDir +
            "\n\nNext: open DanAstroPhoto and choose the Process workspace. Choose the latest published masters to continue.";
         if (result.reusableProfilePath)
            message += "\nReusable profile: " + result.reusableProfilePath;
         (new MessageBox(message, "GenerateMasters complete",
            StdIcon_Information, StdButton_Ok)).execute();
      }
   }
   return result;
}

function gmMain() {
if (Parameters.has("generateMastersSelfTest")) {
   var testDialog = new GenerateMastersDialog;
   if (Parameters.has("generateMastersDryRunTest")) {
      testDialog.dryRun.checked = true;
      gmRun(testDialog);
   }
   File.writeTextFile(Parameters.getString("generateMastersSelfTest"), JSON.stringify({
      title:testDialog.windowTitle, source:testDialog.sourceEdit.text,
      calibrationSource:testDialog.calibrationSourceEdit.text,
      runnerExists:File.exists(gmRunner),
      pixInsightExecutable:CoreApplication.filePath
   }));
} else {
   daConsoleStart("GenerateMasters", gmScriptDirectory);
   try {
      var dialog = new GenerateMastersDialog;
      while (dialog.execute()) {
         try { gmRun(dialog); break; }
         catch (error) {
            console.criticalln(String(error));
            dialog.showRunError(error);
         }
      }
      gmLaunchPendingBlink();
   } finally { daConsoleEnd("GenerateMasters"); }
}

}
#ifndef DANASTROPHOTO_LIBRARY
gmMain();
#endif
