const directions = {
  fwhm: "LOW", eccentricity: "LOW", noise: "LOW", starResidual: "LOW",
  psfSignalWeight: "HIGH", snrWeightMetric: "HIGH", stars: "HIGH",
};

export function selectMeasuredReference(acceptedCalibrated, measurements,
  referenceFilter, requestedChecksum = null) {
  const eligible = acceptedCalibrated.filter((item) =>
    item.filter === referenceFilter);
  if (!eligible.length) throw new Error("No accepted registration reference frame");
  const byChecksum = new Map(measurements.map((item) =>
    [item.sourceChecksum, item]));
  if (requestedChecksum) {
    const chosen = eligible.find((item) => item.source.checksum === requestedChecksum);
    if (!chosen)
      throw new Error("Configured registration reference was excluded by quality decisions");
    return { item: chosen, selection: { method: "PINNED_CHECKSUM",
      sourceChecksum: requestedChecksum,
      measurements: byChecksum.get(requestedChecksum)?.metrics ?? null } };
  }
  if (!measurements.length)
    throw new Error("Select a pinned registration reference when measurement is skipped");
  const rows = eligible.map((item) => ({ item,
    record: byChecksum.get(item.source.checksum) }));
  if (rows.some((row) => !row.record))
    throw new Error("Accepted registration reference candidates lack measurements");
  const scoringDirections = { ...directions };
  const omittedMetrics = [];
  // Compare every candidate using the same metrics. Missing PSF weights are
  // explicitly reported by the batch adapter; they are never assigned zero.
  if (rows.some((row) => row.record.metrics.psfSignalWeight === null &&
      row.record.metrics.unavailableMetrics?.includes("psfSignalWeight"))) {
    delete scoringDirections.psfSignalWeight;
    omittedMetrics.push("psfSignalWeight");
  }
  const scored = rows.map(({ item, record }) => {
    const components = Object.fromEntries(Object.entries(scoringDirections)
      .map(([metric, direction]) => {
        const values = rows.map((row) => row.record.metrics[metric]);
        if (values.some((value) => !Number.isFinite(value)))
          throw new Error("Invalid registration reference metric " + metric);
        const rank = values.filter((value) => value <= record.metrics[metric]).length /
          values.length;
        return [metric, direction === "HIGH" ? rank : 1 - rank];
      }));
    return { item, sourceChecksum: item.source.checksum,
      score: Object.values(components).reduce((sum, value) => sum + value, 0) /
        Object.keys(components).length,
      components, measurements: record.metrics };
  }).sort((a, b) => b.score - a.score ||
    a.sourceChecksum.localeCompare(b.sourceChecksum));
  return { item: scored[0].item, selection: {
    method: "WITHIN_FILTER_FAVORABLE_PERCENTILES", referenceFilter,
    sourceChecksum: scored[0].sourceChecksum,
    score: scored[0].score, components: scored[0].components,
    measurements: scored[0].measurements,
    alternatives: scored.slice(1, 10).map(({ sourceChecksum, score }) =>
      ({ sourceChecksum, score })),
    directions: scoringDirections, omittedMetrics,
  } };
}

export function alignmentReview(acceptedCalibrated, nativeRows) {
  if (nativeRows.length !== acceptedCalibrated.length)
    throw new Error("Alignment review lacks a row for each accepted light");
  return nativeRows.map((row, index) => {
    const source = acceptedCalibrated[index].source;
    const flags = [];
    if (!row.succeeded) flags.push("REGISTRATION_FAILED");
    else {
      if (row.diagnostics.overlapping < 0.5)
        flags.push("LOW_OVERLAP");
      if (row.diagnostics.rmsError > 2.5)
        flags.push("HIGH_RMS_ERROR");
      if (row.diagnostics.totalPairMatches < 10)
        flags.push("FEW_PAIR_MATCHES");
    }
    return { sourcePath: source.path, sourceChecksum: source.checksum,
      filter: source.filter, exposureSeconds: source.exposureSeconds,
      outputPath: row.succeeded ? row.outputPath : null,
      diagnostics: row.diagnostics, flags };
  });
}
