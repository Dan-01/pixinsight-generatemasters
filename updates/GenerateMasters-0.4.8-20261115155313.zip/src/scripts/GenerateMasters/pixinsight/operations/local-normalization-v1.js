/* Explicit, build-scoped LocalNormalization adapter that emits XNML data only. */
var LN_ADAPTER = "pixinsight-local-normalization/1";

function probeLocalNormalization() {
   var reasons = [];
   if (environment.pixInsightVersion !== "1.9.4.0-1695")
      reasons.push("Build has not passed this LocalNormalization contract");
   if (typeof LocalNormalization === "undefined")
      reasons.push("LocalNormalization unavailable");
   else {
      var p = new LocalNormalization;
      var fields = [
         "scale", "scaleEvaluationMethod", "referencePathOrViewId",
         "referenceIsView", "targetItems", "generateNormalizedImages",
         "generateNormalizationData", "localScaleCorrections",
         "outputDirectory", "overwriteExistingFiles", "onError", "outputData"
      ];
      for (var i = 0; i < fields.length; ++i)
         if (typeof p[fields[i]] === "undefined")
            reasons.push("Missing parameter " + fields[i]);
   }
   return {
      supported: reasons.length === 0,
      adapter: LN_ADAPTER,
      version: environment.pixInsightVersion,
      normalizationData: true,
      normalizedImages: false,
      scaleEvaluationMethods: ["PSF_SIGNAL"],
      reasons: reasons
   };
}

function validateLocalNormalization(p, id) {
   var keys = [
      "adapter", "jobId", "referencePath", "inputPath", "outputDirectory",
      "expectedVersion", "scale", "scaleEvaluationMethod",
      "generateNormalizedImages", "generateNormalizationData",
      "localScaleCorrections"
   ];
   if (Object.keys(p).length !== keys.length)
      throw new Error("Malformed LocalNormalization parameters");
   for (var i = 0; i < keys.length; ++i)
      if (!Object.prototype.hasOwnProperty.call(p, keys[i]))
         throw new Error("Missing LocalNormalization field " + keys[i]);
   if (p.adapter !== LN_ADAPTER || p.expectedVersion !== environment.pixInsightVersion || p.jobId !== id)
      throw new Error("LocalNormalization adapter/version/job mismatch");
   var base = bridgePath + "/jobs/" + id;
   if (p.referencePath !== base + "/reference.fits" ||
       p.inputPath !== base + "/input.fits" ||
       p.outputDirectory !== base + "/output")
      throw new Error("LocalNormalization paths must use the job's isolated staging directory");
   if (!(typeof p.scale === "number" && p.scale >= 128 && p.scale <= 4096 && Math.floor(p.scale) === p.scale) ||
       p.scaleEvaluationMethod !== "PSF_SIGNAL" ||
       p.generateNormalizedImages !== false || p.generateNormalizationData !== true ||
       p.localScaleCorrections !== false)
      throw new Error("LocalNormalization v1 fixed contract was changed");
}

function localNormalizationPathInside(path, directory) {
   return path.indexOf(directory + "/") === 0 && path.slice(-5).toLowerCase() === ".xnml";
}

function normalizeLocalImage(p) {
   var capability = probeLocalNormalization();
   if (!capability.supported) throw new Error(capability.reasons.join("; "));
   var instancePath = p.outputDirectory + "/LocalNormalization.js";
   if (File.exists(instancePath))
      throw new Error("Staged LocalNormalization output already exists; explicit recovery review required");

   var process = new LocalNormalization;
   process.scale = p.scale;
   process.noScale = false;
   process.globalLocationNormalization = false;
   process.truncate = true;
   process.backgroundSamplingDelta = 32;
   process.rejection = true;
   process.referenceRejection = false;
   process.lowClippingLevel = 0.000045;
   process.highClippingLevel = 0.85;
   process.referenceRejectionThreshold = 3.00;
   process.targetRejectionThreshold = 3.20;
   process.hotPixelFilterRadius = 2;
   process.noiseReductionFilterRadius = 0;
   process.modelScalingFactor = 8.00;
   process.scaleEvaluationMethod = LocalNormalization.ScaleEvaluationMethod_PSFSignal;
   process.localScaleCorrections = false;
   process.psfStructureLayers = 5;
   process.saturationThreshold = 0.75;
   process.saturationRelative = true;
   process.rejectionLimit = 0.30;
   process.psfNoiseLayers = 1;
   process.psfHotPixelFilterRadius = 1;
   process.psfNoiseReductionFilterRadius = 0;
   process.psfMinStructureSize = 0;
   process.psfMinSNR = 40.00;
   process.psfAllowClusteredSources = true;
   process.psfType = LocalNormalization.PSFType_Auto;
   process.psfGrowth = 1.00;
   process.psfMaxStars = 24576;
   process.referencePathOrViewId = p.referencePath;
   process.referenceIsView = false;
   process.targetItems = [[true, p.inputPath]];
   process.inputHints = "fits-keywords normalize only-first-image raw signed-is-physical";
   process.outputHints = "properties fits-keywords no-compress-data no-embedded-data no-resolution";
   process.generateNormalizedImages = LocalNormalization.GenerateNormalizedImages_Never;
   process.generateNormalizationData = true;
   process.generateInvalidData = false;
   process.generateHistoryProperties = true;
   process.showBackgroundModels = false;
   process.showLocalScaleModels = false;
   process.showRejectionMaps = false;
   process.showStructureMaps = false;
   process.plotNormalizationFunctions = LocalNormalization.PlotNormalizationFunctions_DontPlot;
   process.noGUIMessages = true;
   process.outputDirectory = p.outputDirectory;
   process.outputExtension = ".xisf";
   process.outputPrefix = "";
   process.outputPostfix = "_n";
   process.overwriteExistingFiles = false;
   process.onError = LocalNormalization.OnError_Abort;
   File.writeTextFile(instancePath, process.toSource());
   if (!process.executeGlobal()) throw new Error("LocalNormalization failed");
   if (process.outputData.length !== 1)
      throw new Error("Expected one LocalNormalization output row");
   var row = process.outputData[0];
   var normalizationDataPath = String(row[0]);
   if (!Boolean(row[5]) || !localNormalizationPathInside(normalizationDataPath, p.outputDirectory) ||
       !File.exists(normalizationDataPath))
      throw new Error("LocalNormalization did not produce valid isolated XNML data");
   if (String(row[1]).length)
      throw new Error("LocalNormalization unexpectedly generated a normalized image");
   return {
      adapter: LN_ADAPTER,
      normalizationDataPath: normalizationDataPath,
      processInstancePath: instancePath,
      scaleFactor: Number(row[2])
   };
}
