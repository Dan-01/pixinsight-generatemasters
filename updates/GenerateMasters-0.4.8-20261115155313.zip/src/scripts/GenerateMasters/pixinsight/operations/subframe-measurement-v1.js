/* Measurement-only SubframeSelector adapter. No approval or weighting policy. */
var SM_ADAPTER = "pixinsight-subframe-measurement/1";

function probeSubframeMeasurement() {
   var reasons = [];
   if (["1.9.4.0-1695", "1.9.5.0-1705", "1.9.5.0-1706"].indexOf(environment.pixInsightVersion) < 0)
      reasons.push("Build has not passed this SubframeSelector contract");
   if (typeof SubframeSelector === "undefined")
      reasons.push("SubframeSelector unavailable");
   else {
      var p = new SubframeSelector;
      var fields = [
         "routine", "nonInteractive", "subframes", "fileCache", "subframeScale",
         "cameraGain", "cameraResolution", "scaleUnit", "dataUnit", "psfFit",
         "maxPSFFits", "approvalExpression", "weightingExpression", "measurements"
      ];
      for (var i = 0; i < fields.length; ++i)
         if (typeof p[fields[i]] === "undefined") reasons.push("Missing parameter " + fields[i]);
      var constants = ["MeasureSubframes", "Pixel", "ArcSeconds", "Normalized", "DataNumber", "Electron", "Gaussian", "Moffat4", "Bits8", "Bits10", "Bits12", "Bits14", "Bits16", "Abort"];
      for (var j = 0; j < constants.length; ++j)
         if (typeof SubframeSelector[constants[j]] === "undefined") reasons.push("Missing enum " + constants[j]);
   }
   return {
      supported: reasons.length === 0,
      adapter: SM_ADAPTER,
      version: environment.pixInsightVersion,
      weighting: false,
      rejection: false,
      classification: false,
      reasons: reasons
   };
}

function validateSubframeMeasurement(p, id) {
   var keys = [
      "adapter", "jobId", "inputPath", "outputDirectory", "expectedVersion",
      "cameraGain", "cameraResolutionBits", "subframeScale", "scaleUnit",
      "dataUnit", "psfFit", "maxPSFFits"
   ];
   if (Object.keys(p).length !== keys.length)
      throw new Error("Malformed subframe-measurement parameters");
   for (var i = 0; i < keys.length; ++i)
      if (!Object.prototype.hasOwnProperty.call(p, keys[i]))
         throw new Error("Missing subframe-measurement field " + keys[i]);
   if (p.adapter !== SM_ADAPTER || p.expectedVersion !== environment.pixInsightVersion || p.jobId !== id)
      throw new Error("Subframe measurement adapter/version/job mismatch");
   var base = bridgePath + "/jobs/" + id;
   if (p.inputPath !== base + "/input.fits" || p.outputDirectory !== base + "/output")
      throw new Error("Measurement paths must use the job's isolated staging directory");
   if (!(typeof p.cameraGain === "number" && p.cameraGain > 0) ||
       !(typeof p.subframeScale === "number" && p.subframeScale > 0) ||
       [8, 10, 12, 14, 16].indexOf(p.cameraResolutionBits) < 0 ||
       ["PIXEL", "ARCSECONDS"].indexOf(p.scaleUnit) < 0 ||
       ["NORMALIZED", "DATA_NUMBER", "ELECTRON"].indexOf(p.dataUnit) < 0 ||
       ["GAUSSIAN", "MOFFAT4"].indexOf(p.psfFit) < 0 ||
       Math.floor(p.maxPSFFits) !== p.maxPSFFits || p.maxPSFFits <= 0 || p.maxPSFFits > 100000)
      throw new Error("Invalid subframe-measurement parameters");
}

function measurementValue(value, name) {
   var number = Number(value);
   if (!isFinite(number)) throw new Error("Non-finite measurement " + name);
   return number;
}

function measurementRecord(row, allowMissingPsfWeight) {
   return {
      filePath: String(row[3]),
      fwhm: measurementValue(row[5], "FWHM"),
      eccentricity: measurementValue(row[6], "eccentricity"),
      psfSignalWeight: allowMissingPsfWeight === true && !isFinite(Number(row[7])) ?
         null : measurementValue(row[7], "PSFSignalWeight"),
      snrWeightMetric: measurementValue(row[9], "SNRWeight"),
      median: measurementValue(row[10], "median"),
      medianMeanDev: measurementValue(row[11], "medianMeanDev"),
      noise: measurementValue(row[12], "noise"),
      noiseRatio: measurementValue(row[13], "noiseRatio"),
      stars: measurementValue(row[14], "stars"),
      starResidual: measurementValue(row[15], "starResidual"),
      fwhmMeanDev: measurementValue(row[16], "FWHMMeanDev"),
      eccentricityMeanDev: measurementValue(row[17], "eccentricityMeanDev"),
      starResidualMeanDev: measurementValue(row[18], "starResidualMeanDev"),
      psfFlux: measurementValue(row[21], "PSFFlux"),
      psfFluxPower: measurementValue(row[22], "PSFFluxPower"),
      psfTotalMeanFlux: measurementValue(row[23], "PSFTotalMeanFlux"),
      psfTotalMeanPowerFlux: measurementValue(row[24], "PSFTotalMeanPowerFlux"),
      psfCount: measurementValue(row[25], "PSFCount"),
      mStar: measurementValue(row[26], "MStar"),
      nStar: measurementValue(row[27], "NStar"),
      psfSnr: measurementValue(row[28], "PSFSNR"),
      psfScale: measurementValue(row[29], "PSFScale"),
      psfScaleSnr: measurementValue(row[30], "PSFScaleSNR")
   };
}

function measureSubframe(p) {
   var capability = probeSubframeMeasurement();
   if (!capability.supported) throw new Error(capability.reasons.join("; "));
   var reportPath = p.outputDirectory + "/measurements.json";
   var instancePath = p.outputDirectory + "/SubframeSelector.js";
   if (File.exists(reportPath) || File.exists(instancePath))
      throw new Error("Staged measurement output already exists; explicit recovery review required");
   var process = new SubframeSelector;
   process.routine = SubframeSelector.MeasureSubframes;
   process.nonInteractive = true;
   process.subframes = [[true, p.inputPath, "", ""]];
   process.fileCache = false;
   process.subframeScale = p.subframeScale;
   process.cameraGain = p.cameraGain;
   process.cameraResolution = SubframeSelector["Bits" + p.cameraResolutionBits];
   process.scaleUnit = p.scaleUnit === "PIXEL" ? SubframeSelector.Pixel : SubframeSelector.ArcSeconds;
   process.dataUnit = p.dataUnit === "NORMALIZED" ? SubframeSelector.Normalized :
      p.dataUnit === "DATA_NUMBER" ? SubframeSelector.DataNumber : SubframeSelector.Electron;
   process.psfFit = p.psfFit === "GAUSSIAN" ? SubframeSelector.Gaussian : SubframeSelector.Moffat4;
   process.maxPSFFits = p.maxPSFFits;
   process.approvalExpression = "";
   process.weightingExpression = "";
   process.outputKeyword = "";
   process.onError = SubframeSelector.Abort;
   File.writeTextFile(instancePath, process.toSource());
   if (!process.executeGlobal()) throw new Error("SubframeSelector measurement failed");
   var measurements = [];
   for (var i = 0; i < process.measurements.length; ++i)
      measurements.push(measurementRecord(process.measurements[i]));
   if (measurements.length !== 1) throw new Error("Expected exactly one subframe measurement");
   File.writeTextFile(reportPath, JSON.stringify({
      adapter: SM_ADAPTER,
      version: capability.version,
      request: p,
      weightingExpression: "",
      approvalExpression: "",
      measurements: measurements
   }));
   return {
      adapter: SM_ADAPTER,
      reportPath: reportPath,
      processInstancePath: instancePath,
      measurements: measurements
   };
}
