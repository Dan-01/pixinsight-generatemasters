/* Optional rejection-aware drizzle for GenerateMasters. */
function oneRunDrizzleCapability() {
   var reasons = [];
   if (["1.9.4.0-1695", "1.9.5.0-1706"].indexOf(environment.pixInsightVersion) < 0)
      reasons.push("This build has not passed the GenerateMasters drizzle contract");
   if (typeof DrizzleIntegration === "undefined") reasons.push("DrizzleIntegration unavailable");
   else {
      var process = new DrizzleIntegration;
      for (var field of ["inputData", "scale", "dropShrink", "kernelFunction", "enableRejection",
         "enableImageWeighting", "enableLocalNormalization", "enableCFA", "integrationImageId",
         "weightImageId", "imageData", "totalData", "totalRejectedLowRK", "totalRejectedHighRK"])
         if (!(field in process)) reasons.push("DrizzleIntegration missing " + field);
      if (typeof DrizzleIntegration.Kernel_Square === "undefined" || typeof DrizzleIntegration.Abort === "undefined")
         reasons.push("DrizzleIntegration constants unavailable");
   }
   if (typeof ImageIntegration === "undefined" || !("generateDrizzleData" in new ImageIntegration))
      reasons.push("ImageIntegration drizzle rejection data unavailable");
   return { supported: !reasons.length, reasons: reasons };
}
function oneRunDrizzle(request) {
   var capability = oneRunDrizzleCapability();
   if (!capability.supported) throw new Error(capability.reasons.join("; "));
   if (request.inputs.length < 3 || request.scale !== 2 || request.dropShrink !== 0.9)
      throw new Error("GenerateMasters drizzle requires at least three rejection-aware inputs and the 2x/0.9 recipe");
   for (var path of request.inputs)
      if (path.slice(-5).toLowerCase() !== ".xdrz") throw new Error("Drizzle requires XDRZ input");
   var process = new DrizzleIntegration;
   process.inputData = request.inputs.map(function(path) { return [true, path, ""]; });
   process.inputHints = "properties fits-keywords no-compress-data";
   process.scale = request.scale; process.dropShrink = request.dropShrink;
   process.kernelFunction = DrizzleIntegration.Kernel_Square;
   process.enableCFA = false; process.enableRejection = true;
   process.enableImageWeighting = true; process.enableLocalNormalization = false;
   process.enableAdaptiveNormalization = false; process.useROI = false;
   process.closePreviousImages = false; process.useLUT = true;
   process.truncateOnOutOfRange = false; process.noGUIMessages = true;
   process.showImages = true; process.onError = DrizzleIntegration.Abort;
   var instance = request.outputDirectory + "/DrizzleIntegration.js";
   File.writeTextFile(instance, process.toSource());
   if (!process.executeGlobal() || process.imageData.length !== request.inputs.length ||
       !(Number(process.totalData) > 0))
      throw new Error("DrizzleIntegration did not integrate the complete stack");
   var integrated = ImageWindow.windowById(process.integrationImageId);
   var weight = ImageWindow.windowById(process.weightImageId);
   if (integrated.isNull || weight.isNull) throw new Error("Drizzle master or coverage window unavailable");
   var masterPath = request.outputDirectory + "/drizzle-master.xisf";
   var weightPath = request.outputDirectory + "/drizzle-weight.xisf";
   oneRunSave(integrated, masterPath, "properties fits-keywords no-compress-data");
   oneRunSave(weight, weightPath, "properties no-compress-data");
   integrated.forceClose(); weight.forceClose();
   return { outputs: [masterPath, weightPath], processInstancePath: instance,
      statistics: { numberOfImages: process.imageData.length,
         totalRejectedLow: Number(process.totalRejectedLowRK), totalRejectedHigh: Number(process.totalRejectedHighRK) } };
}
