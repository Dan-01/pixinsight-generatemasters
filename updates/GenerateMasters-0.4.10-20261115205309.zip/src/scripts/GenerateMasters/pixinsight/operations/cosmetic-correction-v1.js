/* Explicit, build-scoped CosmeticCorrection adapter. */
var CC_ADAPTER = "pixinsight-cosmetic-correction/1";

function probeCosmeticCorrection() {
   var reasons = [];
   if (environment.pixInsightVersion !== "1.9.4.0-1695")
      reasons.push("Build has not passed this CosmeticCorrection contract");
   if (typeof CosmeticCorrection === "undefined")
      reasons.push("CosmeticCorrection unavailable");
   else {
      var p = new CosmeticCorrection;
      var fields = [
         "targetFrames", "masterDarkPath", "outputDir", "outputExtension",
         "prefix", "postfix", "generateHistoryProperties", "overwrite",
         "amount", "cfa", "useMasterDark", "hotDarkCheck", "hotDarkLevel",
         "coldDarkCheck", "coldDarkLevel", "useAutoDetect", "hotAutoCheck",
         "hotAutoValue", "coldAutoCheck", "coldAutoValue", "useDefectList"
      ];
      for (var i = 0; i < fields.length; ++i)
         if (typeof p[fields[i]] === "undefined") reasons.push("Missing parameter " + fields[i]);
   }
   return {
      supported: reasons.length === 0,
      adapter: CC_ADAPTER,
      version: environment.pixInsightVersion,
      modes: ["MASTER_DARK", "AUTO_DETECT"],
      defectList: false,
      reasons: reasons
   };
}

function validateCosmeticCorrection(p, id) {
   var keys = [
      "adapter", "jobId", "inputPath", "masterDarkPath", "outputDirectory",
      "expectedVersion", "amount", "useMasterDark", "hotDarkCheck",
      "hotDarkLevel", "coldDarkCheck", "coldDarkLevel", "useAutoDetect",
      "hotAutoCheck", "hotAutoValue", "coldAutoCheck", "coldAutoValue"
   ];
   if (Object.keys(p).length !== keys.length)
      throw new Error("Malformed cosmetic-correction parameters");
   for (var i = 0; i < keys.length; ++i)
      if (!Object.prototype.hasOwnProperty.call(p, keys[i]))
         throw new Error("Missing cosmetic-correction field " + keys[i]);
   if (p.adapter !== CC_ADAPTER || p.expectedVersion !== environment.pixInsightVersion || p.jobId !== id)
      throw new Error("CosmeticCorrection adapter/version/job mismatch");
   var base = bridgePath + "/jobs/" + id;
   if (p.inputPath !== base + "/input.fits" ||
       p.outputDirectory !== base + "/output" ||
       (p.masterDarkPath !== null && p.masterDarkPath !== base + "/master-dark.fits"))
      throw new Error("CosmeticCorrection paths must use the job's isolated staging directory");
   if (p.useMasterDark !== (p.masterDarkPath !== null))
      throw new Error("Master-dark mode/path mismatch");
   if (!(typeof p.amount === "number" && p.amount >= 0 && p.amount <= 1))
      throw new Error("Invalid correction amount");
   if (!(typeof p.hotDarkLevel === "number" && p.hotDarkLevel >= 0 && p.hotDarkLevel <= 1) ||
       !(typeof p.coldDarkLevel === "number" && p.coldDarkLevel >= 0 && p.coldDarkLevel <= 1) ||
       !(typeof p.hotAutoValue === "number" && p.hotAutoValue > 0) ||
       !(typeof p.coldAutoValue === "number" && p.coldAutoValue > 0))
      throw new Error("Invalid CosmeticCorrection thresholds");
   if (!((p.useMasterDark && (p.hotDarkCheck || p.coldDarkCheck)) ||
         (p.useAutoDetect && (p.hotAutoCheck || p.coldAutoCheck))))
      throw new Error("At least one explicitly configured detector is required");
}

function cosmeticConvert(source, target) {
   if (File.exists(target)) throw new Error("Conversion output already exists: " + target);
   var windows = ImageWindow.open(source, "", "fits-keywords normalize only-first-image raw signed-is-physical", true);
   try {
      if (windows.length !== 1 || windows[0].mainView.image.numberOfChannels !== 1)
         throw new Error("Expected one monochrome image");
      if (!windows[0].saveAs(target, false, false, true, false, "properties fits-keywords no-compress-data"))
         throw new Error("Format conversion failed");
   } finally {
      for (var i = 0; i < windows.length; ++i) windows[i].forceClose();
   }
}

function applyCosmeticCorrection(p) {
   var capability = probeCosmeticCorrection();
   if (!capability.supported) throw new Error(capability.reasons.join("; "));
   var nativeDirectory = p.outputDirectory + "/native";
   if (!File.directoryExists(nativeDirectory)) File.createDirectory(nativeDirectory, true);
   var nativeInput = nativeDirectory + "/input.xisf";
   var nativeDark = nativeDirectory + "/master-dark.xisf";
   var nativeOutput = p.outputDirectory + "/input_cc.xisf";
   var output = p.outputDirectory + "/light_cc.fits";
   var instance = p.outputDirectory + "/CosmeticCorrection.js";
   if (File.exists(nativeOutput) || File.exists(output) || File.exists(instance))
      throw new Error("Staged CosmeticCorrection output already exists; explicit recovery review required");
   cosmeticConvert(p.inputPath, nativeInput);
   if (p.masterDarkPath !== null) cosmeticConvert(p.masterDarkPath, nativeDark);
   var process = new CosmeticCorrection;
   process.targetFrames = [[true, nativeInput]];
   process.masterDarkPath = p.masterDarkPath !== null ? nativeDark : "";
   process.outputDir = p.outputDirectory;
   process.outputExtension = ".xisf";
   process.prefix = "";
   process.postfix = "_cc";
   process.generateHistoryProperties = true;
   process.overwrite = false;
   process.amount = p.amount;
   process.cfa = false;
   process.useMasterDark = p.useMasterDark;
   process.hotDarkCheck = p.hotDarkCheck;
   process.hotDarkLevel = p.hotDarkLevel;
   process.coldDarkCheck = p.coldDarkCheck;
   process.coldDarkLevel = p.coldDarkLevel;
   process.useAutoDetect = p.useAutoDetect;
   process.hotAutoCheck = p.hotAutoCheck;
   process.hotAutoValue = p.hotAutoValue;
   process.coldAutoCheck = p.coldAutoCheck;
   process.coldAutoValue = p.coldAutoValue;
   process.useDefectList = false;
   File.writeTextFile(instance, process.toSource());
   if (!process.executeGlobal()) throw new Error("CosmeticCorrection failed");
   if (!File.exists(nativeOutput)) throw new Error("Expected CosmeticCorrection output not produced");
   cosmeticConvert(nativeOutput, output);
   var intermediates = [
      { path: nativeInput, role: "INPUT_CONVERSION" },
      { path: nativeOutput, role: "NATIVE_OUTPUT" },
      { path: instance, role: "PROCESS_INSTANCE" }
   ];
   if (p.masterDarkPath !== null)
      intermediates.push({ path: nativeDark, role: "MASTER_DARK_CONVERSION" });
   return { adapter: CC_ADAPTER, outputPath: output, intermediates: intermediates };
}
