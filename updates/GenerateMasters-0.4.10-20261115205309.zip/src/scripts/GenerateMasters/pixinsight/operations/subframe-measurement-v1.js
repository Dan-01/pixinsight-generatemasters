/* Measurement-only SubframeSelector adapter. No approval or weighting policy. */
var SM_ADAPTER = "pixinsight-subframe-measurement/1";

// GenerateMasters uses ImageAnalysis on 1.9.6+. Keep the standalone legacy
// adapter's units and result contract unchanged for existing bridge clients.
function oneRunUsesImageAnalysis() {
   return /^1\.9\.(?:[6-9]|[1-9][0-9])\./.test(environment.pixInsightVersion);
}

var IA_COLUMNS = {
   filePath: "Path", fwhm: "FWHMpx", fwhmSigma: "FWHMpxSigma",
   eccentricity: "Eccentricity", eccentricitySigma: "EccentricitySigma",
   psfResidual: "PSFResidual", psfResidualSigma: "PSFResidualSigma",
   median: "Median", sigma: "Sigma", entropy: "Entropy", noise: "Noise",
   noiseRatio: "NoiseRatio", snrWeightMetric: "SNR", stars: "Stars",
   psfSignalWeight: "PSFSignalWeight", psfFlux: "PSFFlux",
   psfTotalMeanFlux: "PSFTotalMeanFlux", psfCount: "PSFCount",
   mStar: "MStar", nStar: "NStar", psfSnr: "PSFSNR",
   psfScale: "PSFScale", psfScaleSnr: "PSFScaleSNR"
};

function probeOneRunMeasurement() {
   if (!oneRunUsesImageAnalysis()) return probeSubframeMeasurement();
   var reasons = [];
   if (environment.pixInsightVersion !== "1.9.6.0-1718")
      reasons.push("Build has not passed the GenerateMasters ImageAnalysis contract");
   if (typeof ImageAnalysis === "undefined") reasons.push("ImageAnalysis unavailable");
   else {
      var p = new ImageAnalysis;
      for (var field of ["task", "frames", "fileCache", "extendedMeasurements",
         "psfFit", "maxPSFFits", "approvalExpression", "weightingExpression", "onError", "measurements"])
         if (!(field in p)) reasons.push("ImageAnalysis missing " + field);
      for (var name of ["Task_Measure", "PSF_Moffat4", "OnError_Abort"])
         if (typeof ImageAnalysis[name] === "undefined") reasons.push("ImageAnalysis missing " + name);
      var used = [];
      for (var metric in IA_COLUMNS) {
         var index = ImageAnalysis["measurements_measurement" + IA_COLUMNS[metric]];
         if (typeof index !== "number" || index < 0 || Math.floor(index) !== index || used.indexOf(index) >= 0)
            reasons.push("ImageAnalysis missing or invalid measurement column " + IA_COLUMNS[metric]);
         used.push(index);
      }
   }
   return { supported: !reasons.length, version: environment.pixInsightVersion, reasons: reasons };
}

function imageAnalysisRecord(row) {
   var record = { measurementEngine: "ImageAnalysis", unavailableMetrics: [] };
   for (var metric in IA_COLUMNS) {
      var value = row[ImageAnalysis["measurements_measurement" + IA_COLUMNS[metric]]];
      if (metric === "filePath") {
         if (typeof value !== "string" || !value.length) throw new Error("Invalid ImageAnalysis path");
         record.filePath = value;
      } else if (metric === "psfSignalWeight" && typeof value === "number" && isNaN(value)) {
         record.psfSignalWeight = null;
         record.unavailableMetrics.push(metric);
      } else {
         if (typeof value !== "number" || !isFinite(value))
            throw new Error("Non-finite ImageAnalysis measurement " + metric);
         record[metric] = value;
      }
   }
   // Sigma and relative PSF residual are native 1.9.6 measurements. They must
   // never be relabeled as the old mean deviations or absolute StarResidual.
   return record;
}

function oneRunMeasureImageAnalysis(request) {
   var process = new ImageAnalysis;
   process.task = ImageAnalysis.Task_Measure;
   process.frames = request.inputs.map(function(path) { return [true, path, "", ""]; });
   process.fileCache = false;
   process.extendedMeasurements = false;
   process.psfFit = ImageAnalysis.PSF_Moffat4;
   process.maxPSFFits = 20000;
   process.approvalExpression = "";
   process.weightingExpression = "";
   process.onError = ImageAnalysis.OnError_Abort;
   var instancePath = request.outputDirectory + "/ImageAnalysis.js";
   File.writeTextFile(instancePath, process.toSource());
   if (!process.executeGlobal()) throw new Error("Batch ImageAnalysis measurement failed");
   return { measurements: process.measurements.map(imageAnalysisRecord), processInstancePath: instancePath };
}

function probeSubframeMeasurement() {
   var reasons = [];
   if (["1.9.4.0-1695", "1.9.5.0-1705", "1.9.5.0-1706"].indexOf(environment.pixInsightVersion) < 0)
      reasons.push("Build has not passed this SubframeSelector contract");
   if (typeof SubframeSelector === "undefined")
      reasons.push("SubframeSelector unavailable");
   else {
      var p = new SubframeSelector;
      var fields = [
         "routine", "nonInteractive", "subframes", "fileCache", "subframeScale",
         "cameraGain", "cameraResolution", "scaleUnit", "dataUnit", "psfFit",
         "maxPSFFits", "approvalExpression", "weightingExpression", "measurements"
      ];
      for (var i = 0; i < fields.length; ++i)
         if (typeof p[fields[i]] === "undefined") reasons.push("Missing parameter " + fields[i]);
      var constants = ["MeasureSubframes", "Pixel", "ArcSeconds", "Normalized", "DataNumber", "Electron", "Gaussian", "Moffat4", "Bits8", "Bits10", "Bits12", "Bits14", "Bits16", "Abort"];
      for (var j = 0; j < constants.length; ++j)
         if (typeof SubframeSelector[constants[j]] === "undefined") reasons.push("Missing enum " + constants[j]);
   }
   return {
      supported: reasons.length === 0,
      adapter: SM_ADAPTER,
      version: environment.pixInsightVersion,
      weighting: false,
      rejection: false,
      classification: false,
      reasons: reasons
   };
}

function validateSubframeMeasurement(p, id) {
   var keys = [
      "adapter", "jobId", "inputPath", "outputDirectory", "expectedVersion",
      "cameraGain", "cameraResolutionBits", "subframeScale", "scaleUnit",
      "dataUnit", "psfFit", "maxPSFFits"
   ];
   if (Object.keys(p).length !== keys.length)
      throw new Error("Malformed subframe-measurement parameters");
   for (var i = 0; i < keys.length; ++i)
      if (!Object.prototype.hasOwnProperty.call(p, keys[i]))
         throw new Error("Missing subframe-measurement field " + keys[i]);
   if (p.adapter !== SM_ADAPTER || p.expectedVersion !== environment.pixInsightVersion || p.jobId !== id)
      throw new Error("Subframe measurement adapter/version/job mismatch");
   var base = bridgePath + "/jobs/" + id;
   if (p.inputPath !== base + "/input.fits" || p.outputDirectory !== base + "/output")
      throw new Error("Measurement paths must use the job's isolated staging directory");
   if (!(typeof p.cameraGain === "number" && p.cameraGain > 0) ||
       !(typeof p.subframeScale === "number" && p.subframeScale > 0) ||
       [8, 10, 12, 14, 16].indexOf(p.cameraResolutionBits) < 0 ||
       ["PIXEL", "ARCSECONDS"].indexOf(p.scaleUnit) < 0 ||
       ["NORMALIZED", "DATA_NUMBER", "ELECTRON"].indexOf(p.dataUnit) < 0 ||
       ["GAUSSIAN", "MOFFAT4"].indexOf(p.psfFit) < 0 ||
       Math.floor(p.maxPSFFits) !== p.maxPSFFits || p.maxPSFFits <= 0 || p.maxPSFFits > 100000)
      throw new Error("Invalid subframe-measurement parameters");
}

function measurementValue(value, name) {
   var number = Number(value);
   if (!isFinite(number)) throw new Error("Non-finite measurement " + name);
   return number;
}

function measurementRecord(row, allowMissingPsfWeight) {
   return {
      filePath: String(row[3]),
      fwhm: measurementValue(row[5], "FWHM"),
      eccentricity: measurementValue(row[6], "eccentricity"),
      psfSignalWeight: allowMissingPsfWeight === true && !isFinite(Number(row[7])) ?
         null : measurementValue(row[7], "PSFSignalWeight"),
      snrWeightMetric: measurementValue(row[9], "SNRWeight"),
      median: measurementValue(row[10], "median"),
      medianMeanDev: measurementValue(row[11], "medianMeanDev"),
      noise: measurementValue(row[12], "noise"),
      noiseRatio: measurementValue(row[13], "noiseRatio"),
      stars: measurementValue(row[14], "stars"),
      starResidual: measurementValue(row[15], "starResidual"),
      fwhmMeanDev: measurementValue(row[16], "FWHMMeanDev"),
      eccentricityMeanDev: measurementValue(row[17], "eccentricityMeanDev"),
      starResidualMeanDev: measurementValue(row[18], "starResidualMeanDev"),
      psfFlux: measurementValue(row[21], "PSFFlux"),
      psfFluxPower: measurementValue(row[22], "PSFFluxPower"),
      psfTotalMeanFlux: measurementValue(row[23], "PSFTotalMeanFlux"),
      psfTotalMeanPowerFlux: measurementValue(row[24], "PSFTotalMeanPowerFlux"),
      psfCount: measurementValue(row[25], "PSFCount"),
      mStar: measurementValue(row[26], "MStar"),
      nStar: measurementValue(row[27], "NStar"),
      psfSnr: measurementValue(row[28], "PSFSNR"),
      psfScale: measurementValue(row[29], "PSFScale"),
      psfScaleSnr: measurementValue(row[30], "PSFScaleSNR")
   };
}

function measureSubframe(p) {
   var capability = probeSubframeMeasurement();
   if (!capability.supported) throw new Error(capability.reasons.join("; "));
   var reportPath = p.outputDirectory + "/measurements.json";
   var instancePath = p.outputDirectory + "/SubframeSelector.js";
   if (File.exists(reportPath) || File.exists(instancePath))
      throw new Error("Staged measurement output already exists; explicit recovery review required");
   var process = new SubframeSelector;
   process.routine = SubframeSelector.MeasureSubframes;
   process.nonInteractive = true;
   process.subframes = [[true, p.inputPath, "", ""]];
   process.fileCache = false;
   process.subframeScale = p.subframeScale;
   process.cameraGain = p.cameraGain;
   process.cameraResolution = SubframeSelector["Bits" + p.cameraResolutionBits];
   process.scaleUnit = p.scaleUnit === "PIXEL" ? SubframeSelector.Pixel : SubframeSelector.ArcSeconds;
   process.dataUnit = p.dataUnit === "NORMALIZED" ? SubframeSelector.Normalized :
      p.dataUnit === "DATA_NUMBER" ? SubframeSelector.DataNumber : SubframeSelector.Electron;
   process.psfFit = p.psfFit === "GAUSSIAN" ? SubframeSelector.Gaussian : SubframeSelector.Moffat4;
   process.maxPSFFits = p.maxPSFFits;
   process.approvalExpression = "";
   process.weightingExpression = "";
   process.outputKeyword = "";
   process.onError = SubframeSelector.Abort;
   File.writeTextFile(instancePath, process.toSource());
   if (!process.executeGlobal()) throw new Error("SubframeSelector measurement failed");
   var measurements = [];
   for (var i = 0; i < process.measurements.length; ++i)
      measurements.push(measurementRecord(process.measurements[i]));
   if (measurements.length !== 1) throw new Error("Expected exactly one subframe measurement");
   File.writeTextFile(reportPath, JSON.stringify({
      adapter: SM_ADAPTER,
      version: capability.version,
      request: p,
      weightingExpression: "",
      approvalExpression: "",
      measurements: measurements
   }));
   return {
      adapter: SM_ADAPTER,
      reportPath: reportPath,
      processInstancePath: instancePath,
      measurements: measurements
   };
}
