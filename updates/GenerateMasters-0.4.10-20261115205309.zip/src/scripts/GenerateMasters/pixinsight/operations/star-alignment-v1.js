/* Explicit, build-scoped StarAlignment adapter with mandatory drizzle data. */
var SA_ADAPTER = "pixinsight-star-alignment/1";

function probeStarAlignment() {
   var reasons = [];
   if (environment.pixInsightVersion !== "1.9.4.0-1695")
      reasons.push("Build has not passed this StarAlignment contract");
   if (typeof StarAlignment === "undefined")
      reasons.push("StarAlignment unavailable");
   else {
      var p = new StarAlignment;
      var fields = [
         "referenceImage", "referenceIsFile", "targets", "inputHints",
         "outputHints", "mode", "writeKeywords", "generateMasks",
         "generateDrizzleData", "generateDistortionMaps",
         "generateHistoryProperties", "distortionCorrection",
         "pixelInterpolation", "clampingThreshold", "outputDirectory",
         "outputExtension", "outputPrefix", "outputPostfix",
         "outputSampleFormat", "overwriteExistingFiles", "onError",
         "outputData"
      ];
      for (var i = 0; i < fields.length; ++i)
         if (typeof p[fields[i]] === "undefined")
            reasons.push("Missing parameter " + fields[i]);
   }
   return {
      supported: reasons.length === 0,
      adapter: SA_ADAPTER,
      version: environment.pixInsightVersion,
      drizzleData: true,
      distortionCorrection: false,
      outputSampleFormat: "f32",
      reasons: reasons
   };
}

function validateStarAlignment(p, id) {
   var keys = [
      "adapter", "jobId", "referencePath", "inputPath", "outputDirectory",
      "expectedVersion", "generateDrizzleData", "distortionCorrection",
      "pixelInterpolation", "clampingThreshold"
   ];
   if (Object.keys(p).length !== keys.length)
      throw new Error("Malformed StarAlignment parameters");
   for (var i = 0; i < keys.length; ++i)
      if (!Object.prototype.hasOwnProperty.call(p, keys[i]))
         throw new Error("Missing StarAlignment field " + keys[i]);
   if (p.adapter !== SA_ADAPTER ||
       p.expectedVersion !== environment.pixInsightVersion ||
       p.jobId !== id)
      throw new Error("StarAlignment adapter/version/job mismatch");
   var base = bridgePath + "/jobs/" + id;
   if (p.referencePath !== base + "/reference.fits" ||
       p.inputPath !== base + "/input.fits" ||
       p.outputDirectory !== base + "/output")
      throw new Error("StarAlignment paths must use the job's isolated staging directory");
   if (p.generateDrizzleData !== true || p.distortionCorrection !== false ||
       p.pixelInterpolation !== "AUTO")
      throw new Error("StarAlignment v1 fixed contract was changed");
   if (!(typeof p.clampingThreshold === "number" &&
         p.clampingThreshold >= 0 && p.clampingThreshold <= 1))
      throw new Error("Invalid StarAlignment clamping threshold");
}

function starAlignmentExportFits(source, target) {
   if (File.exists(target))
      throw new Error("Registered FITS output already exists");
   var windows = ImageWindow.open(source, "", "", true);
   try {
      if (windows.length !== 1 || windows[0].mainView.image.numberOfChannels !== 1)
         throw new Error("Expected one monochrome registered image");
      if (!windows[0].saveAs(
         target, false, false, true, false,
         "properties fits-keywords no-compress-data no-embedded-data no-resolution"
      ))
         throw new Error("Registered FITS export failed");
   } finally {
      for (var i = 0; i < windows.length; ++i) windows[i].forceClose();
   }
}

function registerStarAligned(p) {
   var capability = probeStarAlignment();
   if (!capability.supported) throw new Error(capability.reasons.join("; "));
   var nativeOutput = p.outputDirectory + "/input_r.xisf";
   var drizzleOutput = p.outputDirectory + "/input_r.xdrz";
   var fitsOutput = p.outputDirectory + "/registered.fits";
   var instancePath = p.outputDirectory + "/StarAlignment.js";
   if (File.exists(nativeOutput) || File.exists(drizzleOutput) ||
       File.exists(fitsOutput) || File.exists(instancePath))
      throw new Error("Staged StarAlignment output already exists; explicit recovery review required");

   var process = new StarAlignment;
   process.structureLayers = 5;
   process.noiseLayers = 0;
   process.hotPixelFilterRadius = 1;
   process.noiseReductionFilterRadius = 0;
   process.minStructureSize = 0;
   process.sensitivity = 0.50;
   process.peakResponse = 0.50;
   process.brightThreshold = 3.00;
   process.maxStarDistortion = 0.60;
   process.allowClusteredSources = false;
   process.localMaximaDetectionLimit = 0.75;
   process.upperLimit = 1.000;
   process.invert = false;
   process.undistortedReference = false;
   process.rigidTransformations = false;
   process.distortionCorrection = false;
   process.matcherTolerance = 0.0500;
   process.ransacTolerance = 1.9000;
   process.ransacMaxIterations = 2000;
   process.ransacMaximizeInliers = 1.00;
   process.ransacMaximizeOverlapping = 1.00;
   process.ransacMaximizeRegularity = 1.00;
   process.ransacMinimizeError = 1.00;
   process.maxStars = 0;
   process.fitPSF = StarAlignment.FitPSF_DistortionOnly;
   process.psfTolerance = 0.50;
   process.useTriangles = false;
   process.polygonSides = 5;
   process.descriptorsPerStar = 20;
   process.restrictToPreviews = true;
   process.intersection = StarAlignment.MosaicOnly;
   process.useBrightnessRelations = false;
   process.useScaleDifferences = false;
   process.scaleTolerance = 0.100;
   process.referenceImage = p.referencePath;
   process.referenceIsFile = true;
   process.targets = [[true, true, p.inputPath]];
   process.targetCSVFilePath = "";
   process.inputHints = "fits-keywords normalize only-first-image raw signed-is-physical";
   process.outputHints = "properties fits-keywords no-compress-data no-embedded-data no-resolution";
   process.mode = StarAlignment.RegisterMatch;
   process.writeKeywords = true;
   process.generateMasks = false;
   process.generateDrizzleData = true;
   process.generateDistortionMaps = false;
   process.generateHistoryProperties = true;
   process.inheritAstrometricSolution = false;
   process.frameAdaptation = false;
   process.randomizeMosaic = false;
   process.pixelInterpolation = StarAlignment.Auto;
   process.clampingThreshold = p.clampingThreshold;
   process.outputDirectory = p.outputDirectory;
   process.outputExtension = ".xisf";
   process.outputPrefix = "";
   process.outputPostfix = "_r";
   process.outputSampleFormat = StarAlignment.f32;
   process.overwriteExistingFiles = false;
   process.onError = StarAlignment.Abort;
   File.writeTextFile(instancePath, process.toSource());
   if (!process.executeGlobal()) throw new Error("StarAlignment failed");
   if (!File.exists(nativeOutput))
      throw new Error("Expected registered native output not produced");
   if (!File.exists(drizzleOutput))
      throw new Error("Expected drizzle-data output not produced");
   if (process.outputData.length !== 1)
      throw new Error("Expected one StarAlignment diagnostic row");
   var row = process.outputData[0];
   if (row[0] !== nativeOutput)
      throw new Error("StarAlignment reported an unexpected output path");
   starAlignmentExportFits(nativeOutput, fitsOutput);
   return {
      adapter: SA_ADAPTER,
      registeredPath: fitsOutput,
      nativeRegisteredPath: nativeOutput,
      drizzlePath: drizzleOutput,
      processInstancePath: instancePath,
      diagnostics: {
         totalPairMatches: Number(row[2]),
         inliers: Number(row[3]),
         overlapping: Number(row[4]),
         regularity: Number(row[5]),
         quality: Number(row[6]),
         rmsError: Number(row[7]),
         rmsErrorDev: Number(row[8]),
         peakErrorX: Number(row[9]),
         peakErrorY: Number(row[10])
      }
   };
}
