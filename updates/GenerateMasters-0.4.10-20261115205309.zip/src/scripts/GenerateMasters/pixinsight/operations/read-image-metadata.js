/* Original implementation. No image windows or pixel arrays are created. */
function readImageMetadata(path) {
   var format = new FileFormat(File.extractExtension(path), true, false);
   var file = new FileFormatInstance(format);
   try {
      var descriptions = file.open(path, "");
      if (!descriptions || descriptions.length === 0)
         throw new Error("No images in file: " + path);
      var images = [];
      for (var i = 0; i < descriptions.length; ++i) {
         var d = descriptions[i];
         images.push({width:d.width, height:d.height, numberOfChannels:d.numberOfChannels, bitsPerSample:d.bitsPerSample});
      }
      var keywords = [];
      if (format.canStoreKeywords) {
         var source = file.keywords;
         for (var j = 0; j < source.length; ++j)
            keywords.push({name:source[j].name, value:source[j].value, comment:source[j].comment});
      }
      return {path:path, images:images, keywords:keywords};
   } finally { if (file.isOpen) file.close(); }
}
