/* Build-scoped, rejection-aware 2x DrizzleIntegration comparison adapter. */
var DI_ADAPTER = "pixinsight-drizzle-integration/1";

function probeDrizzleIntegration() {
   var reasons = [];
   if (environment.pixInsightVersion !== "1.9.4.0-1695")
      reasons.push("Build has not passed this DrizzleIntegration contract");
   if (typeof DrizzleIntegration === "undefined")
      reasons.push("DrizzleIntegration unavailable");
   else {
      var p = new DrizzleIntegration;
      var fields = ["inputData","scale","dropShrink","kernelFunction",
         "enableRejection","enableImageWeighting","enableLocalNormalization",
         "enableCFA","integrationImageId","weightImageId","outputPixels",
         "integratedPixels","totalRejectedLowRK","totalRejectedHighRK","totalData"];
      for (var i = 0; i < fields.length; ++i)
         if (typeof p[fields[i]] === "undefined") reasons.push("Missing parameter " + fields[i]);
      if (typeof DrizzleIntegration.Kernel_Square === "undefined" ||
          typeof DrizzleIntegration.Abort === "undefined")
         reasons.push("Missing required DrizzleIntegration constants");
   }
   return {supported:reasons.length===0,adapter:DI_ADAPTER,
      version:environment.pixInsightVersion,scales:[2],kernels:["SQUARE"],
      rejection:true,weighting:true,cfa:false,reasons:reasons};
}

function validateDrizzleIntegration(p, id) {
   var fields = ["adapter","jobId","inputs","outputDirectory","expectedVersion",
      "scale","dropShrink","kernel","enableRejection","enableImageWeighting",
      "enableLocalNormalization","enableCFA"];
   if (!p || Object.keys(p).length !== fields.length)
      throw new Error("Malformed DrizzleIntegration request");
   for (var k = 0; k < fields.length; ++k)
      if (!Object.prototype.hasOwnProperty.call(p, fields[k]))
         throw new Error("Missing DrizzleIntegration field " + fields[k]);
   var base = bridgePath + "/jobs/" + id;
   if (p.adapter !== DI_ADAPTER || p.jobId !== id ||
       p.expectedVersion !== environment.pixInsightVersion ||
       p.outputDirectory !== base + "/output" ||
       !Array.isArray(p.inputs) || p.inputs.length < 3 ||
       p.scale !== 2 || Math.abs(p.dropShrink-0.9) > 1e-7 ||
       p.kernel !== "SQUARE" || p.enableRejection !== true ||
       p.enableImageWeighting !== true || p.enableLocalNormalization !== false ||
       p.enableCFA !== false)
      throw new Error("DrizzleIntegration v1 contract mismatch");
   for (var i = 0; i < p.inputs.length; ++i)
      if (p.inputs[i] !== base + "/drizzle-" + ("000" + i).slice(-3) + ".xdrz" ||
          !File.exists(p.inputs[i]))
         throw new Error("Missing isolated DrizzleIntegration input");
}

function drizzleSaveWindow(window, path, hints) {
   if (File.exists(path)) throw new Error("Refusing to overwrite staged drizzle output");
   if (!window.saveAs(path, false, false, true, false, hints))
      throw new Error("Unable to save drizzle output " + path);
}

function integrateDrizzle(p) {
   var capability = probeDrizzleIntegration();
   if (!capability.supported) throw new Error(capability.reasons.join("; "));
   var fitsPath = p.outputDirectory + "/drizzled.fits";
   var nativePath = p.outputDirectory + "/drizzled.xisf";
   var weightPath = p.outputDirectory + "/weight.xisf";
   var weightFitsPath = p.outputDirectory + "/weight.fits";
   var instancePath = p.outputDirectory + "/DrizzleIntegration.js";
   var outputPaths = [fitsPath,nativePath,weightPath,weightFitsPath,instancePath];
   for (var n=0; n<outputPaths.length; ++n)
      if (File.exists(outputPaths[n]))
         throw new Error("Staged DrizzleIntegration output already exists; explicit recovery review required");
   var rows = [];
   for (var i=0; i<p.inputs.length; ++i) rows.push([true,p.inputs[i],""]);
   var process = new DrizzleIntegration;
   process.inputData = rows;
   process.inputHints = "fits-keywords normalize only-first-image raw signed-is-physical";
   process.scale = 2;
   process.dropShrink = 0.9;
   process.kernelFunction = DrizzleIntegration.Kernel_Square;
   process.enableCFA = false;
   process.enableRejection = true;
   process.enableImageWeighting = true;
   process.enableLocalNormalization = false;
   process.enableAdaptiveNormalization = false;
   process.useROI = false;
   process.closePreviousImages = false;
   process.useLUT = true;
   process.truncateOnOutOfRange = false;
   process.noGUIMessages = true;
   process.showImages = true;
   process.onError = DrizzleIntegration.Abort;
   File.writeTextFile(instancePath, process.toSource());
   if (!process.executeGlobal()) throw new Error("DrizzleIntegration failed");
   var integrated = ImageWindow.windowById(process.integrationImageId);
   var weight = ImageWindow.windowById(process.weightImageId);
   if (integrated.isNull || weight.isNull)
      throw new Error("Drizzled integration or weight window missing");
   drizzleSaveWindow(integrated, nativePath, "properties fits-keywords no-compress-data");
   drizzleSaveWindow(integrated, fitsPath, "fits-keywords no-compress-data");
   drizzleSaveWindow(weight, weightPath, "properties no-compress-data");
   drizzleSaveWindow(weight, weightFitsPath, "fits-keywords no-compress-data");
   integrated.forceClose(); weight.forceClose();
   function number(v) { return typeof v === "bigint" ? Number(v) : Number(v); }
   return {adapter:DI_ADAPTER,integratedPath:fitsPath,nativeIntegratedPath:nativePath,
      weightMapPath:weightFitsPath,nativeWeightMapPath:weightPath,
      processInstancePath:instancePath,
      statistics:{outputPixels:number(process.outputPixels),
         integratedPixels:number(process.integratedPixels),
         totalRejectedLow:number(process.totalRejectedLowRK),
         totalRejectedHigh:number(process.totalRejectedHighRK),
         totalData:number(process.totalData)}};
}
