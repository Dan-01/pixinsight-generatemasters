/* Explicit, build-scoped ImageIntegration adapter with external policy inputs. */
var II_ADAPTER = "pixinsight-image-integration/2";

function probeImageIntegration() {
   var reasons = [];
   if (environment.pixInsightVersion !== "1.9.4.0-1695")
      reasons.push("Build has not passed this ImageIntegration contract");
   if (typeof ImageIntegration === "undefined")
      reasons.push("ImageIntegration unavailable");
   else {
      var p = new ImageIntegration;
      var fields = [
         "images", "combination", "weightMode", "normalization", "rejection",
         "rejectionNormalization", "generateRejectionMaps", "generateSlopeMaps",
         "generateIntegratedImage", "integrationImageId", "lowRejectionMapImageId",
         "highRejectionMapImageId", "numberOfImages", "imageData"
      ];
      for (var i = 0; i < fields.length; ++i)
         if (typeof p[fields[i]] === "undefined")
            reasons.push("Missing parameter " + fields[i]);
   }
   return {
      supported: reasons.length === 0,
      adapter: II_ADAPTER,
      version: environment.pixInsightVersion,
      combinations: ["AVERAGE"],
      weightModes: ["EQUAL", "PSF_SIGNAL"],
      normalizations: ["ADDITIVE_WITH_SCALING", "LOCAL_NORMALIZATION"],
      rejections: ["NONE", "WINSORIZED_SIGMA", "ESD"],
      rejectionMaps: true,
      slopeMaps: false,
      reasons: reasons
   };
}

function probeImageIntegrationDrizzle() {
   var result = probeImageIntegration();
   result.adapter = "pixinsight-image-integration/3";
   result.drizzleData = true;
   result.rejections = ["WINSORIZED_SIGMA", "ESD"];
   if (typeof ImageIntegration !== "undefined" &&
       typeof (new ImageIntegration).generateDrizzleData === "undefined")
      result.reasons.push("Missing generateDrizzleData parameter");
   result.supported = result.reasons.length === 0;
   return result;
}

function validateImageIntegration(p, id) {
   var keys = [
      "adapter", "jobId", "inputs", "outputDirectory", "expectedVersion",
      "combination", "weightMode", "normalization", "rejection", "sigmaLow",
      "sigmaHigh", "generateRejectionMaps", "generateSlopeMap"
   ];
   if (Object.keys(p).length !== keys.length + (p.adapter === "pixinsight-image-integration/3" ? 1 : 0))
      throw new Error("Malformed ImageIntegration parameters");
   for (var i = 0; i < keys.length; ++i)
      if (!Object.prototype.hasOwnProperty.call(p, keys[i]))
         throw new Error("Missing ImageIntegration field " + keys[i]);
   var drizzle = p.adapter === "pixinsight-image-integration/3";
   if (["pixinsight-image-integration/1", II_ADAPTER, "pixinsight-image-integration/3"].indexOf(p.adapter) < 0 ||
       p.expectedVersion !== environment.pixInsightVersion || p.jobId !== id)
      throw new Error("ImageIntegration adapter/version/job mismatch");
   var base = bridgePath + "/jobs/" + id;
   if (p.outputDirectory !== base + "/output" || !Array.isArray(p.inputs) || p.inputs.length < 3)
      throw new Error("ImageIntegration requires at least three isolated inputs");
   var seen = {};
   for (var j = 0; j < p.inputs.length; ++j) {
      var input = p.inputs[j];
      var index = ("000" + j).slice(-3);
      if (!input || Object.keys(input).length !== (drizzle ? 3 : 2) ||
          input.path !== base + "/input-" + index + ".fits" || seen[input.path])
         throw new Error("Invalid ImageIntegration input row");
      if (drizzle && input.drizzleDataPath !== base + "/drizzle-" + index + ".xdrz")
         throw new Error("Invalid isolated drizzle row");
      seen[input.path] = true;
      var expectedXNML = base + "/normalization-" + index + ".xnml";
      if (p.normalization === "LOCAL_NORMALIZATION") {
         if (input.localNormalizationDataPath !== expectedXNML)
            throw new Error("Missing isolated XNML input");
      } else if (input.localNormalizationDataPath !== null)
         throw new Error("Unexpected XNML input");
   }
   if (p.combination !== "AVERAGE" || ["EQUAL", "PSF_SIGNAL"].indexOf(p.weightMode) < 0 ||
       (p.adapter === "pixinsight-image-integration/1" && p.weightMode !== "EQUAL") ||
       ["ADDITIVE_WITH_SCALING", "LOCAL_NORMALIZATION"].indexOf(p.normalization) < 0 ||
       ["NONE", "WINSORIZED_SIGMA", "ESD"].indexOf(p.rejection) < 0 ||
       !(typeof p.sigmaLow === "number" && p.sigmaLow > 0) ||
       !(typeof p.sigmaHigh === "number" && p.sigmaHigh > 0) ||
       p.generateRejectionMaps !== (p.rejection !== "NONE") || p.generateSlopeMap !== false)
      throw new Error("ImageIntegration v1 contract was changed");
   if (drizzle && (p.generateDrizzleData !== true || p.rejection === "NONE" || Object.keys(p).length !== keys.length + 1))
      throw new Error("ImageIntegration v3 requires rejection-aware drizzle generation");
   if (!drizzle && p.generateDrizzleData !== undefined)
      throw new Error("Legacy ImageIntegration cannot generate drizzle data");
}

function integrationSaveWindow(window, path, hints) {
   if (File.exists(path)) throw new Error("Refusing to overwrite staged integration output");
   if (!window.saveAs(path, false, false, true, false, hints))
      throw new Error("Unable to save integration output " + path);
}

function integrationStatistic(value) {
   return typeof value === "bigint" ? Number(value) : value;
}

function integrationWeights(process) {
   var weights = [];
   for (var i = 0; i < process.imageData.length; ++i)
      weights.push(Number(process.imageData[i][0]));
   return weights;
}

function integrateImages(p) {
   var capability = p.adapter === "pixinsight-image-integration/3"
      ? probeImageIntegrationDrizzle() : probeImageIntegration();
   if (!capability.supported) throw new Error(capability.reasons.join("; "));
   var nativePath = p.outputDirectory + "/integrated.xisf";
   var fitsPath = p.outputDirectory + "/integrated.fits";
   var lowPath = p.outputDirectory + "/rejection-low.xisf";
   var highPath = p.outputDirectory + "/rejection-high.xisf";
   var instancePath = p.outputDirectory + "/ImageIntegration.js";
   var known = [nativePath, fitsPath, lowPath, highPath, instancePath];
   for (var e = 0; e < known.length; ++e)
      if (File.exists(known[e]))
         throw new Error("Staged ImageIntegration output already exists; explicit recovery review required");

   var rows = [];
   for (var i = 0; i < p.inputs.length; ++i)
      rows.push([true, p.inputs[i].path, p.inputs[i].drizzleDataPath || "", p.inputs[i].localNormalizationDataPath || ""]);
   var process = new ImageIntegration;
   process.images = rows;
   process.inputHints = "fits-keywords normalize only-first-image raw signed-is-physical";
   process.combination = ImageIntegration.Average;
   process.weightMode = p.weightMode === "PSF_SIGNAL"
      ? ImageIntegration.PSFSignalWeight
      : ImageIntegration.DontCare;
   process.weightScale = ImageIntegration.WeightScale_BWMV;
   process.weightOvershootProtection = false;
   process.minWeight = 0.005;
   process.normalization = p.normalization === "LOCAL_NORMALIZATION"
      ? ImageIntegration.LocalNormalization
      : ImageIntegration.AdditiveWithScaling;
   process.rejection = p.rejection === "NONE"
      ? ImageIntegration.NoRejection
      : p.rejection === "ESD"
         ? ImageIntegration.Rejection_ESD
         : ImageIntegration.WinsorizedSigmaClip;
   process.rejectionNormalization = p.normalization === "LOCAL_NORMALIZATION"
      ? ImageIntegration.LocalRejectionNormalization
      : ImageIntegration.Scale;
   process.sigmaLow = p.sigmaLow;
   process.sigmaHigh = p.sigmaHigh;
   process.winsorizationCutoff = 5.00;
   process.esdOutliersFraction = 0.30;
   process.esdAlpha = 0.05;
   process.esdLowRelaxation = 1.00;
   process.clipLow = true;
   process.clipHigh = true;
   process.rangeClipLow = false;
   process.rangeClipHigh = false;
   process.generate64BitResult = false;
   process.generateRejectionMaps = p.generateRejectionMaps;
   process.generateSlopeMaps = false;
   process.generateIntegratedImage = true;
   process.generateDrizzleData = p.adapter === "pixinsight-image-integration/3";
   process.closePreviousImages = false;
   process.useCache = false;
   process.evaluateSNR = true;
   process.psfStructureLayers = 5;
   process.psfType = ImageIntegration.PSFType_Moffat4;
   process.generateFITSKeywords = true;
   process.truncateOnOutOfRange = false;
   process.noGUIMessages = true;
   process.showImages = true;
   File.writeTextFile(instancePath, process.toSource());
   if (!process.executeGlobal()) throw new Error("ImageIntegration failed");
   var integrated = ImageWindow.windowById(process.integrationImageId);
   if (integrated.isNull) throw new Error("Integrated image window is unavailable");
   integrationSaveWindow(integrated, nativePath, "properties fits-keywords no-compress-data");
   integrationSaveWindow(integrated, fitsPath, "fits-keywords no-compress-data");
   integrated.forceClose();

   var lowResult = null, highResult = null;
   if (p.generateRejectionMaps) {
      var low = ImageWindow.windowById(process.lowRejectionMapImageId);
      var high = ImageWindow.windowById(process.highRejectionMapImageId);
      if (low.isNull || high.isNull)
         throw new Error("Requested rejection maps were not generated");
      integrationSaveWindow(low, lowPath, "properties no-compress-data");
      integrationSaveWindow(high, highPath, "properties no-compress-data");
      low.forceClose(); high.forceClose();
      lowResult = lowPath; highResult = highPath;
   }
   var response = {
      adapter: p.adapter,
      integratedPath: fitsPath,
      nativeIntegratedPath: nativePath,
      lowRejectionMapPath: lowResult,
      highRejectionMapPath: highResult,
      slopeMapPath: null,
      processInstancePath: instancePath,
      statistics: {
         numberOfImages: integrationStatistic(process.numberOfImages),
         numberOfPixels: integrationStatistic(process.numberOfPixels),
         totalRejectedLow: integrationStatistic(process.totalRejectedLowRK),
         totalRejectedHigh: integrationStatistic(process.totalRejectedHighRK),
         finalNoiseEstimate: Number(process.finalNoiseEstimateRK),
         finalScaleEstimate: Number(process.finalScaleEstimateRK),
         finalLocationEstimate: Number(process.finalLocationEstimateRK),
         referenceNoiseReduction: Number(process.referenceNoiseReductionRK),
         medianNoiseReduction: Number(process.medianNoiseReductionRK),
         imageWeights: integrationWeights(process)
      }
   };
   if (p.adapter === "pixinsight-image-integration/3") {
      response.drizzleDataPaths = [];
      for (var d = 0; d < p.inputs.length; ++d) {
         if (!File.exists(p.inputs[d].drizzleDataPath))
            throw new Error("Updated drizzle data is missing");
         response.drizzleDataPaths.push(p.inputs[d].drizzleDataPath);
      }
   }
   return response;
}
