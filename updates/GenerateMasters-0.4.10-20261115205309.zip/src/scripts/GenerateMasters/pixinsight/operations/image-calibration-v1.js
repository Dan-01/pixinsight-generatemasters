/* Version adapter: parameters live here, never in application business logic. */
var IC_ADAPTER = "pixinsight-image-calibration/1";
function probeCalibration() {
   var reasons = [];
   // Only this build has a live contract. Add builds after running the opt-in suite.
   if (environment.pixInsightVersion !== "1.9.4.0-1695") reasons.push("Build has not passed this adapter's contract");
   if (typeof ImageCalibration === "undefined") reasons.push("ImageCalibration unavailable");
   else {
      var p = new ImageCalibration;
      var fields = ["targetFrames","masterBiasEnabled","masterBiasPath","masterDarkEnabled","masterDarkPath","masterFlatEnabled","masterFlatPath","calibrateBias","calibrateDark","calibrateFlat","optimizeDarks","enableCFA","overscanEnabled","outputDirectory","outputExtension","outputPrefix","outputPostfix","outputSampleFormat","overwriteExistingFiles","outputPedestal","outputPedestalMode","evaluateNoise","evaluateSignal","cosmeticCorrectionHigh"];
      for(var i=0;i<fields.length;++i) if(typeof p[fields[i]] === "undefined") reasons.push("Missing parameter " + fields[i]);
      if(typeof ImageCalibration.f32 === "undefined" || typeof ImageCalibration.OutputPedestal_Literal === "undefined") reasons.push("Missing output format/pedestal enum");
   }
   return {supported:reasons.length===0,adapter:IC_ADAPTER,version:environment.pixInsightVersion,darkScaling:false,reasons:reasons};
}
function validateCalibration(p, id) {
   var keys=["adapter","jobId","inputPath","darkPath","flatPath","biasPath","outputDirectory","expectedVersion","outputPedestal"];
   if(Object.keys(p).length!==keys.length)throw new Error("Malformed calibration parameters");
   for(var i=0;i<keys.length;++i)if(!Object.prototype.hasOwnProperty.call(p,keys[i]))throw new Error("Missing calibration field");
   if(p.adapter!==IC_ADAPTER||p.expectedVersion!==environment.pixInsightVersion||p.jobId!==id)throw new Error("Calibration adapter/version/job mismatch");
   var base=bridgePath+"/jobs/"+id;
   if(p.inputPath!==base+"/light.fits"||p.darkPath!==base+"/dark.fits"||p.flatPath!==base+"/flat.fits"||(p.biasPath!==null&&p.biasPath!==base+"/bias.fits")||p.outputDirectory!==base+"/output")throw new Error("Calibration paths must use the job's isolated staging directory");
   if(typeof p.outputPedestal!=="number"||p.outputPedestal<0||p.outputPedestal>65535||Math.floor(p.outputPedestal)!==p.outputPedestal)throw new Error("Invalid output pedestal");
}
function convertCalibrationFile(source,target) {
   if(File.exists(target))throw new Error("Conversion output already exists: "+target);
   var windows=ImageWindow.open(source,"","fits-keywords normalize only-first-image raw signed-is-physical",true);
   try {
      if(windows.length!==1)throw new Error("Expected one monochrome image");
      if(windows[0].mainView.image.numberOfChannels!==1)throw new Error("Only monochrome calibration is supported");
      if(!windows[0].saveAs(target,false,false,true,false,"properties fits-keywords no-compress-data"))throw new Error("Format conversion failed");
   } finally {for(var i=0;i<windows.length;++i)windows[i].forceClose();}
}
function calibrateImage(p) {
   var capability=probeCalibration();if(!capability.supported)throw new Error(capability.reasons.join("; "));
   var output=p.outputDirectory+"/light_c.fits";
   if(File.exists(output))throw new Error("Staged output already exists; explicit recovery review required");
   var nativeDirectory=p.outputDirectory+"/native";
   if(!File.directoryExists(nativeDirectory))File.createDirectory(nativeDirectory,true);
   var nativeLight=nativeDirectory+"/light.xisf",nativeDark=nativeDirectory+"/dark.xisf",nativeFlat=nativeDirectory+"/flat.xisf",nativeBias=nativeDirectory+"/bias.xisf";
   convertCalibrationFile(p.inputPath,nativeLight);
   convertCalibrationFile(p.darkPath,nativeDark);
   convertCalibrationFile(p.flatPath,nativeFlat);
   if(p.biasPath!==null)convertCalibrationFile(p.biasPath,nativeBias);
   var process = new ImageCalibration;
   process.targetFrames=[[true,nativeLight]];
   process.enableCFA=false;process.overscanEnabled=false;
   process.masterBiasEnabled=p.biasPath!==null;process.masterBiasPath=p.biasPath!==null?nativeBias:"";
   process.masterDarkEnabled=true;process.masterDarkPath=nativeDark;
   process.masterFlatEnabled=true;process.masterFlatPath=nativeFlat;
   process.calibrateBias=false;process.calibrateDark=false;process.calibrateFlat=false;
   process.optimizeDarks=false;process.separateCFAFlatScalingFactors=false;
   process.pedestal=0;process.pedestalMode=ImageCalibration.Keyword;process.pedestalKeyword="";
   process.inputHints="fits-keywords normalize only-first-image raw signed-is-physical";
   process.outputHints="properties fits-keywords no-compress-data no-embedded-data no-resolution";
   process.cosmeticCorrectionLow=false;process.cosmeticShowMap=false;process.cosmeticShowMapAndStop=false;
   process.generateHistoryProperties=true;process.generateFITSKeywords=true;
   process.evaluateNoise=false;process.evaluateSignal=false;process.cosmeticCorrectionHigh=false;
   process.outputDirectory=p.outputDirectory;process.outputExtension=".xisf";
   process.outputPrefix="";process.outputPostfix="_c";process.outputSampleFormat=ImageCalibration.f32;
   process.outputPedestal=p.outputPedestal;process.outputPedestalMode=ImageCalibration.OutputPedestal_Literal;
   process.overwriteExistingFiles=false;
   process.flatScaleClippingFactor=0.05;
   File.writeTextFile(p.outputDirectory+"/ImageCalibration.js",process.toSource());
   if(!process.executeGlobal())throw new Error("ImageCalibration failed");
   convertCalibrationFile(p.outputDirectory+"/light_c.xisf",output);
   if(!File.exists(output))throw new Error("Expected calibrated output not produced");
   var intermediates=[{path:nativeLight,role:"LIGHT"},{path:nativeDark,role:"DARK"},{path:nativeFlat,role:"FLAT"},{path:p.outputDirectory+"/light_c.xisf",role:"NATIVE_OUTPUT"},{path:p.outputDirectory+"/ImageCalibration.js",role:"PROCESS_INSTANCE"}];
   if(p.biasPath!==null)intermediates.push({path:nativeBias,role:"BIAS"});
   return {outputPath:output,adapter:IC_ADAPTER,intermediates:intermediates};
}
