#ifndef DANASTROPHOTO_PROTOCOL_VERSIONS
#define DANASTROPHOTO_PROTOCOL_VERSIONS
#include "../includes/protocol-versions.jsh"
#endif
#include "one-run-drizzle.js"
/* Fast, isolated batch stages with native capability gates. */
var OR_ADAPTER = ONE_RUN_ADAPTER;

function probeOneRun() {
   var reasons = [];
   var types = [
      ["ImageCalibration", typeof ImageCalibration === "undefined" ? null : ImageCalibration,
         ["targetFrames", "masterDarkPath", "masterFlatPath", "optimizeDarks",
          "outputDirectory", "outputSampleFormat", "overwriteExistingFiles"]],
      ["StarAlignment", typeof StarAlignment === "undefined" ? null : StarAlignment,
         ["referenceImage", "targets", "outputDirectory", "outputSampleFormat",
          "generateDrizzleData", "overwriteExistingFiles", "outputData"]],
      ["ImageIntegration", typeof ImageIntegration === "undefined" ? null : ImageIntegration,
         ["images", "normalization", "rejection", "generateRejectionMaps",
          "generateIntegratedImage", "numberOfImages", "totalRejectedLowRK",
          "totalRejectedHighRK", "finalNoiseEstimateRK", "finalScaleEstimateRK",
          "finalLocationEstimateRK", "referenceNoiseReductionRK",
          "medianNoiseReductionRK"]]
   ];
   for (var i = 0; i < types.length; ++i) {
      if (!types[i][1]) { reasons.push(types[i][0] + " unavailable"); continue; }
      try {
         var instance = new types[i][1];
         if (typeof instance.executeGlobal !== "function" || typeof instance.toSource !== "function")
            reasons.push(types[i][0] + " lacks executable process contract");
         for (var j = 0; j < types[i][2].length; ++j)
            if (!(types[i][2][j] in instance))
               reasons.push(types[i][0] + " missing " + types[i][2][j]);
      } catch (error) { reasons.push(types[i][0] + ": " + String(error)); }
   }
   if (typeof ImageCalibration !== "undefined" &&
       (typeof ImageCalibration.f32 === "undefined" ||
        typeof ImageCalibration.OutputPedestal_Literal === "undefined"))
      reasons.push("ImageCalibration output constants unavailable");
   if (typeof StarAlignment !== "undefined" && typeof StarAlignment.f32 === "undefined")
      reasons.push("StarAlignment Float32 output unavailable");
   if (typeof ImageIntegration !== "undefined" &&
       (typeof ImageIntegration.Rejection_ESD === "undefined" ||
        typeof ImageIntegration.WinsorizedSigmaClip === "undefined" ||
        typeof ImageIntegration.PSFSignalWeight === "undefined" ||
        typeof ImageIntegration.LocalNormalization === "undefined" ||
        typeof ImageIntegration.LocalRejectionNormalization === "undefined" ||
        typeof ImageIntegration.AdditiveWithScaling === "undefined"))
      reasons.push("ImageIntegration recipe constants unavailable");
   var preparation = probeMasterPreparation();
   var measurement = probeOneRunMeasurement();
   var local = probeLocalNormalization();
   var drizzle = oneRunDrizzleCapability();
   return { supported: reasons.length === 0, adapter: OR_ADAPTER,
      version: environment.pixInsightVersion,
      masterPreparationSupported: preparation.supported,
      subframeMeasurementSupported: measurement.supported,
      subframeMeasurementReasons: measurement.reasons,
      localNormalizationSupported: local.supported,
      localNormalizationReasons: local.reasons,
      darkFlatExposureApprovalSupported: true,
      savedMasterDarkReuseSupported: true,
      drizzleSupported: drizzle.supported,
      drizzleReasons: drizzle.reasons,
      reasons: reasons.concat(preparation.supported ? [] : preparation.reasons) };
}

function validateOneRunStage(p, id) {
   if (!p || Object.keys(p).length !== 3 ||
       p.adapter !== OR_ADAPTER || p.jobId !== id ||
       p.requestPath !== bridgePath + "/jobs/" + id + "/request.json")
      throw new Error("Malformed one-run stage request");
}

function oneRunSave(window, path, hints) {
   if (File.exists(path)) throw new Error("Refusing to overwrite " + path);
   if (!window.saveAs(path, false, false, true, false, hints))
      throw new Error("Unable to save " + path);
}

function oneRunRequireInputs(request) {
   if (!request || request.adapter !== OR_ADAPTER ||
       request.expectedVersion !== environment.pixInsightVersion)
      throw new Error("One-run adapter/version mismatch");
   var capability = probeOneRun();
   if (!capability.supported ||
       (request.stage === "PREPARE_MASTERS" && !capability.masterPreparationSupported))
      throw new Error("One-run native capabilities unavailable: " + capability.reasons.join("; "));
   if (!Array.isArray(request.inputs) || request.inputs.length < 1)
      throw new Error("One-run stage has no inputs");
   for (var i = 0; i < request.inputs.length; ++i)
      if (typeof request.inputs[i] !== "string" ||
          request.inputs[i].charAt(0) !== "/" ||
          !File.exists(request.inputs[i]))
         throw new Error("One-run input is missing: " + request.inputs[i]);
}

function oneRunCalibrate(request) {
   if (typeof ImageCalibration === "undefined")
      throw new Error("ImageCalibration unavailable");
   if (!request.darkPath || !File.exists(request.darkPath) ||
       !request.flatPath || !File.exists(request.flatPath))
      throw new Error("Calibration masters are missing");
   var process = new ImageCalibration;
   process.targetFrames = request.inputs.map(function(path) { return [true, path]; });
   process.enableCFA = false;
   process.overscanEnabled = false;
   process.masterBiasEnabled = false;
   process.masterBiasPath = "";
   process.masterDarkEnabled = true;
   process.masterDarkPath = request.darkPath;
   process.masterFlatEnabled = true;
   process.masterFlatPath = request.flatPath;
   process.calibrateBias = false;
   process.calibrateDark = false;
   process.calibrateFlat = false;
   process.optimizeDarks = false;
   process.separateCFAFlatScalingFactors = false;
   process.pedestal = 0;
   process.pedestalMode = ImageCalibration.Keyword;
   process.pedestalKeyword = "";
   process.inputHints = "fits-keywords normalize only-first-image raw signed-is-physical";
   process.outputHints = "properties fits-keywords no-compress-data no-embedded-data no-resolution";
   process.cosmeticCorrectionLow = false;
   process.cosmeticCorrectionHigh = false;
   process.cosmeticShowMap = false;
   process.cosmeticShowMapAndStop = false;
   process.generateHistoryProperties = true;
   process.generateFITSKeywords = true;
   process.evaluateNoise = false;
   process.evaluateSignal = false;
   process.outputDirectory = request.outputDirectory;
   process.outputExtension = ".xisf";
   process.outputPrefix = "";
   process.outputPostfix = "_c";
   process.outputSampleFormat = ImageCalibration.f32;
   process.outputPedestal = 0;
   process.outputPedestalMode = ImageCalibration.OutputPedestal_Literal;
   process.overwriteExistingFiles = false;
   process.flatScaleClippingFactor = 0.05;
   var instance = request.outputDirectory + "/ImageCalibration.js";
   File.writeTextFile(instance, process.toSource());
   if (!process.executeGlobal()) throw new Error("Batch ImageCalibration failed");
   var outputs = request.inputs.map(function(path) {
      var name = File.extractName(path);
      return request.outputDirectory + "/" + name + "_c.xisf";
   });
   for (var i = 0; i < outputs.length; ++i)
      if (!File.exists(outputs[i])) throw new Error("Missing calibrated output " + outputs[i]);
   return { outputs: outputs, processInstancePath: instance };
}

function oneRunAlign(request) {
   if (typeof StarAlignment === "undefined") throw new Error("StarAlignment unavailable");
   if (!request.referencePath || !File.exists(request.referencePath))
      throw new Error("Registration reference is missing");
   var process = new StarAlignment;
   process.structureLayers = 5;
   process.noiseLayers = 0;
   process.hotPixelFilterRadius = 1;
   process.noiseReductionFilterRadius = 0;
   process.minStructureSize = 0;
   process.sensitivity = 0.50;
   process.peakResponse = 0.50;
   process.brightThreshold = 3.00;
   process.maxStarDistortion = 0.60;
   process.allowClusteredSources = false;
   process.localMaximaDetectionLimit = 0.75;
   process.upperLimit = 1.000;
   process.invert = false;
   process.undistortedReference = false;
   process.rigidTransformations = false;
   process.distortionCorrection = false;
   process.matcherTolerance = 0.0500;
   process.ransacTolerance = 1.9000;
   process.ransacMaxIterations = 2000;
   process.ransacMaximizeInliers = 1.00;
   process.ransacMaximizeOverlapping = 1.00;
   process.ransacMaximizeRegularity = 1.00;
   process.ransacMinimizeError = 1.00;
   process.maxStars = 0;
   process.fitPSF = StarAlignment.FitPSF_DistortionOnly;
   process.psfTolerance = 0.50;
   process.useTriangles = false;
   process.polygonSides = 5;
   process.descriptorsPerStar = 20;
   process.restrictToPreviews = true;
   process.intersection = StarAlignment.MosaicOnly;
   process.useBrightnessRelations = false;
   process.useScaleDifferences = false;
   process.scaleTolerance = 0.100;
   process.referenceImage = request.referencePath;
   process.referenceIsFile = true;
   process.targets = request.inputs.map(function(path) { return [true, true, path]; });
   process.targetCSVFilePath = "";
   process.inputHints = "properties fits-keywords no-compress-data";
   process.outputHints = "properties fits-keywords no-compress-data no-embedded-data no-resolution";
   process.mode = StarAlignment.RegisterMatch;
   process.writeKeywords = true;
   process.generateMasks = false;
   process.generateDrizzleData = Boolean(request.drizzle);
   process.generateDistortionMaps = false;
   process.generateHistoryProperties = true;
   process.inheritAstrometricSolution = false;
   process.frameAdaptation = false;
   process.randomizeMosaic = false;
   process.pixelInterpolation = StarAlignment.Auto;
   process.clampingThreshold = 0.3;
   process.outputDirectory = request.outputDirectory;
   process.outputExtension = ".xisf";
   process.outputPrefix = "";
   process.outputPostfix = "_r";
   process.outputSampleFormat = StarAlignment.f32;
   process.overwriteExistingFiles = false;
   process.onError = StarAlignment.Continue;
   var instance = request.outputDirectory + "/StarAlignment.js";
   File.writeTextFile(instance, process.toSource());
   if (!process.executeGlobal()) throw new Error("Batch StarAlignment failed");
   var outputs = request.inputs.map(function(path) {
      var name = File.extractName(path);
      return request.outputDirectory + "/" + name + "_r.xisf";
   });
   var succeeded = [], failed = [];
   for (var i = 0; i < outputs.length; ++i)
      (File.exists(outputs[i]) ? succeeded : failed).push(outputs[i]);
   if (!succeeded.length) throw new Error("StarAlignment produced no registered lights");
   var rows = {};
   for (var j = 0; j < process.outputData.length; ++j) {
      var row = process.outputData[j], path = String(row[0]);
      if (succeeded.indexOf(path) < 0) continue;
      if (rows[path]) throw new Error("Duplicate StarAlignment diagnostic path");
      var diagnostics = { totalPairMatches: Number(row[2]),
         inliers: Number(row[3]), overlapping: Number(row[4]),
         regularity: Number(row[5]), quality: Number(row[6]),
         rmsError: Number(row[7]), rmsErrorDev: Number(row[8]),
         peakErrorX: Number(row[9]), peakErrorY: Number(row[10]) };
      for (var key in diagnostics)
         if (!isFinite(diagnostics[key]))
            throw new Error("Invalid StarAlignment diagnostic " + key);
      rows[path] = diagnostics;
   }
   var alignments = outputs.map(function(path, index) {
      if (succeeded.indexOf(path) >= 0 && !rows[path])
         throw new Error("Missing StarAlignment diagnostics for " + path);
      return { inputPath: request.inputs[index], outputPath: path,
         succeeded: succeeded.indexOf(path) >= 0,
         diagnostics: rows[path] || null };
   });
   var result = { outputs: succeeded, failed: failed, alignments: alignments,
      processInstancePath: instance };
   if (request.drizzle) result.drizzleDataPaths = succeeded.map(function(path) {
      var dataPath = path.replace(/\.xisf$/i, ".xdrz");
      if (!File.exists(dataPath)) throw new Error("Missing alignment drizzle data: " + dataPath);
      return dataPath;
   });
   return result;
}

function oneRunMeasure(request) {
   var capability = probeOneRunMeasurement();
   if (!capability.supported)
      throw new Error("Subframe measurement unavailable: " + capability.reasons.join("; "));
   if (!(typeof request.cameraGain === "number" && request.cameraGain > 0))
      throw new Error("Subframe measurement requires a positive camera conversion gain");
   var modern = oneRunUsesImageAnalysis();
   var measured;
   if (modern) measured = oneRunMeasureImageAnalysis(request);
   else measured = oneRunMeasureLegacy(request);
   var measurements = measured.measurements;
   if (measurements.length !== request.inputs.length)
      throw new Error("Measurement engine returned an incomplete measurement set");
   var byPath = {};
   for (var i = 0; i < measurements.length; ++i) {
      var path = measurements[i].filePath;
      if (byPath[path] || request.inputs.indexOf(path) < 0)
         throw new Error("Measurement engine returned an unexpected or duplicate measured path");
      byPath[path] = measurements[i];
   }
   var ordered = request.inputs.map(function(path) { return byPath[path]; });
   var reportPath = request.outputDirectory + "/measurements.json";
   File.writeTextFile(reportPath, JSON.stringify({ adapter: OR_ADAPTER,
      pixInsightVersion: capability.version, inputs: request.inputs,
      measurements: ordered }));
   return { outputs: [reportPath], measurements: ordered,
      processInstancePath: measured.processInstancePath };
}

function oneRunMeasureLegacy(request) {
   var process = new SubframeSelector;
   process.routine = SubframeSelector.MeasureSubframes;
   process.nonInteractive = true;
   process.subframes = request.inputs.map(function(path) { return [true, path, "", ""]; });
   process.fileCache = false;
   process.subframeScale = 1;
   process.cameraGain = request.cameraGain;
   process.cameraResolution = SubframeSelector.Bits16;
   process.scaleUnit = SubframeSelector.Pixel;
   process.dataUnit = SubframeSelector.Normalized;
   process.psfFit = SubframeSelector.Moffat4;
   process.maxPSFFits = 20000;
   process.approvalExpression = "";
   process.weightingExpression = "";
   process.outputKeyword = "";
   process.onError = SubframeSelector.Abort;
   var instancePath = request.outputDirectory + "/SubframeSelector.js";
   File.writeTextFile(instancePath, process.toSource());
   if (!process.executeGlobal()) throw new Error("Batch SubframeSelector measurement failed");
   var measurements = process.measurements.map(function(row) {
      var record = measurementRecord(row, true);
      record.unavailableMetrics = record.psfSignalWeight === null ? ["psfSignalWeight"] : [];
      return record;
   });
   return { measurements: measurements, processInstancePath: instancePath };
}

function oneRunNormalize(request) {
   var capability = probeLocalNormalization();
   if (!capability.supported)
      throw new Error("LocalNormalization unavailable: " + capability.reasons.join("; "));
   if (!request.referencePath || !File.exists(request.referencePath) ||
       !(request.scale >= 128 && request.scale <= 4096 && Math.floor(request.scale) === request.scale))
      throw new Error("LocalNormalization needs a registered reference and 128–4096 pixel scale");
   var paths = [], instances = [];
   for (var i = 0; i < request.inputs.length; ++i) {
      var process = new LocalNormalization;
      process.scale = request.scale;
      process.noScale = false;
      process.globalLocationNormalization = false;
      process.truncate = true;
      process.backgroundSamplingDelta = 32;
      process.rejection = true;
      process.referenceRejection = false;
      process.lowClippingLevel = 0.000045;
      process.highClippingLevel = 0.85;
      process.referenceRejectionThreshold = 3.00;
      process.targetRejectionThreshold = 3.20;
      process.hotPixelFilterRadius = 2;
      process.noiseReductionFilterRadius = 0;
      process.modelScalingFactor = 8.00;
      process.scaleEvaluationMethod = LocalNormalization.ScaleEvaluationMethod_PSFSignal;
      process.localScaleCorrections = false;
      process.psfStructureLayers = 5;
      process.saturationThreshold = 0.75;
      process.saturationRelative = true;
      process.rejectionLimit = 0.30;
      process.psfNoiseLayers = 1;
      process.psfHotPixelFilterRadius = 1;
      process.psfNoiseReductionFilterRadius = 0;
      process.psfMinStructureSize = 0;
      process.psfMinSNR = 40.00;
      process.psfAllowClusteredSources = true;
      process.psfType = LocalNormalization.PSFType_Auto;
      process.psfGrowth = 1.00;
      process.psfMaxStars = 24576;
      process.referencePathOrViewId = request.referencePath;
      process.referenceIsView = false;
      process.targetItems = [[true, request.inputs[i]]];
      process.inputHints = "properties fits-keywords no-compress-data";
      process.outputHints = "properties fits-keywords no-compress-data no-embedded-data no-resolution";
      process.generateNormalizedImages = LocalNormalization.GenerateNormalizedImages_Never;
      process.generateNormalizationData = true;
      process.generateInvalidData = false;
      process.generateHistoryProperties = true;
      process.showBackgroundModels = false;
      process.showLocalScaleModels = false;
      process.showRejectionMaps = false;
      process.showStructureMaps = false;
      process.plotNormalizationFunctions = LocalNormalization.PlotNormalizationFunctions_DontPlot;
      process.noGUIMessages = true;
      process.outputDirectory = request.outputDirectory;
      process.outputExtension = ".xisf";
      process.outputPrefix = "";
      process.outputPostfix = "_n";
      process.overwriteExistingFiles = false;
      process.onError = LocalNormalization.OnError_Abort;
      var instancePath = request.outputDirectory + "/LocalNormalization-" + i + ".js";
      File.writeTextFile(instancePath, process.toSource());
      if (!process.executeGlobal() || process.outputData.length !== 1)
         throw new Error("LocalNormalization failed for " + request.inputs[i]);
      var row = process.outputData[0], dataPath = String(row[0]);
      if (!Boolean(row[5]) || !localNormalizationPathInside(dataPath, request.outputDirectory) ||
          !File.exists(dataPath) || String(row[1]).length)
         throw new Error("LocalNormalization did not produce valid XNML for " + request.inputs[i]);
      paths.push(dataPath); instances.push(instancePath);
   }
   return { outputs: paths, processInstancePath: instances[0] };
}

function oneRunIntegrate(request) {
   if (typeof ImageIntegration === "undefined") throw new Error("ImageIntegration unavailable");
   if (request.inputs.length < 3) throw new Error("Integration requires at least three images");
   if (["EQUAL", "PSF_SIGNAL"].indexOf(request.weighting) < 0 ||
       ["ESD", "WINSORIZED_SIGMA"].indexOf(request.rejection) < 0 ||
       ["ADDITIVE_WITH_SCALING", "LOCAL_NORMALIZATION"].indexOf(request.normalization) < 0 ||
       !(request.sigmaLow > 0) || !(request.sigmaHigh > 0))
      throw new Error("Unsupported one-run integration policy");
   var local = request.normalization === "LOCAL_NORMALIZATION";
   var drizzle = Boolean(request.drizzleDataPaths && request.drizzleDataPaths.length);
   if (drizzle && (local || request.drizzleDataPaths.length !== request.inputs.length))
      throw new Error("Drizzle requires one alignment record per light and additive normalization");
   if (local && (!Array.isArray(request.normalizationDataPaths) ||
       request.normalizationDataPaths.length !== request.inputs.length))
      throw new Error("LocalNormalization requires one XNML per registered light");
   var process = new ImageIntegration;
   process.images = request.inputs.map(function(path, index) {
      var dataPath = local ? request.normalizationDataPaths[index] : "";
      if (local && (!File.exists(dataPath) || dataPath.slice(-5).toLowerCase() !== ".xnml"))
         throw new Error("Missing local normalization data " + dataPath);
      return [true, path, drizzle ? request.drizzleDataPaths[index] : "", dataPath];
   });
   process.inputHints = "properties fits-keywords no-compress-data";
   process.combination = ImageIntegration.Average;
   process.weightMode = request.weighting === "PSF_SIGNAL"
      ? ImageIntegration.PSFSignalWeight : ImageIntegration.DontCare;
   process.weightScale = ImageIntegration.WeightScale_BWMV;
   process.weightOvershootProtection = false;
   process.minWeight = 0.005;
   process.normalization = local
      ? ImageIntegration.LocalNormalization : ImageIntegration.AdditiveWithScaling;
   process.rejection = request.rejection === "ESD"
      ? ImageIntegration.Rejection_ESD : ImageIntegration.WinsorizedSigmaClip;
   process.rejectionNormalization = local
      ? ImageIntegration.LocalRejectionNormalization : ImageIntegration.Scale;
   process.sigmaLow = request.sigmaLow;
   process.sigmaHigh = request.sigmaHigh;
   process.winsorizationCutoff = 5.0;
   process.esdOutliersFraction = 0.3;
   process.esdAlpha = 0.05;
   process.esdLowRelaxation = 1.0;
   process.clipLow = true;
   process.clipHigh = true;
   process.rangeClipLow = false;
   process.rangeClipHigh = false;
   process.generate64BitResult = false;
   process.generateRejectionMaps = true;
   process.generateSlopeMaps = false;
   process.generateIntegratedImage = true;
   process.generateDrizzleData = drizzle;
   process.closePreviousImages = false;
   process.useCache = false;
   process.evaluateSNR = true;
   process.psfStructureLayers = 5;
   process.psfType = ImageIntegration.PSFType_Moffat4;
   process.generateFITSKeywords = true;
   process.truncateOnOutOfRange = false;
   process.noGUIMessages = true;
   process.showImages = true;
   var instance = request.outputDirectory + "/ImageIntegration.js";
   File.writeTextFile(instance, process.toSource());
   if (!process.executeGlobal()) throw new Error("Batch ImageIntegration failed");
   var integrated = ImageWindow.windowById(process.integrationImageId);
   if (integrated.isNull) throw new Error("Integrated image window unavailable");
   var nativePath = request.outputDirectory + "/master.xisf";
   oneRunSave(integrated, nativePath, "properties fits-keywords no-compress-data");
   integrated.forceClose();
   var low = ImageWindow.windowById(process.lowRejectionMapImageId);
   var high = ImageWindow.windowById(process.highRejectionMapImageId);
   if (low.isNull || high.isNull) throw new Error("Rejection maps unavailable");
   var lowPath = request.outputDirectory + "/rejection-low.xisf";
   var highPath = request.outputDirectory + "/rejection-high.xisf";
   oneRunSave(low, lowPath, "properties no-compress-data");
   oneRunSave(high, highPath, "properties no-compress-data");
   low.forceClose();
   high.forceClose();
   var result = { outputs: [nativePath, lowPath, highPath],
      processInstancePath: instance,
      statistics: { numberOfImages: Number(process.numberOfImages),
         totalRejectedLow: Number(process.totalRejectedLowRK),
         totalRejectedHigh: Number(process.totalRejectedHighRK),
         finalNoiseEstimate: Number(process.finalNoiseEstimateRK),
         finalScaleEstimate: Number(process.finalScaleEstimateRK),
         finalLocationEstimate: Number(process.finalLocationEstimateRK),
         referenceNoiseReduction: Number(process.referenceNoiseReductionRK),
         medianNoiseReduction: Number(process.medianNoiseReductionRK) } };
   if (drizzle) result.drizzleDataPaths = request.drizzleDataPaths;
   return result;
}

function oneRunPrepareMasters(request) {
   if (!request.groups || !request.equipmentHeader)
      throw new Error("Raw calibration groups and equipment identity are required");
   function files(indices) {
      return indices.map(function(index) {
         if (!(index >= 0 && index < request.inputs.length) || Math.floor(index) !== index)
            throw new Error("Invalid calibration source index");
         return { path: request.inputs[index] };
      });
   }
   var names = Object.keys(request.groups.filters);
   var groups = { masterDarks: {}, filters: {} };
   var exposures = Object.keys(request.groups.masterDarks);
   for (var d = 0; d < exposures.length; ++d)
      groups.masterDarks[exposures[d]] = files(request.groups.masterDarks[exposures[d]]);
   for (var i = 0; i < names.length; ++i) {
      var group = request.groups.filters[names[i]];
      if (!group) throw new Error("Missing calibration group " + names[i]);
      groups.filters[names[i]] = { exposureSeconds: group.exposureSeconds,
         darkFlatExposureSeconds: group.darkFlatExposureSeconds,
         darkFlatExposureApproval: group.darkFlatExposureApproval,
         lightExposureSeconds: group.lightExposureSeconds,
         flats: files(group.flats), darkFlats: files(group.darkFlats) };
   }
   var nativeRequest = { adapter: MP_ADAPTER,
      expectedVersion: request.expectedVersion,
      outputDirectory: request.outputDirectory,
      equipmentHeader: request.equipmentHeader,
      preparationFingerprint: request.preparationFingerprint,
      savedDarkExposures: request.savedDarkExposures,
      groups: groups, nativeOnly: true };
   var receipt = prepareMasters(nativeRequest);
   var masters = { darks: {}, flats: {}, darkFlats: {} };
   var outputs = [];
   for (var x = 0; x < exposures.length; ++x) {
      var dark = receipt.masterDarks[exposures[x]];
      masters.darks[exposures[x]] = dark.nativePath;
      outputs.push(dark.nativePath);
   }
   for (var j = 0; j < names.length; ++j) {
      var name = names[j];
      masters.flats[name] = receipt.filters[name].flat.nativePath;
      masters.darkFlats[name] = receipt.filters[name].darkFlat.nativePath;
      outputs.push(receipt.filters[name].flat.nativePath,
         receipt.filters[name].darkFlat.nativePath);
   }
   var masterPaths = Object.keys(masters.darks).map(function(key) { return masters.darks[key]; });
   for (var k = 0; k < names.length; ++k)
      masterPaths.push(masters.darkFlats[names[k]], masters.flats[names[k]]);
   for (var m = 0; m < masterPaths.length; ++m) {
      var directory = masterPaths[m].substring(0, masterPaths[m].lastIndexOf("/"));
      var lowPath = directory + "/rejection-low.xisf";
      var highPath = directory + "/rejection-high.xisf";
      if (!File.exists(lowPath) || !File.exists(highPath))
         throw new Error("Prepared master rejection maps are missing: " + directory);
      outputs.push(lowPath, highPath);
   }
   return { outputs: outputs, masters: masters,
      processInstancePath: exposures.length ? receipt.masterDarks[exposures[0]].processInstancePath :
         receipt.filters[names[0]].flat.processInstancePath };
}

function runOneRunStage(p) {
   var request = JSON.parse(File.readTextFile(p.requestPath));
   oneRunRequireInputs(request);
   if (request.outputDirectory !== bridgePath + "/jobs/" + p.jobId + "/output")
      throw new Error("One-run output must stay inside isolated bridge staging");
   if (!File.directoryExists(request.outputDirectory))
      File.createDirectory(request.outputDirectory, true);
   var result;
   if (request.stage === "PREPARE_MASTERS") result = oneRunPrepareMasters(request);
   else if (request.stage === "CALIBRATE") result = oneRunCalibrate(request);
   else if (request.stage === "MEASURE") result = oneRunMeasure(request);
   else if (request.stage === "NORMALIZE") result = oneRunNormalize(request);
   else if (request.stage === "ALIGN") result = oneRunAlign(request);
   else if (request.stage === "INTEGRATE") result = oneRunIntegrate(request);
   else if (request.stage === "DRIZZLE") result = oneRunDrizzle(request);
   else throw new Error("Unsupported one-run stage: " + request.stage);
   result.adapter = OR_ADAPTER;
   result.stage = request.stage;
   return result;
}
