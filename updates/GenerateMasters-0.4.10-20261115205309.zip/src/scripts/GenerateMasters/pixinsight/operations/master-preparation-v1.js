/* Capability-gated native master preparation contract. */
var MP_ADAPTER = "pixinsight-master-preparation/1";

function masterPreparationVersion() {
   return [
      CoreApplication.versionMajor,
      CoreApplication.versionMinor,
      CoreApplication.versionRelease,
      CoreApplication.versionRevision
   ].join(".") + "-" + CoreApplication.versionBuild;
}

function probeMasterPreparation() {
   var reasons = [];
   var version = masterPreparationVersion();
   if (typeof ImageIntegration === "undefined")
      reasons.push("ImageIntegration unavailable");
   if (typeof ImageCalibration === "undefined")
      reasons.push("ImageCalibration unavailable");
   if (!reasons.length) {
      var integration = new ImageIntegration;
      var calibration = new ImageCalibration;
      for (var i = 0, integrationFields = ["images", "combination", "weightMode",
         "normalization", "rejection", "generateRejectionMaps"]; i < integrationFields.length; ++i)
         if (!(integrationFields[i] in integration)) reasons.push("ImageIntegration missing " + integrationFields[i]);
      for (var j = 0, calibrationFields = ["targetFrames", "masterDarkPath",
         "masterDarkEnabled", "outputDirectory", "outputSampleFormat"]; j < calibrationFields.length; ++j)
         if (!(calibrationFields[j] in calibration)) reasons.push("ImageCalibration missing " + calibrationFields[j]);
      if (typeof ImageIntegration.Rejection_ESD === "undefined" ||
          typeof ImageCalibration.f32 === "undefined")
         reasons.push("Required native process constants unavailable");
   }
   return {
      supported: reasons.length === 0,
      adapter: MP_ADAPTER,
      version: version,
      reasons: reasons
   };
}

function masterJoin(directory, name) {
   return (directory.charAt(directory.length - 1) === "/"
      ? directory.substring(0, directory.length - 1) : directory) + "/" + name;
}

function masterEnsureDirectory(path) {
   if (!File.directoryExists(path)) File.createDirectory(path, true);
}

function masterAssertNewFile(path) {
   if (File.exists(path)) throw new Error("Refusing to overwrite " + path);
}

function masterWrite(path, value) {
   masterAssertNewFile(path);
   File.writeTextFile(path, value);
}

function masterReplaceKeyword(window, name, value, comment) {
   var keywords = window.keywords;
   var literal = typeof value === "number"
      ? String(value)
      : "'" + String(value).split("'").join("''") + "'";
   var keyword = new FITSKeyword(name, literal, comment || "");
   var replaced = false;
   for (var i = 0; i < keywords.length; ++i)
      if (keywords[i].name === name) {
         keywords[i] = keyword;
         replaced = true;
         break;
      }
   if (!replaced) keywords.push(keyword);
   window.keywords = keywords;
}

function masterSaveWindow(window, path, hints) {
   masterAssertNewFile(path);
   if (!window.saveAs(path, false, false, true, false, hints))
      throw new Error("Unable to save " + path);
}

function ensureProfiledMaster(nativePath, directory, metadata, nativeOnly) {
   var profiledNativePath = masterJoin(directory, "master-profiled-v2.xisf");
   var profiledFitsPath = masterJoin(directory, "master-profiled-v2.fits");
   var nativeExists = File.exists(profiledNativePath);
   var fitsExists = File.exists(profiledFitsPath);
   if (nativeExists && (nativeOnly ? !fitsExists : fitsExists))
      return { nativePath: profiledNativePath,
         fitsPath: nativeOnly ? null : profiledFitsPath };
   if (nativeExists || fitsExists)
      throw new Error("Partial profiled master output requires review: " + directory);
   var windows = ImageWindow.open(nativePath, "", "properties fits-keywords", true);
   try {
      if (windows.length !== 1)
         throw new Error("Expected one image while profiling master metadata");
      var window = windows[0];
      masterReplaceKeyword(window, "IMAGETYP", metadata.imageType, "Master frame type");
      masterReplaceKeyword(window, "EXPOSURE", metadata.exposureSeconds, "[s] Exposure duration");
      masterReplaceKeyword(window, "EXPTIME", metadata.exposureSeconds, "[s] Exposure duration");
      if (metadata.filterName)
         masterReplaceKeyword(window, "FILTER", metadata.filterName, "Active filter name");
      masterReplaceKeyword(window, "INSTRUME", metadata.cameraName, "Imaging instrument name");
      masterReplaceKeyword(window, "CAMERAID", metadata.cameraDriver, "Imaging instrument identifier");
      masterReplaceKeyword(window, "READOUTM", metadata.readoutMode, "Sensor readout mode");
      masterReplaceKeyword(window, "EGAIN", metadata.electronsPerAdu, "[e-/ADU] Electrons per A/D unit");
      masterReplaceKeyword(window, "XBINNING", metadata.binX, "X axis binning factor");
      masterReplaceKeyword(window, "YBINNING", metadata.binY, "Y axis binning factor");
      masterSaveWindow(window, profiledNativePath, "properties fits-keywords no-compress-data");
      if (!nativeOnly)
         masterSaveWindow(window, profiledFitsPath, "fits-keywords no-compress-data");
   } finally {
      for (var i = 0; i < windows.length; ++i) windows[i].forceClose();
   }
   return { nativePath: profiledNativePath,
      fitsPath: nativeOnly ? null : profiledFitsPath };
}

function masterImageRows(inputs) {
   var rows = [];
   for (var i = 0; i < inputs.length; ++i)
      rows.push([true, inputs[i].path || inputs[i], "", ""]);
   return rows;
}

function masterIntegrationReceipt(process) {
   function serializable(value) {
      return typeof value === "bigint" ? Number(value) : value;
   }
   return {
      numberOfImages: serializable(process.numberOfImages),
      numberOfPixels: serializable(process.numberOfPixels),
      totalRejectedLow: serializable(process.totalRejectedLowRK),
      totalRejectedHigh: serializable(process.totalRejectedHighRK),
      finalNoiseEstimate: process.finalNoiseEstimateRK,
      finalScaleEstimate: process.finalScaleEstimateRK,
      finalLocationEstimate: process.finalLocationEstimateRK,
      referenceNoiseReduction: process.referenceNoiseReductionRK,
      medianNoiseReduction: process.medianNoiseReductionRK
   };
}

function integrateMaster(inputs, directory, metadata, flatMode, nativeOnly) {
   masterEnsureDirectory(directory);
   var nativePath = masterJoin(directory, "master.xisf");
   var fitsPath = masterJoin(directory, "master.fits");
   var instancePath = masterJoin(directory, "ImageIntegration.js");
   var lowPath = masterJoin(directory, "rejection-low.xisf");
   var highPath = masterJoin(directory, "rejection-high.xisf");
   var existing = nativeOnly
      ? [nativePath, instancePath, lowPath, highPath]
      : [nativePath, fitsPath, instancePath, lowPath, highPath];
   if (nativeOnly && File.exists(fitsPath))
      throw new Error("Unexpected FITS master in XISF-only staging: " + directory);
   var existingCount = 0;
   for (var e = 0; e < existing.length; ++e)
      if (File.exists(existing[e])) ++existingCount;
   if (existingCount === existing.length)
   {
      var resumedProfile = ensureProfiledMaster(nativePath, directory, metadata, nativeOnly);
      return {
         nativePath: resumedProfile.nativePath,
         fitsPath: resumedProfile.fitsPath,
         processInstancePath: instancePath,
         statistics: null,
         resumed: true
      };
   }
   if (existingCount !== 0)
      throw new Error("Partial/existing master output requires review: " + directory);
   var process = new ImageIntegration;
   process.images = masterImageRows(inputs);
   process.inputHints = "fits-keywords normalize only-first-image raw signed-is-physical";
   process.combination = ImageIntegration.Average;
   process.weightMode = ImageIntegration.DontCare;
   process.normalization = flatMode
      ? ImageIntegration.Multiplicative
      : ImageIntegration.NoNormalization;
   process.rejection = ImageIntegration.WinsorizedSigmaClip;
   process.rejectionNormalization = flatMode
      ? ImageIntegration.EqualizeFluxes
      : ImageIntegration.NoRejectionNormalization;
   process.sigmaLow = 4.0;
   process.sigmaHigh = 3.0;
   process.clipLow = true;
   process.clipHigh = true;
   process.rangeClipLow = false;
   process.rangeClipHigh = false;
   process.generate64BitResult = false;
   process.generateRejectionMaps = true;
   process.generateSlopeMaps = false;
   process.generateIntegratedImage = true;
   process.generateDrizzleData = false;
   process.closePreviousImages = false;
   process.useCache = false;
   process.evaluateSNR = true;
   process.generateFITSKeywords = true;
   process.truncateOnOutOfRange = false;
   process.noGUIMessages = true;
   process.showImages = true;
   masterWrite(instancePath, process.toSource());
   if (!process.executeGlobal()) throw new Error("ImageIntegration failed");
   var window = ImageWindow.windowById(process.integrationImageId);
   if (window.isNull) throw new Error("Integrated image window is unavailable");
   masterReplaceKeyword(window, "IMAGETYP", metadata.imageType, "Master frame type");
   masterReplaceKeyword(window, "EXPOSURE", metadata.exposureSeconds, "[s] Exposure duration");
   masterReplaceKeyword(window, "EXPTIME", metadata.exposureSeconds, "[s] Exposure duration");
   if (metadata.filterName)
      masterReplaceKeyword(window, "FILTER", metadata.filterName, "Active filter name");
   masterSaveWindow(window, nativePath, "properties fits-keywords no-compress-data");
   if (!nativeOnly)
      masterSaveWindow(window, fitsPath, "fits-keywords no-compress-data");
   var receipt = masterIntegrationReceipt(process);
   var low = ImageWindow.windowById(process.lowRejectionMapImageId);
   if (!low.isNull) {
      masterSaveWindow(low, lowPath, "properties no-compress-data");
      low.forceClose();
   }
   var high = ImageWindow.windowById(process.highRejectionMapImageId);
   if (!high.isNull) {
      masterSaveWindow(high, highPath, "properties no-compress-data");
      high.forceClose();
   }
   window.forceClose();
   var profile = ensureProfiledMaster(nativePath, directory, metadata, nativeOnly);
   return {
      nativePath: profile.nativePath,
      fitsPath: profile.fitsPath,
      processInstancePath: instancePath,
      statistics: receipt
   };
}

function calibratedFlatPath(source, directory) {
   var name = File.extractName(source);
   return masterJoin(directory, name + "_c.xisf");
}

function calibrateFlats(inputs, masterDarkFlatPath, directory) {
   masterEnsureDirectory(directory);
   var targets = [];
   var outputs = [];
   var existingCount = 0;
   for (var i = 0; i < inputs.length; ++i) {
      var output = calibratedFlatPath(inputs[i].path || inputs[i], directory);
      if (File.exists(output)) ++existingCount;
      outputs.push(output);
      targets.push([true, inputs[i].path || inputs[i]]);
   }
   var instancePath = masterJoin(directory, "ImageCalibration.js");
   if (File.exists(instancePath)) ++existingCount;
   if (existingCount === inputs.length + 1)
      return { paths: outputs, processInstancePath: instancePath, resumed: true };
   if (existingCount !== 0)
      throw new Error("Partial/existing calibrated flat outputs require review: " + directory);
   var process = new ImageCalibration;
   process.targetFrames = targets;
   process.enableCFA = false;
   process.overscanEnabled = false;
   process.masterBiasEnabled = false;
   process.masterBiasPath = "";
   process.masterDarkEnabled = true;
   process.masterDarkPath = masterDarkFlatPath;
   process.masterFlatEnabled = false;
   process.masterFlatPath = "";
   process.calibrateBias = false;
   process.calibrateDark = false;
   process.calibrateFlat = false;
   process.optimizeDarks = false;
   process.separateCFAFlatScalingFactors = false;
   process.pedestal = 0;
   process.pedestalMode = ImageCalibration.Keyword;
   process.pedestalKeyword = "";
   process.inputHints = "fits-keywords normalize only-first-image raw signed-is-physical";
   process.outputHints = "properties fits-keywords no-compress-data no-embedded-data no-resolution";
   process.cosmeticCorrectionLow = false;
   process.cosmeticCorrectionHigh = false;
   process.cosmeticShowMap = false;
   process.cosmeticShowMapAndStop = false;
   process.generateHistoryProperties = true;
   process.generateFITSKeywords = true;
   process.evaluateNoise = false;
   process.evaluateSignal = false;
   process.outputDirectory = directory;
   process.outputExtension = ".xisf";
   process.outputPrefix = "";
   process.outputPostfix = "_c";
   process.outputSampleFormat = ImageCalibration.f32;
   process.outputPedestal = 0;
   process.outputPedestalMode = ImageCalibration.OutputPedestal_Literal;
   process.overwriteExistingFiles = false;
   masterWrite(instancePath, process.toSource());
   if (!process.executeGlobal()) throw new Error("Flat ImageCalibration failed");
   for (var j = 0; j < inputs.length; ++j) {
      var path = calibratedFlatPath(inputs[j].path || inputs[j], directory);
      if (!File.exists(path)) throw new Error("Missing calibrated flat " + path);
   }
   return {
      paths: outputs,
      processInstancePath: instancePath
   };
}

function masterDarkFlatExposure(group) {
   var seconds = group.darkFlatExposureSeconds === undefined ? group.exposureSeconds : group.darkFlatExposureSeconds;
   if (typeof seconds !== "number" || !isFinite(seconds) || !(seconds > 0))
      throw new Error("Invalid dark-flat exposure");
   var approval = group.darkFlatExposureApproval;
   if (approval || Math.abs(seconds - group.exposureSeconds) > 1e-4) {
      if (!approval || approval.flatExposureSeconds !== group.exposureSeconds ||
          approval.darkFlatExposureSeconds !== seconds ||
          typeof approval.operator !== "string" || !approval.operator.trim() ||
          typeof approval.reason !== "string" || !approval.reason.trim() ||
          !Array.isArray(approval.flatChecksums) || approval.flatChecksums.length !== group.flats.length ||
          !Array.isArray(approval.darkFlatChecksums) || approval.darkFlatChecksums.length !== group.darkFlats.length)
         throw new Error("Missing or inconsistent dark-flat exposure approval");
   }
   return seconds;
}

function validateMasterPreparation(request) {
   var capability = probeMasterPreparation();
   if (!capability.supported) throw new Error(capability.reasons.join("; "));
   if (!request || request.adapter !== MP_ADAPTER ||
       request.expectedVersion !== capability.version)
      throw new Error("Master preparation adapter/version mismatch");
   if (typeof request.outputDirectory !== "string" || request.outputDirectory.charAt(0) !== "/")
      throw new Error("Master preparation needs an absolute output directory");
   if (!request.groups || !request.groups.masterDarks || !request.groups.filters)
      throw new Error("Master preparation groups are missing");
   var exposures = Object.keys(request.groups.masterDarks);
   var savedExposures = request.savedDarkExposures || [];
   if (!Array.isArray(savedExposures) || savedExposures.some(function(value) {
      return !(Number(value) > 0) || !isFinite(Number(value));
   })) throw new Error("Invalid saved dark exposure groups");
   if (!exposures.length && !savedExposures.length) throw new Error("No long-dark exposure groups");
   for (var d = 0; d < exposures.length; ++d)
      if (!(Number(exposures[d]) > 0) || request.groups.masterDarks[exposures[d]].length < 3)
         throw new Error("At least three long darks are required per exposure");
   var names = Object.keys(request.groups.filters);
   if (!names.length) throw new Error("No filter groups");
   for (var i = 0; i < names.length; ++i) {
      var group = request.groups.filters[names[i]];
      if (!group || group.flats.length < 3 || group.darkFlats.length < 3 ||
          !(group.exposureSeconds > 0) ||
          !Array.isArray(group.lightExposureSeconds) ||
          !group.lightExposureSeconds.length ||
          group.lightExposureSeconds.some(function(seconds) {
             return !request.groups.masterDarks[String(seconds)] && savedExposures.indexOf(String(seconds)) < 0;
          }))
         throw new Error("At least three flats and dark-flats are required for " + names[i]);
      masterDarkFlatExposure(group);
   }
   return capability;
}

function prepareMasters(request) {
   var capability = validateMasterPreparation(request);
   masterEnsureDirectory(request.outputDirectory);
   var receipt = {
      adapter: MP_ADAPTER,
      version: capability.version,
      preparationFingerprint: request.preparationFingerprint,
      startedAt: new Date().toISOString(),
      masterDarks: {},
      filters: {}
   };
   var exposures = Object.keys(request.groups.masterDarks);
   for (var d = 0; d < exposures.length; ++d) {
      var exposure = exposures[d];
      receipt.masterDarks[exposure] = integrateMaster(
         request.groups.masterDarks[exposure],
         masterJoin(request.outputDirectory, "dark-" + exposure + "s"),
         masterMetadata(request.equipmentHeader, "DARK", Number(exposure), "Luminance"),
         false, request.nativeOnly === true
      );
   }
   var names = Object.keys(request.groups.filters);
   for (var i = 0; i < names.length; ++i) {
      var name = names[i];
      var group = request.groups.filters[name];
      var darkFlat = integrateMaster(
         group.darkFlats,
         masterJoin(request.outputDirectory, "darkflat-" + name.toLowerCase()),
         masterMetadata(request.equipmentHeader, "DARKFLAT", masterDarkFlatExposure(group), name),
         false, request.nativeOnly === true
      );
      var calibrated = calibrateFlats(
         group.flats,
         darkFlat.nativePath,
         masterJoin(request.outputDirectory, "flat-" + name.toLowerCase() + "/calibrated")
      );
      var flatInputs = [];
      for (var j = 0; j < calibrated.paths.length; ++j)
         flatInputs.push({ path: calibrated.paths[j] });
      var flat = integrateMaster(
         flatInputs,
         masterJoin(request.outputDirectory, "flat-" + name.toLowerCase()),
         masterMetadata(request.equipmentHeader, "FLAT", group.exposureSeconds, name),
         true, request.nativeOnly === true
      );
      receipt.filters[name] = {
         exposureSeconds: group.exposureSeconds,
         darkFlatExposureSeconds: masterDarkFlatExposure(group),
         darkFlatExposureApproval: group.darkFlatExposureApproval || null,
         darkFlat: darkFlat,
         calibratedFlats: calibrated,
         flat: flat
      };
   }
   receipt.completedAt = new Date().toISOString();
   return receipt;
}

function masterMetadata(equipment, imageType, exposureSeconds, filterName) {
   if (!equipment) throw new Error("Equipment header identity is required");
   return {
      imageType: imageType,
      exposureSeconds: exposureSeconds,
      filterName: filterName,
      cameraName: equipment.cameraName,
      cameraDriver: equipment.cameraDriver,
      readoutMode: equipment.readoutMode,
      electronsPerAdu: equipment.electronsPerAdu,
      binX: equipment.binX,
      binY: equipment.binY
   };
}
