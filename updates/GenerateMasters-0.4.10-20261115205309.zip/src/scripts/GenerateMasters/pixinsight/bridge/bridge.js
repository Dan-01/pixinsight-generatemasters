#ifgteq __PI_VERSION__ 1.9.4
#engine v8
#endif
#include "service.jsh"

var bridgePath = Parameters.has("bridgePath") ? Parameters.getString("bridgePath") : File.homeDirectory + "/.pixinsight-processor/bridge";
var sessionSeconds = Parameters.has("sessionSeconds") ? Parameters.getReal("sessionSeconds") : 0;
var autoStopToken = Parameters.has("autoStopToken") ? Parameters.getString("autoStopToken") : "";
var bridge = createPixInsightBridge({ path:bridgePath,
   timeoutSeconds:Parameters.has("timeoutSeconds") ? Parameters.getReal("timeoutSeconds") : 3600 });
bridge.start();
try {
   var dialog = new Dialog;
   dialog.windowTitle = "PixInsight Processor Bridge";
   var label = new Label(dialog); label.text = "Calibration bridge: " + bridgePath;
   var stop = new PushButton(dialog); stop.text = "Stop bridge";
   var stopping = false, polling = false;
   stop.onClick = function() { stopping = true; dialog.ok(); };
   dialog.sizer = new VerticalSizer; dialog.sizer.margin=12; dialog.sizer.spacing=12;
   dialog.sizer.add(label); dialog.sizer.add(stop); dialog.adjustToContents();
   var timer = new Timer(2, true), sessionStarted = Date.now();
   timer.onTimeout = function() {
      if (polling || stopping) return;
      var stopPath = bridgePath+"/one-run-stop-"+autoStopToken+".json";
      try {
         if (autoStopToken && File.exists(stopPath) && JSON.parse(File.readTextFile(stopPath)).token === autoStopToken) {
            File.remove(stopPath); stopping = true; dialog.ok(); return;
         }
      } catch (error) { console.warningln(String(error)); }
      if (sessionSeconds > 0 && Date.now()-sessionStarted >= sessionSeconds*1000) { stopping = true; dialog.ok(); return; }
      polling = true;
      try { bridge.poll(); } catch (error) { console.warningln(String(error)); }
      finally { polling = false; }
   };
   timer.start();
   try { dialog.execute(); } finally { timer.stop(); }
} finally { bridge.stop(); }
