/* Shared native transport, embedded in GenerateMasters or run standalone. */
function bridgeHasLocalMount(path, mounts) {
   var best = null;
   for (var line of mounts.split("\n")) {
      var match = /^.* on (.*) \((.*)\)$/.exec(line);
      if (match && (match[1] === "/" || path === match[1] || path.indexOf(match[1] + "/") === 0) &&
          (!best || match[1].length > best.path.length))
         best = { path: match[1], flags: match[2].split(", ") };
   }
   if ((path.indexOf("/Volumes/") === 0 || path.indexOf("/Network/") === 0) &&
       (!best || best.path === "/")) return false;
   return best !== null && best.flags.indexOf("local") >= 0;
}

function createPixInsightBridge(options) {
#include "../operations/read-image-metadata.js"
#include "../operations/image-calibration-v1.js"
#include "../operations/cosmetic-correction-v1.js"
#include "../operations/subframe-measurement-v1.js"
#include "../operations/star-alignment-v1.js"
#include "../operations/local-normalization-v1.js"
#include "../operations/image-integration-v1.js"
#include "../operations/drizzle-integration-v1.js"
#include "../operations/one-run-stage-v1.js"
#include "../operations/master-preparation-v1.js"
var BRIDGE_VERSION = "0.9.1";
var queuePath = options.path, bridgePath = options.jobRoot || queuePath;
var commandTimeout = options.timeoutSeconds || 3600;
if (bridgePath.charAt(0) !== "/" || bridgePath.indexOf("/Network/") === 0)
   throw new Error("Bridge requires an absolute path on a mounted local disk");
// The Node launcher also resolves and verifies symlinked ancestors. Check the
// external mount here for standalone bridge launches before creating any files.
if (bridgePath.indexOf("/Volumes/") === 0) {
   var mountProbe = new ExternalProcess;
   mountProbe.start("/sbin/mount", []);
   if (!mountProbe.waitForStarted(5000) || !mountProbe.waitForFinished(5000) ||
       mountProbe.exitCode !== 0 || !bridgeHasLocalMount(bridgePath, mountProbe.stdout.toString()))
      throw new Error("Bridge requires a mounted local disk; network shares and disconnected volumes are not supported: " + bridgePath);
}

var environment = {bridgeVersion:BRIDGE_VERSION, pixInsightVersion:[CoreApplication.versionMajor, CoreApplication.versionMinor, CoreApplication.versionRelease, CoreApplication.versionRevision].join(".") + "-" + CoreApplication.versionBuild};
var active = null, started = false, polling = false;
function now() { return new Date().toISOString(); }
function atomicWrite(path, value) {
   var temp = path + ".tmp";
   File.writeTextFile(temp, JSON.stringify(value));
   // PJSR File.move refuses replacement. Remove only the previous runtime record.
   if (File.exists(path)) File.remove(path);
   File.move(temp, path);
}
function heartbeat(state, message) {
   atomicWrite(queuePath + "/heartbeat.json", {protocolVersion:BRIDGE_PROTOCOL_VERSION, timestamp:now(), state:state, environment:environment, activeCommand:active, message:message || ""});
}
function files(dir) {
   var out = [], finder = new FileFind;
   if (finder.begin(dir + "/*.json")) {
      do { if (finder.isFile && !finder.isSymbolicLink) out.push(finder.name); } while (finder.next());
      finder.end();
   }
   out.sort();
   return out;
}
function validate(c, name) {
   if (!c || c.protocolVersion !== BRIDGE_PROTOCOL_VERSION || typeof c.id !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(c.id) || name !== c.id + ".json")
      throw new Error("Invalid protocol version or command identity");
   if (c.status !== "queued" || !c.timestamps || typeof c.timestamps.createdAt !== "string" || !isFinite(Date.parse(c.timestamps.createdAt)) || !c.environment || !(c.environment.bridgeVersion === null || typeof c.environment.bridgeVersion === "string") || !(c.environment.pixInsightVersion === null || typeof c.environment.pixInsightVersion === "string") || !c.parameters || typeof c.parameters !== "object" || Array.isArray(c.parameters))
      throw new Error("Malformed command envelope");
   if (["ping","read_image_metadata","probe_calibration","image_calibration","probe_cosmetic_correction","cosmetic_correction","probe_subframe_measurement","subframe_measurement","probe_star_alignment","star_alignment","probe_local_normalization","local_normalization","probe_image_integration","probe_image_integration_drizzle","image_integration","probe_drizzle_integration","drizzle_integration","probe_one_run","one_run_stage"].indexOf(c.operation) < 0) throw new Error("Unsupported operation");
   if(c.operation === "image_calibration")validateCalibration(c.parameters,c.id);
   if(c.operation === "cosmetic_correction")validateCosmeticCorrection(c.parameters,c.id);
   if(c.operation === "subframe_measurement")validateSubframeMeasurement(c.parameters,c.id);
   if(c.operation === "star_alignment")validateStarAlignment(c.parameters,c.id);
   if(c.operation === "local_normalization")validateLocalNormalization(c.parameters,c.id);
   if(c.operation === "image_integration")validateImageIntegration(c.parameters,c.id);
   if(c.operation === "drizzle_integration")validateDrizzleIntegration(c.parameters,c.id);
   if(c.operation === "one_run_stage")validateOneRunStage(c.parameters,c.id);
   var keys = Object.keys(c.parameters);
   if (["ping","probe_calibration","probe_cosmetic_correction","probe_subframe_measurement","probe_star_alignment","probe_local_normalization","probe_image_integration","probe_image_integration_drizzle","probe_drizzle_integration","probe_one_run"].indexOf(c.operation) >= 0 && keys.length !== 0) throw new Error("Probe operations accept no parameters");
   if (c.operation === "read_image_metadata" && (keys.length !== 1 || typeof c.parameters.path !== "string" || c.parameters.path.charAt(0) !== "/" || c.parameters.path.indexOf("\u0000") >= 0))
      throw new Error("read_image_metadata requires one absolute path");
}
var operations = {
   ping:function() { return {message:"pong", capabilities:{version:environment.pixInsightVersion, processes:[], modules:[], operations:["ping","read_image_metadata","probe_calibration","image_calibration","probe_cosmetic_correction","cosmetic_correction","probe_subframe_measurement","subframe_measurement","probe_star_alignment","star_alignment","probe_local_normalization","local_normalization","probe_image_integration","probe_image_integration_drizzle","image_integration","probe_drizzle_integration","drizzle_integration","probe_one_run","one_run_stage"]}}; },
   probe_calibration:function(){return probeCalibration();},
   image_calibration:function(p){return calibrateImage(p);},
   probe_cosmetic_correction:function(){return probeCosmeticCorrection();},
   cosmetic_correction:function(p){return applyCosmeticCorrection(p);},
   probe_subframe_measurement:function(){return probeSubframeMeasurement();},
   subframe_measurement:function(p){return measureSubframe(p);},
   probe_star_alignment:function(){return probeStarAlignment();},
   star_alignment:function(p){return registerStarAligned(p);},
   probe_local_normalization:function(){return probeLocalNormalization();},
   local_normalization:function(p){return normalizeLocalImage(p);},
   probe_image_integration:function(){return probeImageIntegration();},
   probe_image_integration_drizzle:function(){return probeImageIntegrationDrizzle();},
   image_integration:function(p){return integrateImages(p);},
   probe_drizzle_integration:function(){return probeDrizzleIntegration();},
   drizzle_integration:function(p){return integrateDrizzle(p);},
   probe_one_run:function(){return probeOneRun();},
   one_run_stage:function(p){return runOneRunStage(p);},
   read_image_metadata:function(p) { return readImageMetadata(p.path); }
};
function consume(name, recovered) {
   var path = queuePath + "/processing/" + name;
   if (!recovered) File.move(queuePath + "/commands/" + name, path);
   var c;
   try { c = JSON.parse(File.readTextFile(path)); validate(c, name); }
   catch (e) {
      // Malformed commands cannot be represented as a correlated protocol result.
      atomicWrite(queuePath + "/failed/" + name + ".rejection", {error:String(e), timestamp:now()});
      File.move(path, queuePath + "/failed/" + name + ".command");
      return;
   }
   var resultPath = queuePath + "/results/" + name;
   var failedPath = queuePath + "/failed/" + name;
   if (File.exists(resultPath) || File.exists(failedPath)) { File.remove(path); return; }
   var start = now();
   active = {id:c.id, operation:c.operation, startedAt:start, deadlineAt:new Date(Date.now() + commandTimeout*1000).toISOString()};
   heartbeat("processing");
   var result = {protocolVersion:BRIDGE_PROTOCOL_VERSION, id:c.id, operation:c.operation, timestamps:{createdAt:c.timestamps.createdAt, startedAt:start}, status:"succeeded", environment:environment, requestParameters:c.parameters};
   try {
      if(recovered && ["image_calibration","cosmetic_correction","subframe_measurement","star_alignment","local_normalization","image_integration","drizzle_integration","one_run_stage"].indexOf(c.operation) >= 0)throw new Error("INTERRUPTED_REVIEW_REQUIRED: processing claim was interrupted; will not repeat automatically");
      result.data = operations[c.operation](c.parameters);
   }
   catch (e) { result.status = "failed"; result.error = String(e); }
   result.timestamps.completedAt = now();
   atomicWrite(result.status === "succeeded" ? resultPath : failedPath, result);
   File.remove(path);
   active = null;
   heartbeat("idle");
}

var bridgeLockToken=String(CoreApplication.instancePID(CoreApplication.instance))+"-"+Date.now()+"-"+Math.random();
var bridgeLockPath=queuePath+"/bridge.lock";
function acquireBridgeLock(){
   if(!File.directoryExists(queuePath))File.createDirectory(queuePath,true);
   var temp=bridgeLockPath+"."+bridgeLockToken+".tmp";
   File.writeTextFile(temp,JSON.stringify({token:bridgeLockToken,pid:Number(CoreApplication.instancePID(CoreApplication.instance)),instance:CoreApplication.instance,createdAt:now()}));
   try{File.move(temp,bridgeLockPath);}catch(e){if(File.exists(temp))File.remove(temp);throw new Error("Bridge lock exists. Stop the other bridge, or use piproc bridge-unlock after its PixInsight process has exited.");}
}

return {
   start: function() {
      acquireBridgeLock();
      try {
         for (var dir of ["commands", "processing", "results", "failed"])
            if (!File.directoryExists(queuePath+"/"+dir)) File.createDirectory(queuePath+"/"+dir,true);
         heartbeat("starting");
         for (var name of files(queuePath+"/processing")) consume(name, true);
         started = true; heartbeat("idle");
      } catch (error) { this.stop(); throw error; }
   },
   poll: function() {
      // The Node owner removes a private desktop session when its run ends.
      if (!started || polling || !File.directoryExists(queuePath)) return;
      polling = true;
      try {
         var queue = files(queuePath+"/commands");
         if (queue.length) consume(queue[0], false); else heartbeat("idle");
      } catch (error) { active = null; heartbeat("error", String(error)); throw error; }
      finally { polling = false; }
   },
   stop: function() {
      if (started && File.directoryExists(queuePath)) heartbeat("error", "Bridge stopped by operator");
      started = false;
      if (File.exists(bridgeLockPath) && JSON.parse(File.readTextFile(bridgeLockPath)).token === bridgeLockToken)
         File.remove(bridgeLockPath);
   }
};
}
