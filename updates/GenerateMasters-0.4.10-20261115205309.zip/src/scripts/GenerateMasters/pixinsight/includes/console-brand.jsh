/* Console identity shared by the two interactive DanAstroPhoto scripts. */
function daConsoleVersion(scriptDirectory) {
   if (scriptDirectory.charAt(scriptDirectory.length - 1) !== "/")
      scriptDirectory += "/";
   var names = ["release-manifest.json", "package.json"];
   for (var name of names) {
      var path = File.fullPath(scriptDirectory + "../" + name);
      if (!File.exists(path)) continue;
      try {
         var version = JSON.parse(File.readTextFile(path)).version;
         if (typeof version === "string" && /^\d+\.\d+\.\d+$/.test(version))
            return "v" + version;
      } catch (_) { /* The console banner should never prevent a script from opening. */ }
   }
   return "";
}

function daConsoleStart(tool, scriptDirectory) {
   console.show();
   console.writeln("");
   var mark = [
      "________              _______       _____             ______________       _____",
      "___  __ \\_____ __________    |________  /________________  __ \\__  /_________  /______",
      "__  / / /  __ `/_  __ \\_  /| |_  ___/  __/_  ___/  __ \\_  /_/ /_  __ \\  __ \\  __/  __ \\",
      "_  /_/ // /_/ /_  / / /  ___ |(__  )/ /_ _  /   / /_/ /  ____/_  / / / /_/ / /_ / /_/ /",
      "/_____/ \\__,_/ /_/ /_//_/  |_/____/ \\__/ /_/    \\____//_/     /_/ /_/\\____/\\__/ \\____/"
   ];
   // PixInsight supports italic SGR text and 24-bit foreground colours.
   var gradient = [
      [222, 95, 104], [199, 93, 128], [177, 91, 151],
      [149, 85, 174], [122, 82, 185]
   ];
   for (var i = 0; i < mark.length; ++i)
      console.writeln("\x1b[3;38;2;" + gradient[i].join(";") + "m" +
         mark[i] + "\x1b[0m");
   var version = daConsoleVersion(scriptDirectory);
   console.noteln("Starting DanAstroPhoto ★ " + tool + " ★" +
      (version ? "  " + version : ""));
   console.noteln("PixInsight · calibration and guided processing");
   console.flush();
}

function daConsoleEnd(tool) {
   console.noteln(tool + " dialog closed.");
   console.flush();
}
