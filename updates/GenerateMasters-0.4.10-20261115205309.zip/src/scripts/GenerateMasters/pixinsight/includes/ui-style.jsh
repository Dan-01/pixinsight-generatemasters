/* Shared native PixInsight presentation for DanAstroPhoto dialogs.
 * Keep controls and colours supplied by the active PixInsight theme. */
// Sizes are device-independent; preserve any larger user-selected native font.
function daUiPixels(control, size) {
   return control.logicalPixelsToPhysical ? control.logicalPixelsToPhysical(size) : size;
}
function daUiFont(control, size, bold) {
   if (typeof Font === "undefined" || !control.font) return;
   var font = new Font(control.font);
   font.pointSize = Math.max(size, control.font.pointSize);
   font.bold = !!bold; control.font = font;
}
function daUiBase(control) {
   var size = control.font ? Math.max(10, control.font.pointSize) : 10;
   if (!control.daUiStyled) {
      var css = "QLineEdit, QComboBox, QPushButton, QTabBar, QTreeView { font-size: " + size + "pt; } QLineEdit { padding: 3px 5px; } QComboBox { padding: 3px 5px; } " +
         "QPushButton { padding: 4px 8px; } QTabBar::tab { padding: 5px 10px; } " +
         "QTreeView::item { padding-top: 2px; padding-bottom: 2px; }";
      control.styleSheet = control.scaledStyleSheet ? control.scaledStyleSheet(css) : css;
      control.daUiStyled = true;
   }
   daUiFont(control, size, false);
   return control;
}
function daUiPalette(control) {
   var color = control.backgroundColor === undefined ? 0xffeeeeee : control.backgroundColor;
   var dark = (((color >> 16) & 255) * 0.2126 + ((color >> 8) & 255) * 0.7152 + (color & 255) * 0.0722) < 128;
   return dark ? {
      accent: "#d4b8f3", primary: "#6a418d", primaryText: "#ffffff",
      info: ["#243345", "#d5e8ff", "#7098c2"], success: ["#203c30", "#c8f2d8", "#72b792"],
      warning: ["#42351c", "#ffe7b2", "#d4a64e"], error: ["#43252f", "#ffd5df", "#d87890"]
   } : {
      accent: "#623b82", primary: "#694185", primaryText: "#ffffff",
      info: ["#edf4fc", "#24446b", "#789ac0"], success: ["#edf8f0", "#245c3e", "#78a88a"],
      warning: ["#fff7e5", "#71500f", "#bc8c34"], error: ["#fff0f3", "#90273e", "#bf6477"]
   };
}
function daUiEmphasis(control, role) {
   var size = role === "brand" ? 16 : role === "section" ? 12 : 10;
   if (control.font) size = Math.max(size, control.font.pointSize);
   daUiFont(control, size, role !== "body");
   if (role === "brand" || role === "section") control.foregroundColor =
      parseInt(daUiPalette(control).accent.replace("#", "ff"), 16);
   if (role === "primary") {
      var palette = daUiPalette(control);
      var css = "QPushButton { font-size: " + size + "pt; background-color: " + palette.primary + "; color: " + palette.primaryText +
         "; border: 1px solid " + palette.primary + "; border-radius: 5px; padding: 5px 10px; } " +
         "QPushButton:disabled { background-color: transparent; color: #888888; border-color: #999999; } " +
         "QPushButton:focus { border: 2px solid " + palette.accent + "; }";
      control.styleSheet = control.scaledStyleSheet ? control.scaledStyleSheet(css) : css;
      if (control.setScaledMinHeight) control.setScaledMinHeight(28);
   }
   // Assign after the stylesheet: native Qt styling can reset an explicit font.
   daUiFont(control, size, role !== "body");
   return control;
}
function daUiLabelWidth(control, texts, minimum) {
   var width = daUiPixels(control, minimum || 0);
   if (control.font && control.font.width)
      for (var text of texts) width = Math.max(width, control.font.width(text) + daUiPixels(control, 12));
   return width;
}
// Native QLabel size hints can retain the smaller theme font after styling.
// Wrap with the actual font, including unbroken paths, and reserve every line.
function daUiWrapNotice(text, font, width) {
   var lines = [];
   for (var paragraph of text.split("\n")) {
      while (paragraph.length && font.width(paragraph) > width) {
         var low = 1, high = paragraph.length;
         while (low < high) {
            var middle = Math.ceil((low + high)/2);
            if (font.width(paragraph.slice(0, middle)) <= width) low = middle;
            else high = middle - 1;
         }
         var cut = low;
         var boundary = Math.max(paragraph.lastIndexOf(" ", cut - 1),
            paragraph.lastIndexOf("/", cut - 1), paragraph.lastIndexOf("\\", cut - 1)) + 1;
         if (boundary >= Math.ceil(cut/2)) cut = boundary;
         lines.push(paragraph.slice(0, cut)); paragraph = paragraph.slice(cut);
      }
      lines.push(paragraph);
   }
   return lines.join("\n");
}
function daUiReflowNotice(label, width) {
   if (label.daNoticeReflowing || !label.font || !label.font.width || !label.font.height) return;
   label.daNoticeReflowing = true;
   try {
      var full = label.daNoticeMessage ? (label.daNoticeTitle ? label.daNoticeTitle + "\n" : "") + label.daNoticeMessage : "";
      var available = Math.max(1, (width > daUiPixels(label, 120) ? width : daUiPixels(label, 360)) - daUiPixels(label, 30));
      var wrapped = full ? daUiWrapNotice(full, label.font, available) : "";
      if (label.text !== wrapped) label.text = wrapped;
      var lines = wrapped.split("\n").length;
      var spacing = Math.max(label.font.height, label.font.lineSpacing || label.font.height);
      // height is glyph height; subsequent baselines use lineSpacing, including leading.
      var height = full ? label.font.height + (lines - 1) * spacing + daUiPixels(label, 32) : 0;
      if (label.minHeight !== height) label.minHeight = height;
   } finally { label.daNoticeReflowing = false; }
}
function daUiSetNotice(label, kind, text, title) {
   kind = ["info", "success", "warning", "error"].indexOf(kind) >= 0 ? kind : "info";
   text = String(text || "");
   label.daNoticeKind = kind; label.daNoticeMessage = text;
   label.daNoticeTitle = title === undefined ? { info: "Information", success: "Ready", warning: "Action needed", error: "Action failed" }[kind] : title;
   label.useRichText = false; label.wordWrapping = false;
   label.margin = daUiPixels(label, 12);
   if (typeof TextAlignment !== "undefined") label.textAlignment = TextAlignment.Left | TextAlignment.Top;
   label.text = text ? (label.daNoticeTitle ? label.daNoticeTitle + "\n" : "") + text : "";
   label.visible = !!text;
   var size = label.font ? Math.max(10, label.font.pointSize) : 10;
   var colors = daUiPalette(label)[kind];
   var css = "QLabel { font-size: " + size + "pt; background-color: " + colors[0] + "; color: " + colors[1] +
      "; border: 1px solid " + colors[2] + "; border-left: 4px solid " + colors[2] +
      "; border-radius: 5px; padding: 0px; }";
   label.styleSheet = label.scaledStyleSheet ? label.scaledStyleSheet(css) : css;
   daUiFont(label, size, false);
   daUiReflowNotice(label, label.width);
   return label;
}
function daUiNotice(parent, text, kind, title) {
   var label = new Label(parent);
   label.onResize = function(width) { daUiReflowNotice(label, width); };
   return daUiSetNotice(label, kind || "info", text, title);
}
function daUiWorkspaceNotice(workspace, label) {
   (workspace.notices || workspace.work).add(label);
   return label;
}
// Scrolling moves the existing layout; only a resize/content change recomputes it.
function daUiScrollContent(scroll, content) {
   function position() {
      content.move(-scroll.horizontalScrollPosition, -scroll.verticalScrollPosition);
   }
   scroll.onVerticalScrollPosUpdated = position;
   scroll.onHorizontalScrollPosUpdated = position;
   function wheel(x, y, dy) {
      var previous = scroll.verticalScrollPosition;
      var step = Math.max(1, Math.round(Math.abs(dy)/120 *
         Math.max(daUiPixels(content, 24), (content.font ? content.font.height : 12) * 3)));
      scroll.verticalScrollPosition = Math.max(0, Math.min(scroll.maxVerticalScrollPosition,
         previous + (dy < 0 ? step : dy > 0 ? -step : 0)));
      position();
      return scroll.verticalScrollPosition !== previous;
   }
   scroll.viewport.onMouseWheel = wheel;
   content.onMouseWheel = wheel;
   return position;
}
// Reserve the actual font's wrapped lines for ordinary instructions as well.
function daUiReflowText(label, width) {
   if (label.daTextReflowing || !label.font || !label.font.width || !label.font.height) return;
   label.daTextReflowing = true;
   try {
      var available = Math.max(1, (width > daUiPixels(label, 120) ? width : daUiPixels(label, 360)) - daUiPixels(label, 4));
      var wrapped = daUiWrapNotice(label.daTextMessage, label.font, available);
      if (label.text !== wrapped) label.text = wrapped;
      label.wordWrapping = false;
      if (typeof TextAlignment !== "undefined") label.textAlignment = TextAlignment.Left | TextAlignment.Top;
      label.margin = daUiPixels(label, 2);
      var height = label.font.height + (wrapped.split("\n").length - 1) *
         Math.max(label.font.height, label.font.lineSpacing || label.font.height) + daUiPixels(label, 4);
      if (label.minHeight !== height) label.minHeight = height;
   } finally { label.daTextReflowing = false; }
}
var daActiveWorkspaceDialog = null;
#include "ui-help.jsh"
function daUiMount(host, page) {
   if (!host.daWorkspaceSizer) {
      host.daWorkspaceSizer = new VerticalSizer;
      host.daWorkspaceSizer.margin = 0;
      host.sizer = host.daWorkspaceSizer;
   }
   if (host.daWorkspacePage && host.daWorkspacePage !== page) {
      host.daWorkspaceSizer.remove(host.daWorkspacePage);
      host.daWorkspacePage.hide();
   }
   if (host.daWorkspacePage !== page) host.daWorkspaceSizer.add(page);
   host.daWorkspacePage = page;
   page.show(); host.adjustToContents();
   if (page.daRefreshWorkspace) page.daRefreshWorkspace();
}
// Workflow and setup pages use this host sequentially. File pickers remain native dialogs.
var daUiInspectionPause = false;
function daUiDialog() {
   if (!daActiveWorkspaceDialog) {
      var standalone = daUiBase(new Dialog); standalone.daWorkspace = true;
      var execute = standalone.execute;
      standalone.execute = function() { return daUiInspectionPause ? 0 : execute.call(this); };
      return standalone;
   }
   var host = daActiveWorkspaceDialog, page = new Control(host);
   daUiFont(page, 10, false);
   page.daWorkspace = true; page.hide();
   page.ok = function() { host.ok(); };
   page.cancel = function() { host.cancel(); };
   page.execute = function() {
      host.windowTitle = "DanAstroPhoto — " + page.windowTitle.replace("ProcessMasters — ", "Process · ");
      daUiMount(host, page);
      return daUiInspectionPause ? 0 : host.execute();
   };
   return page;
}
function daUiHeader(dialog, title, subtitle) {
   var header = new Control(dialog), palette = daUiPalette(dialog);
   var layout = new VerticalSizer; layout.spacing = 6;
   var brand = new Label(header); brand.text = "DanAstroPhoto"; daUiEmphasis(brand, "brand");
   var heading = new Label(header); heading.wordWrapping = true;
   heading.text = title + (subtitle ? "  ·  " + subtitle : ""); daUiEmphasis(heading, "section");
   var rule = daUiRule(header);
   rule.styleSheet = "QFrame { color: " + palette.accent + "; background-color: " + palette.accent + "; border: none; }";
   layout.add(brand); layout.add(heading); layout.add(rule);
   header.daRetainedControls = [brand, heading, rule];
   header.sizer = layout; return header;
}
function daUiGroup(dialog, title) {
   var group = new GroupBox(dialog);
   group.title = title;
   var css = "QGroupBox { border: 1px solid palette(mid); border-radius: 5px; margin-top: 12px; } " +
      "QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left; padding: 0 5px; color: " + daUiPalette(dialog).accent + "; }";
   group.styleSheet = group.scaledStyleSheet ? group.scaledStyleSheet(css) : css;
   daUiFont(group, dialog.font ? Math.max(10, dialog.font.pointSize) : 10, false);
   group.sizer = new VerticalSizer;
   group.sizer.margin = 10;
   group.sizer.spacing = 8;
   return group;
}
function daUiRule(dialog) {
   var rule = new Frame(dialog);
   rule.frameStyle = FrameStyle.Box;
   rule.setFixedHeight(2);
   return rule;
}
function daUiWorkspace(dialog, title, subtitle) {
   daUiFont(dialog, 10, false);
   var root = new VerticalSizer; root.margin = 10; root.spacing = 8;
   var header = daUiHeader(dialog, title, subtitle);
   root.add(header);
   var scroll = new ScrollBox(dialog); scroll.autoScroll = true; scroll.tracking = true;
   var tools = new Control(scroll.viewport), work = new Control(dialog);
   var workScroll = new ScrollBox(work); workScroll.autoScroll = true; workScroll.tracking = true;
   var content = new Control(workScroll.viewport);
   content.sizer = new VerticalSizer; content.sizer.spacing = 8;
   var notices = new VerticalSizer; notices.spacing = 10;
   tools.sizer = new VerticalSizer; tools.sizer.spacing = 8;
   work.sizer = new VerticalSizer; work.sizer.spacing = 8;
   work.sizer.add(workScroll, 100); work.sizer.add(notices);
   var screen = dialog.availableScreenRect;
   var compact = screen && screen.width > 0 && screen.width < daUiPixels(dialog, 1100);
   if (compact) {
      var tabs = new TabBox(dialog);
      tabs.addPage(work, "Workspace"); tabs.addPage(scroll, "Workflow and settings");
      root.add(tabs, 100);
   } else {
      scroll.setFixedWidth(daUiPixels(dialog, 390));
      var body = new HorizontalSizer; body.spacing = 10;
      body.add(scroll); body.add(work, 100); root.add(body, 100);
   }
   tools.setFixedWidth(daUiPixels(dialog, 366));
   scroll.setFixedHeight(screen && screen.height > 0 ? Math.max(daUiPixels(dialog, 260), Math.min(daUiPixels(dialog, 600), screen.height - daUiPixels(dialog, 360))) : daUiPixels(dialog, 540));
   workScroll.setFixedHeight(scroll.height);
   if (workScroll.setScaledMinWidth) workScroll.setScaledMinWidth(compact ? 580 : 680);
   content.setFixedWidth(daUiPixels(dialog, compact ? 580 : 680));
   var positionWork = daUiScrollContent(workScroll, content);
   var positionTools = daUiScrollContent(scroll, tools);
   var refreshingWork = false, refreshingTools = false;
   function refreshWork() {
      if (refreshingWork) return;
      refreshingWork = true;
      try {
         if (workScroll.viewport.width > 0) content.setFixedWidth(workScroll.viewport.width);
         content.adjustToContents();
         // Keep fixed-size image comparisons reachable through horizontal scrolling.
         if (content.childrenRect && content.childrenRect.x1 > content.width) {
            content.setFixedWidth(content.childrenRect.x1);
            content.adjustToContents();
         }
         workScroll.maxVerticalScrollPosition = Math.max(0, content.height - workScroll.viewport.height);
         workScroll.maxHorizontalScrollPosition = Math.max(0, content.width - workScroll.viewport.width);
         positionWork();
      } finally { refreshingWork = false; }
   }
   workScroll.viewport.onResize = refreshWork;
   function refresh() {
      if (refreshingTools) return;
      refreshingTools = true;
      try {
         tools.adjustToContents();
         scroll.maxVerticalScrollPosition = Math.max(0, tools.height - scroll.viewport.height);
         scroll.maxHorizontalScrollPosition = Math.max(0, tools.width - scroll.viewport.width);
         positionTools();
         refreshWork();
      } finally { refreshingTools = false; }
   }
   scroll.viewport.onResize = refresh;
   dialog.daRefreshWorkspace = refresh;
   var footer = new HorizontalSizer; footer.spacing = 8;
   root.add(daUiRule(dialog)); root.add(footer);
   return { root: root, tools: tools.sizer, work: content.sizer, notices: notices, workScroll: workScroll, workContent: content, toolsScroll: scroll, toolsContent: tools, footer: footer, refresh: refresh,
      retainedControls: [header, scroll, tools, work, workScroll, content], retainedLayout: compact ? tabs : body };
}
function daUiText(parent, text) {
   var label = new Label(parent); daUiFont(label, 10, false);
   label.daTextMessage = String(text || ""); label.useRichText = false;
   label.wordWrapping = true; label.text = label.daTextMessage;
   label.onResize = function(width) { daUiReflowText(label, width); };
   daUiReflowText(label, label.width);
   return label;
}
function pmSettingsWorkspace(state, title, instructions) {
   var dialog = daUiDialog(); dialog.windowTitle = "ProcessMasters — " + title;
   var workspace = daUiWorkspace(dialog, "Process", title);
   workspace.tools.add(daUiText(dialog, instructions));
   if (state) {
      workspace.tools.add(daUiText(dialog, "Recipe: " + pmRecipe(state).name));
      workspace.tools.add(daUiText(dialog, pmRecipeGuidance(state)));
      workspace.tools.add(daUiText(dialog, pmStepPosition(state)));
      workspace.tools.add(pmTimelineControl(dialog, state));
   }
   workspace.tools.addStretch();
   workspace.tools.add(daUiText(dialog, state ? "Back returns to the current step. Settings are applied only when you choose the action below." : "Review your selections before continuing."));
   dialog.sizer = workspace.root;
   return { dialog: dialog, workspace: workspace };
}
function daUiProblemDialog(title, error, workspaceName) {
   var dialog = daUiDialog(); dialog.windowTitle = title;
   var workspace = daUiWorkspace(dialog, workspaceName || "Process", title);
   workspace.tools.add(daUiText(dialog, "This action could not complete. Review the details, then return to the workspace to adjust settings or continue a saved session."));
   daUiWorkspaceNotice(workspace, daUiNotice(dialog, String(error).split("\n")[0], "error", "Action could not complete"));
   var detail = new TextBox(dialog); detail.readOnly = true; detail.text = String(error); detail.setFixedHeight(220);
   workspace.work.add(detail); workspace.work.addStretch();
   var back = new PushButton(dialog); back.text = "Back to workspace"; daUiActionHelp(back, "back");
   back.onClick = function() { dialog.ok(); }; workspace.footer.addStretch(); workspace.footer.add(back);
   dialog.sizer = workspace.root; dialog.adjustToContents(); dialog.execute();
}
