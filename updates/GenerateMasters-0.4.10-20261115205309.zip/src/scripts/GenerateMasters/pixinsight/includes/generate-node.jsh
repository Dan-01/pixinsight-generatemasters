// Minimum patched Node 26 LTS runtime supported by GenerateMasters.
function gmNodeSupportedVersion(version) {
   var match = /^v26\.(\d+)\.(\d+)$/.exec(String(version).trim());
   return match !== null && (Number(match[1]) > 13 ||
      (Number(match[1]) === 13 && Number(match[2]) >= 1));
}
