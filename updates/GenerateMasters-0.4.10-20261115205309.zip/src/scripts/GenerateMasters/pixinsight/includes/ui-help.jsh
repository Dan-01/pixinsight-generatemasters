function daUiEscape(value) {
   return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/\"/g, "&quot;");
}
/* Rich-text help follows PixInsight's native tooltip style. Recommendations are
 * starting points for inspection, not automatic settings or object detection. */
function daUiHelp(control, title, explanation, recommendation) {
   control.toolTip = "<p><b>" + daUiEscape(title) + "</b></p><p>" +
      daUiEscape(explanation) + "</p>" + (recommendation ?
      "<p><b>Starting recommendation:</b> " + daUiEscape(recommendation) + "</p>" : "");
   return control.toolTip;
}
function daUiFieldHelp(control, title) {
   var help = {
      "Extra calibration folder": ["Optional additional folder of raw calibration frames, standalone MasterDark images or a DanAstroPhoto master-dark library. These are combined with calibration data in the source folder. Leave blank when everything is already there, or when selecting a master dark directly.", "Point to the folder containing matching calibration files. Use existing master darks must be enabled for reuse. Camera, gain/readout, binning, temperature and exposure must match. Dark scaling stays disabled."],
      "Source FITS folder": ["Folder searched for light and calibration frames matching this capture.", "Use one target and equipment configuration. Include the raw calibration frames when rebuilding masters."],
      "Final masters folder": ["Destination for reviewed, published linear masters and their inventory.", "Use a separate folder per target or capture. Select this folder later in Process."],
      "Target": ["Target name used to match source frames and name outputs. It does not select processing settings.", "Use the target identity recorded in your capture; choose processing methods after reviewing the image."],
      "Equipment name": ["Identity for this telescope, camera, reducer and filter train, used to check calibration compatibility.", "Use the same name only for the same configuration; object type does not change calibration requirements."],
      "Captured by": ["Name recorded with frame decisions and calibration confirmations.", "Enter the person reviewing these frames."],
      "Reference filter": ["Filter from which the alignment reference is selected. Other filters are registered to the same grid.", "Usually L for LRGB galaxies, reflection nebulae or clusters; use a narrowband filter with well-defined stars for emission nebulae."],
      "Calibration mode": ["Use all calibration masters recorded in the saved setup, or prepare calibration from your folders. Folder mode builds flats and dark-flats and can use a standalone master dark selected on Source.", "Choose Prepare calibration from folders when using new flats and an existing master dark. Leave dark reuse enabled; camera settings and exposure must match for every target type."],
      "Equipment setup file": ["Saved JSON describing equipment, calibration settings, filters, exposures and default folders.", "Normally use Create from FITS or Load saved setup; edit this path only to select an existing setup."],
      "Runtime settings file": ["Optional YAML configuration for the generation runtime.", "Keep the supplied configuration unless you need a reviewed custom runtime."],
      "Saved frame review": ["Saved per-frame decisions from an earlier review of the same inputs.", "Leave blank for a new capture; the workflow will guide the review."],
      "Saved master review": ["Saved master-acceptance record for resuming the same reviewed run.", "Leave blank for new integrations; inspect their masters and rejection maps first."],
      "Node executable": ["Path to the Node.js executable used to generate masters.", "Use the detected Node.js 24 executable. This is a runtime requirement, not an image-processing setting."],
      "Sample light frame": ["One representative FITS light frame whose headers supply the target, camera settings and capture geometry.", "Choose a light from the current capture, not a master or calibration frame. Check the detected settings afterward."],
      "Save setup as": ["Location and filename for the reusable equipment setup JSON.", "Keep the suggested Equipment setups folder. Choose a new filename to avoid overwriting another setup."],
      "Recent runs": ["Select a recently published GenerateMasters run; its masters inventory is loaded automatically.", "Check the displayed target and filters before starting."],
      "Masters folder": ["Published final masters folder containing manifest.json. Its inventory and image checksums are checked before processing.", "Choose the reviewed output from GenerateMasters, not its temporary staging folder."],
      "Masters inventory file": ["Advanced path to the manifest.json describing a published master set.", "Normally select the Masters folder instead; use this for an inventory outside the usual location."],
      "Alternate reviewed master set": ["Optional selection of alternate integrations that have been reviewed and share the same image grid.", "Leave blank to use the published masters. Select an alternate only after comparing its actual images."],
      "Processing folder": ["Parent folder for new processing sessions, intermediate candidates and finished images. Each new session gets its own subfolder.", "Use a local folder with space for several full-size images; keep source masters separately."],
      "Save processed images in": ["Parent folder for processing sessions and finished images; a separate session subfolder is created.", "Keep the suggested Processed folder or choose a disk with enough space for full-size candidates."],
      "Saved session folder": ["Folder containing guided-session.json and its saved processing images. Continue returns to its recorded checkpoint.", "Choose the original session subfolder and keep its contents together."],
      "Saved session file": ["Advanced direct path to guided-session.json.", "Normally choose the saved session folder. Moving the JSON alone does not move the session images."],
      "Processing method": ["Select the tool or settings source used to create the next result. Saved settings use a PixInsight process icon; defaults use a new process instance.", "Review every candidate before accepting. A provider or larger model tier is not a guarantee of a better result."],
      "Preview palette": ["Maps the available filter masters to output colour channels. LRGB uses luminance later; Ha additions are reviewed separately.", "Use RGB/LRGB for galaxies, reflection nebulae and clusters. SHO/HOO are emission-line interpretations for suitable narrowband data."],
      "Stretch method": ["Choose a global HistogramTransformation stretch or MultiscaleAdaptiveStretch. The guide creates a full-size candidate for review.", "Compare both on your data. Check galaxy or cluster cores and bright nebular regions, as well as faint outskirts."],
      "Star blend": ["Soft screen combines layers with 1-(1-background)*(1-stars); Additive adds the star layer and limits the output range.", "Start with Soft screen. Inspect colours, halos and bright-star clipping; for globular clusters also inspect the crowded core."],
      "Target type": ["Displays gradient-removal advice for the selected subject. It does not identify the object or change the image automatically.", "Select the closest subject. For clusters use broadband advice and protect the crowded core and outer stars."],
      "Blend method": ["Direct addition adds strength × Ha to red without automatic scaling or background subtraction. Background-adjusted excess is a different visual blend limited to strength 0–1.", "Use direct addition when following the guided Ha workflow, denoise Ha first and inspect the subsequent calibration. For galaxies, consider continuum subtraction; reflection nebulae and clusters usually do not need Ha."],
      "GraXpert executable": ["Executable used for automatic AI background subtraction.", "On macOS select the executable inside GraXpert.app/Contents/MacOS. Keep the detected path if it works."],
      "Installed background model version": ["Exact version of the downloaded GraXpert background model; it must exist in the model cache.", "Use the version installed in GraXpert. Do not enter a denoising model version."],
      "Settings source": ["Choose a model and amount here, or reuse all parameters from a saved MLDenoise process icon.", "Start with explicit settings for a new image. Recheck saved settings when image scale, noise level or processing state changes."],
      "Model file": ["Installed MLDenoise .xmlm model. The native process uses this exact file rather than inheriting interface preferences.", "Choose an appropriate installed model and inspect fine structure at 100%. A model name or tier alone does not determine the best amount."],
      "Saved process settings": ["PixInsight process icon whose parameters are loaded to create a new candidate.", "Review the icon first. Use conservative detail/noise settings for faint dust and check crowded cluster stars; StarNet2 icons must have Linear Data enabled."],
      "Measured star profile (PSF)": ["Open monochrome 32-bit floating-point PSF image exported from DynamicPSF. This describes the blur used by native Deconvolution.", "Measure several unsaturated, isolated stars in the current linear input. For clusters avoid the blended central stars."],
      "Star protection mask (optional)": ["Full-size monochrome support image for Deconvolution's local deringing, retained with the measured PSF.", "Use suitable local support around bright stars and inspect for dark rings. In crowded fields check that support does not suppress the desired detail."],
      "Start after": ["Retained accepted checkpoint from which a separate processing version will begin. The original session is preserved.", "Choose the last satisfactory result before the step you want to change."],
      "Left / A": ["Saved input or result shown on the left of the method comparison.", "Keep the accepted input here when evaluating how much a tool changed."],
      "Right / B": ["Saved result shown on the right; Review selected right result returns it to the normal acceptance page.", "Compare at 100%, including faint signal and star profiles. Review before accepting."],
      "MARS databases": ["Selected downloaded .xmars reference databases used by MGC. They must cover the field and required broadband filters.", "Keep the files in a stable folder. MGC + MARS can be useful for broad faint dust; inspect the removed gradient for lost real signal."],
      "View scale": ["Choose an unresampled 100% crop or a reduced overview. This only changes the display.", "Use 100% to judge noise, ringing and star profiles; use the overview to check gradients and overall balance."],
      "Compare": ["Show split input/result, side-by-side images, removed signal, or extracted stars where available. This changes only the review display.", "Check removed signal for galaxy arms, dust or emission structure; inspect extracted stars for nebulosity and cluster-core remnants."],
      "Split position": ["Move the dividing line between input and candidate in the split comparison. You can also drag it on the preview.", "Sweep it across stars, bright cores and faint background structure."],
      "Background target": ["Target brightness used to derive the stretch; it is not a background-subtraction control.", "Start near the supplied value. Keep reflection nebulosity, IFN and galaxy halos visible without making the sky artificially bright."],
      "Shadow clip": ["Sets the HistogramTransformation black point using the image median minus this multiple of its deviation. Larger values move the black point lower.", "For faint dust or galaxy outskirts, inspect carefully and use a lower black point that preserves signal. Check the histogram rather than forcing the sky black."],
      "MAS aggressiveness": ["Sets MAS shadow clipping before the midtone stretch. Higher aggressiveness moves the black point closer to the sky peak, increasing contrast and potentially background noise or clipping.", "Start modestly for noisy dust and reflection nebulae; increase only while faint structure remains credible. Inspect galaxy halos and cluster outskirts."],
      "MAS dynamic range compression": ["Controls MAS compression of brightness differences between faint and bright regions.", "Compare moderate compression for bright galaxy/cluster cores or nebulae such as M42. Too much can flatten their natural brightness structure."],
      "L contribution": ["Fraction of separately reviewed L mixed into linear RGB luminance after automatic native LinearFit. A common pixel gain preserves R/G/B ratios, with shared highlight limiting. Zero keeps RGB brightness; one uses matched L brightness.", "Prepare L gradients first. Start around 0.3–0.6 for galaxies or reflection dust; compare faint structure, noise and stellar halos at 100%. For clusters inspect crowded cores. Keep RGB without L omits luminance."],
      "L contribution (applied later for LRGB)": ["Planned luminance fraction. In current sessions it is applied at the later LRGB checkpoint after colour calibration.", "Start with a modest contribution and inspect the later full-size result for colour dilution and core detail."],
      "Ha red strength": ["Multiplier of the separate Ha signal added to red. The allowed range depends on this checkpoint; background-adjusted excess is limited to 0–1. Changing strength requires a new candidate.", "Start low and compare. Enhance verified emission regions, not galaxy continuum or stellar halos; normally omit Ha for reflection nebulae and clusters."],
      "R subtraction scale (k)": ["Continuum estimate: subtract k × registered R from Ha before the later Ha addition. This may also remove emission present in R.", "For galaxies, compare unsaturated stars and non-emission regions at 100%. Increase carefully; do not remove real emission or force all stars to zero."],
      "Star midtone (lower = brighter)": ["Midtone balance used to stretch the saved linear star layer independently. Lower values make stars brighter.", "Start with the supplied value. For emission nebulae keep stars balanced with nebulosity; for clusters preserve the stellar core and its colours."],
      "Star amount (0–2; 1 = normal)": ["Multiplier of the stretched star layer during recombination: zero removes it, one uses its normal contribution, two doubles it.", "Start at 1. Reduce only after inspecting small stars and halos; avoid suppressing the main subject in globular or open clusters."],
      "Denoising amount": ["MLDenoise strength from 0 to 1; higher values apply more noise reduction. Creates a candidate without replacing the accepted input.", "Start modestly, then inspect at 100%. Preserve reflection dust/IFN, galaxy arms, emission filaments and small stars in clusters; inspect removed signal."],
      "Smoothing": ["GraXpert smoothing parameter passed to the installed background model.", "Begin with the saved/default value and compare the removed model. For faint dust or extended emission, reject subtraction that removes real structure."],
      "Highlight threshold": ["HDRComposition mask threshold at which shorter exposures replace bright regions of longer masters.", "Use HDR where shorter data preserve a bright nebular, galaxy or cluster core. Inspect transition boundaries and check the native candidate at full size."],
      "Mask smoothness": ["HDRComposition mask smoothing in pixels, softening transitions between exposures.", "Start with the supplied value and inspect core transitions; excessive smoothing can spread the replacement into surrounding detail."],
      "Mask growth": ["HDRComposition mask expansion in pixels around highlight regions.", "Increase only enough to cover clipped core pixels or transition artifacts; inspect nearby stars and fine nebular structure."],
      "Crop left (px)": ["Left coordinate of the common 100% review crop; changes only the preview.", "Compare the same region in every panel: include fine target detail, background and a representative star."],
      "Crop top (px)": ["Top coordinate of the common 100% review crop; changes only the preview.", "Inspect both the bright core and faint outskirts, rather than judging noise from an empty patch alone."]
   };
   var entry = help[title];
   if (!entry && / brightness$/.test(title)) {
      var filter = title.replace(/ brightness$/, "");
      entry = ["Multiplier applied to the " + filter + " channel when constructing the colour preview and candidate. With automatic SHO normalization enabled, it adjusts the fitted channel. It changes visual channel balance, not photometric calibration.",
         ["R", "G", "B"].indexOf(filter) >= 0 ? "Start at 1 for broadband galaxies, reflection nebulae and clusters; judge final colours after gradient correction and SPCC." :
         "For SHO start at 1 after automatic channel normalization, then compare emission structure and weak-channel noise before making small refinements."];
   }
   if (entry) daUiHelp(control, title, entry[0], entry[1]);
   return !!entry;
}
function daUiMethodHelp(control, method) {
   var advice = /Deconvolution|BlurXTerminator|Parallax/.test(method) ?
      "For galaxies inspect arms and cores; for nebulae preserve genuine filaments and dust. For clusters check isolated stars and the crowded core for ringing or false detail. Begin conservatively and compare at 100%." :
      /StarNet|StarXTerminator|Starless/.test(method) ?
      "Useful for separate development of nebulae or galaxies. For globular/open clusters the stars are the subject: consider skipping removal, and reject results that damage the crowded core. Inspect both starless and extracted-star layers." :
      /NoiseXTerminator|MLDenoise|Prism/.test(method) ?
      "Use moderate noise reduction after gradient and colour review. Check faint reflection dust, galaxy arms, emission filaments and small cluster stars at 100%; real structure in the removed signal is a reason to reduce strength or skip." :
      "Protect galaxy halos, nebular emission, reflection dust and cluster outskirts. Inspect the removed gradient for real target signal before accepting.";
   var description = /saved/i.test(method) ? "Loads your saved native process parameters, then creates a new candidate for review." :
      /MGC/.test(method) ? "Opens guided MARS reference-file, astrometry and SPFC setup before creating an MGC gradient candidate. Requires supported broadband RGB and reference coverage." :
      /Deconvolution/.test(method) ? "Opens native controls on a saved working copy. Prepare a measured PSF and optional local deringing support, then save the result and resume." :
      /Parallax|Prism|SyQon|Starless/.test(method) ? "Opens a working copy for the SyQon script. Choose its installed model tier in the plugin, keep linear data and dimensions, save the copy and resume for review." :
      /DBE/.test(method) ? "Opens a working copy for the selected DBE script or native process. Place/check background samples, save the corrected image and resume for review." :
      /MLDenoise/.test(method) ? "Opens model and amount settings, then creates a full-size noise-reduction candidate for review." :
      /GraXpert/.test(method) ? "Creates a background-subtraction candidate with the installed GraXpert AI model and saved settings." :
      /guided protection/.test(method) ? "Opens scale, smoothness, structure-protection and model controls inside this script. Create a full-size trial from the accepted input, then inspect Before, Candidate, Removed signal and saved protection masks." :
      /StarNet/.test(method) ? "Creates a starless candidate with StarNet2 Linear Data mode and a linked screen stretch; saves linear stars for later recombination." :
      "Creates a full-size candidate with a new native process instance and its defaults. Interface settings from a previously opened process are not inherited.";
   daUiHelp(control, method, description, advice);
}
function daUiActionHelp(control, action) {
   if (action === "correct-optics") {
      daUiHelp(control, "Optical correction before SPCC", "Choose BlurXTerminator Correct Only, SyQon Parallax aberration correction, or advanced native Deconvolution. Opening this chooser does not process an image. Each method uses a separate linear RGB candidate for review.", "Optional: use when star shapes warrant correction. Parallax should have star reduction and sharpening disabled here. Native Deconvolution requires an appropriate PSF and conservative settings; it has no dedicated correction-only mode. Inspect stars and halos before accepting, and recompute astrometry if centroids changed.");
      return;
   }
   if (["edit-image", "accept-image-edit", "discard-image-edit"].indexOf(action) >= 0) {
      daUiHelp(control, action === "edit-image" ? "Develop detail and contrast" : action === "accept-image-edit" ? "Accept developed image" : "Discard working copy",
         action === "edit-image" ? "Open a separate copy of the accepted nonlinear image for native masked contrast, curves or core compression, following the object recipe. Save the copy and return to review before accepting." :
         action === "accept-image-edit" ? "Validate the edited working copy and publish a new image version. The source and earlier versions are preserved. Manual tool parameters are not captured automatically." : "Close the working copy and return to the retained image without publishing its edits.",
         "For galaxies enhance well-exposed arms around dust lanes; for reflection dust protect faint wisps and sky; for clusters protect stars and the crowded core. Inspect at 100% before accepting.");
      return;
   }
   var actions = {
      "skip": "Keep the accepted input and continue past this step. During review the unaccepted candidate is discarded.",
      "accept": "Accept the reviewed candidate and continue. Changed settings require a new candidate first.",
      "accept-palette": "Build the selected full-size colour combination and begin the guided processing checkpoints. L and Ha additions are reviewed later when selected.",
      "retry": "Return to method selection using the accepted input, without accepting this candidate.",
      "create": "Create a full-size candidate with the displayed settings. Review it before acceptance.",
      "regenerate": "Create a new full-size candidate from the accepted input using the changed settings.",
      "keep-comparison": "Save this unaccepted result for comparison, then return to method selection. This uses additional disk space.",
      "compare-candidates": "Compare the accepted input and saved alternative results at 100%, with matching regions and a difference view.",
      "prepare-deconvolution": "Select a measured PSF and optional local deringing support, or open a measurement copy to prepare them in PixInsight.",
      "configure-gradient": "Edit the installed GraXpert executable, background model and smoothing settings before creating a candidate.",
      "guided-gradient": "Adjust native GradientCorrection scale, smoothness and protection inside the script. Each trial starts from the accepted linear input, records its settings, and preserves the previous working trial for comparison.",
      "gradient-diagnostics": "Inspect the saved native protection masks and gradient models. Black areas in protection masks are protected. Check whether real nebulosity appears in the model or outside the protected region.",
      "compare-gradient-trial": "Compare the previous and current gradient trials with the same display treatment, without accepting either one.",
      "configure-spcc": "Select and confirm the real camera QE and RGB filter transmission curves for colour calibration.",
      "apply-spcc": "Run SPCC on the solved linear image with the confirmed responses, then review the colour-calibrated candidate.",
      "auto-solve-spcc": "Use the installed ImageSolver with capture/sky metadata to solve coordinates before SPCC. Review any solving failure before retrying.",
      "solve-spcc": "Open a saved working copy for manual ImageSolver. Save the solved image and resume the colour-calibration checkpoint.",
      "apply-luminance": "Match a reviewed linear L copy to RGB luminance with native LinearFit, then create a linear blend preserving RGB channel ratios. Matching does not remove L gradients; review the full-size result.",
      "prepare-l-detail": "Optional: recover L detail with BlurXTerminator, reduce noise with MLDenoise, or apply MLDenoise after BlurXTerminator. Strength sliders update a padded original-pixel region. Parallax/native Deconvolution use a manual L copy. Review the full-size result before accepting.",
      "apply-blur-settings": "Choose BlurXTerminator or SyQon Parallax for detail recovery. BlurXTerminator provides live native strength previews; Parallax prepares a working copy and pauses the script for SyQon's own model/style controls. Both require review before acceptance.",
      "prepare-l-background": "Prepare a separate linear L copy with native GradientCorrection, DBE or ABE, or review an already corrected L. For dust and galaxy halos protect real faint structure in the background model. Apply, save and continue this session for review.",
      "open-custom": "Open a working copy for a native manual process. Follow the instructions, save to the displayed path and resume for review.",
      "open-crop-v2": "Open the actual crop candidate and DynamicCropV2, then pause the script to release PixInsight. Crop, apply and save the working copy, then Continue recent session to review. For an edge crop keep scale at 1 and avoid unintended rotation.",
      "edit-crop": "Reopen the existing crop working image in DynamicCrop and pause the script. Further edits use the same candidate, preserving the accepted input. Save before closing PixInsight and resume to review.",
      "edit-crop-v2": "Reopen the existing crop working image in DynamicCropV2 and pause the script. It appears only when the module is installed. Keep scale at 1 for an edge-only crop; apply and save, then resume to review.",
      "replace-stars": "Create the recombined image from the developed starless layer and stretched stars. Inspect halos, clipping and cluster cores before accepting.",
      "edit-starless": "Open a separate copy of the accepted starless image for native colour, contrast or structure adjustments. Save and resume to review the edit.",
      "accept-edit": "Accept the saved starless edit after inspection, then continue to star recombination.",
      "discard-edit": "Discard the pending starless edit and retain the previously accepted starless image.",
      "new-version": "Start a separate session from the original reviewed masters, carrying forward the current colour weights and L/Ha contributions for a new review.",
      "adjust-stars": "Return to star-layer controls to change star brightness, amount or blend and review a replacement candidate.",
      "keep-current": "Keep the previously accepted finished image and discard the pending replacement or edit.",
      "open-finished": "Open the finished image in PixInsight for inspection or export.",
      "branch-checkpoint": "Start a separate version from a retained accepted checkpoint; the original finished session is preserved.",
      "mars-files": "Select downloaded .xmars reference database files that cover this field and its required RGB filters.",
      "mars-gaia-setup": "Choose your downloaded Gaia DR3/SP folder or .xpsd files, then configure and validate PixInsight's spectral catalogue here. The same catalogue can supply stars for plate solving. MARS files are separate.",
      "mars-solve-setup": "Review capture coordinates, image scale and observation time, then run ImageSolver inside this workspace. Successful solving saves a separate metadata-only copy and returns here. Configure Gaia first.",
      "mars-spfc-setup": "Confirm the actual camera QE and RGB filter responses used for flux calibration before MGC.",
      "mars-mgc-icon": "Edit gradient scale, structure separation, smoothness and MARS reference bands. Start with native defaults; optionally load a saved PixInsight icon. Save settings returns here without processing an image.",
      "mars-mgc-defaults": "Clear the saved MGC icon choice and use the script's native MGC defaults.",
      "mars-auto-solve": "Solve the image coordinates automatically using the installed ImageSolver and capture metadata.",
      "mars-manual-solve": "Open a saved working copy for manual ImageSolver. Keep geometry unchanged, save it and resume this setup page.",
      "mars-spfc": "Run flux calibration on the solved image using confirmed responses and the configured Gaia DR3/SP catalogue.",
      "mars-back": "Return to the gradient method choices without creating an MGC candidate.",
      "mars-mgc": "Create the MGC gradient candidate after checking MARS references, astrometry and flux calibration. Inspect the removed model for real dust or emission.",
      "ha-noise": "Create a noise-reduced candidate from the separate linear Ha layer. RGB is unchanged; inspect real emission and star profiles before accepting.",
      "pause": "Save the current checkpoint and return control to PixInsight. Reopen DanAstroPhoto → Process → Continue recent session to resume.",
      "back": "Return to the preceding workspace page without applying this settings page."
   };
   var text = actions[action];
   if (!text && /apply-|open-deconvolution|manual-gradient|auto-gradient/.test(action)) {
      daUiMethodHelp(control, control.text); return;
   }
   if (text) daUiHelp(control, control.text, text);
}
