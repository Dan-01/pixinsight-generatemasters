function gmBuildWorkspace() {
   daUiBase(this);
   this.windowTitle = "GenerateMasters"; this.daWorkspace = true;
   var self = this, preferences = gmReadPreferences();
   this.sourceEdit = new Edit(this); this.sourceEdit.text = preferences.source || "";
   this.calibrationSourceEdit = new Edit(this); this.calibrationSourceEdit.text = preferences.calibrationSource || "";
   this.outputEdit = new Edit(this); this.outputEdit.text = preferences.output || "";
   this.operatorEdit = new Edit(this); this.operatorEdit.text = preferences.folderWorkflow ? preferences.operator || "" : "";
   this.configEdit = new Edit(this); this.configEdit.text = File.exists(gmBundledConfig) ? gmBundledConfig : "";
   this.nodeEdit = new Edit(this); this.nodeEdit.text = gmNodePath();
   this.qualityDecisionsEdit = new Edit(this); this.qualityDecisionsEdit.hide();
   this.masterAcceptanceEdit = new Edit(this); this.masterAcceptanceEdit.hide();
   this.dryRun = new CheckBox(this); this.dryRun.checked = false; this.dryRun.hide();
   this.retryFailed = new CheckBox(this); this.retryFailed.text = "Retry a failed run";
   this.drizzle = new CheckBox(this); this.drizzle.text = "Use 2× drizzle (also keep a normal master for comparison)";
   this.drizzle.checked = Boolean(preferences.drizzle);
   daUiHelp(this.drizzle, "2× drizzle", "Reconstruct masters at twice the width and height from the calibrated frames and their registered subpixel offsets. Per-frame pixel rejection is carried through from ImageIntegration. Normal masters and drizzle coverage maps are also saved.", "Leave off initially. Review inputs checks frame counts; master review adds measured star sampling and, for drizzle runs, offset coverage. Recommendations are advisory. 2× images have four times as many pixels and need more disk space.");
   this.confirmCalibrationIdentity = new CheckBox(this);
   this.confirmCalibrationIdentity.text = "Confirm missing master-dark metadata from capture records";
   daUiHelp(this.confirmCalibrationIdentity, "Missing master-dark metadata", "Only needed if an existing master lacks camera settings or temperature in its header. Confirm these match the lights after checking your capture records.", "Known mismatches are always rejected.");
   this.validation = daUiNotice(this, "", "info");
   this.values = function() {
      return { source: self.sourceEdit.text, calibrationSource: self.calibrationSourceEdit.text,
         output: self.outputEdit.text };
   };
   this.validateInputs = function() {
      var errors = gmValidateValues(self.values());
      for (var field of [self.sourceEdit, self.calibrationSourceEdit])
         if (field.text.trim() && !File.directoryExists(field.text.trim()))
            errors.push("Folder does not exist:\n" + field.text.trim() + "\nUse Browse to select the folder, including any spaces in its name.");
      daUiSetNotice(self.validation, errors.length ? "warning" : "success",
         errors.length ? errors.join("\n\n") : "Ready. Filters, exposures and matching calibration will be detected from the image headers.",
         errors.length ? "Check your folders" : "Ready for input review");
      if (self.runButton) self.runButton.enabled = errors.length === 0;
      if (self.reviewButton) self.reviewButton.enabled = errors.length === 0;
      return errors.length === 0;
   };
   var workspace = daUiWorkspace(this, "Generate", "Lights + calibration → linear masters");
   this.workspace = workspace;
   workspace.tools.add(daUiEmphasis(daUiText(this, "Generate masters"), "section"));
   workspace.tools.add(daUiText(this, "1. Choose the lights folder.\n2. Choose the darks / flats folder.\n3. Generate masters."));
   workspace.tools.add(daUiText(this, "Subfolders are included. 600s luminance and 300s RGB automatically use their own matching darks. Flats match by filter; dark-flats match the flat exposure."));
   workspace.tools.addStretch();
   var folders = daUiGroup(this, "Folders");
   function row(group, title, edit, caption) {
      var label = new Label(self); label.text = title;
      label.setFixedWidth(daUiLabelWidth(label, ["Darks / flats folder", "Save masters to"], 165));
      label.textAlignment = TextAlignment.Right | TextAlignment.VertCenter;
      edit.minWidth = 280;
      var line = new HorizontalSizer; line.spacing = 6;
      line.add(label); line.add(edit, 100);
      if (caption) line.add(gmDirectoryButton(self, edit, caption));
      group.sizer.add(line);
   }
   daUiHelp(this.sourceEdit, "Lights folder", "Choose the folder containing this target's original LIGHT FITS files. All subfolders are scanned and filters, exposure times, target and camera settings are read automatically.", "Calibration frames stored here are also found. Choose one target per run.");
   daUiHelp(this.calibrationSourceEdit, "Darks / flats folder", "Choose the folder containing raw darks, flats and dark-flats, or existing MasterDark FITS/XISF images. Subfolders are searched. It can be the same folder as the lights.", "For a shared dark library, choose its parent folder containing both 300s and 600s. Flats beside the lights take priority over shared flats.");
   daUiHelp(this.outputEdit, "Save masters to", "Optional output folder. Blank creates a folder named after the lights folder with Masters appended, outside both input folders.", "Input review shows the chosen output location before processing.");
   row(folders, "Lights folder", this.sourceEdit, "Choose lights folder");
   row(folders, "Darks / flats folder", this.calibrationSourceEdit, "Choose darks / flats folder");
   row(folders, "Save masters to", this.outputEdit, "Choose output folder");
   folders.sizer.add(daUiText(this, "Blank output creates a Masters folder outside both input folders. Original images are kept untouched."));
   workspace.work.add(folders);
   workspace.work.add(this.drizzle);
   this.drizzle.onCheck = function() { self.qualityDecisionsEdit.text = ""; self.masterAcceptanceEdit.text = ""; };
   var advancedToggle = new CheckBox(this); advancedToggle.text = "Advanced";
   var advanced = daUiGroup(this, "Advanced"); this.advancedGroup = advanced; advanced.hide();
   daUiHelp(this.operatorEdit, "Captured by", "Optional name for processing records. Blank uses your computer account name.", "Use the same name when resuming a run.");
   daUiFieldHelp(this.configEdit, "Runtime settings file"); daUiFieldHelp(this.nodeEdit, "Node executable");
   row(advanced, "Captured by", this.operatorEdit);
   row(advanced, "Runtime settings file", this.configEdit);
   row(advanced, "Node executable", this.nodeEdit);
   advanced.sizer.add(this.retryFailed); advanced.sizer.add(this.confirmCalibrationIdentity);
   advancedToggle.onCheck = function(checked) { advanced.visible = checked; if (self.daRefreshWorkspace) self.daRefreshWorkspace(); };
   workspace.work.add(advancedToggle); workspace.work.add(advanced); workspace.work.addStretch();
   daUiWorkspaceNotice(workspace, this.validation);
   var buttons = new HorizontalSizer; buttons.spacing = 8; buttons.addStretch();
   this.reviewButton = new PushButton(this); this.reviewButton.text = "Review inputs";
   this.reviewButton.onClick = function() {
      try { if (!self.validateInputs()) return; var result = gmRun(self, true); if (result && result.manifestPath) { self.publication = result; self.cancel(); } }
      catch (error) { console.criticalln(String(error)); self.showRunError(error); }
   };
   var close = new PushButton(this); close.text = "Close";
   close.onClick = function() { if (!Parameters.has("generateMastersSelfTest")) gmSavePreferences(self); self.cancel(); };
   this.runButton = daUiEmphasis(new PushButton(this), "primary"); this.runButton.text = "Generate / resume masters";
   this.runButton.onClick = function() { if (self.validateInputs()) self.ok(); };
   this.showRunError = function(error) {
      self.validateInputs();
      daUiSetNotice(self.validation, "error", "Check the folders and choose Review inputs again.\n\n" + String(error), "Generation stopped");
      if (self.daRefreshWorkspace) self.daRefreshWorkspace();
   };
   buttons.add(this.reviewButton); buttons.add(close); buttons.add(this.runButton); workspace.footer.add(buttons, 100);
   for (var edit of [this.sourceEdit, this.calibrationSourceEdit, this.outputEdit, this.operatorEdit]) {
      edit.onTextUpdated = function() {
         self.qualityDecisionsEdit.text = ""; self.masterAcceptanceEdit.text = ""; self.validateInputs();
      };
      edit.onEditCompleted = function() { this.text = this.text.trim(); self.validateInputs(); };
   }
   this.sizer = workspace.root; this.adjustToContents(); this.validateInputs(); workspace.refresh();
}

class GenerateMastersDialog extends Dialog {
constructor() { super(); gmBuildWorkspace.call(this); }
}
