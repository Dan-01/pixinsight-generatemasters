function gmValidateValues(values) {
   var errors = [];
   if (!String(values.source || "").trim()) errors.push("Choose the lights folder");
   if (!String(values.calibrationSource || "").trim()) errors.push("Choose the darks / flats folder");
   return errors;
}
function gmReadPreferences() {
   try { return JSON.parse(Settings.read("DanAstroPhoto/generatePreferences", DataType.String) || "{}"); }
   catch (_) { return {}; }
}
function gmSavePreferences(dialog) {
   Settings.write("DanAstroPhoto/generatePreferences", DataType.String, JSON.stringify({
      folderWorkflow: 1, source: dialog.sourceEdit.text.trim(),
      calibrationSource: dialog.calibrationSourceEdit.text.trim(),
      output: dialog.outputEdit.text.trim(), operator: dialog.operatorEdit.text.trim(),
      drizzle: Boolean(dialog.drizzle && dialog.drizzle.checked)
   }));
}
function gmDrizzleRecommendationText(rows) {
   return (rows || []).map(function(row) {
      return row.key + " (" + row.frames + " frames" +
         (row.medianFwhmPixels === null ? "" : ", median FWHM " + row.medianFwhmPixels.toFixed(2) + " px") +
         "): " + row.reason;
   }).join("\n");
}
