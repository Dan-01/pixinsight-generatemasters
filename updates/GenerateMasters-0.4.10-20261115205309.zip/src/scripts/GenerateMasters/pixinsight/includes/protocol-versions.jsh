// Generated from packages/shared/src/protocol.ts; run npm run sync:protocol.
var BRIDGE_PROTOCOL_VERSION = 1;
var ONE_RUN_ADAPTER = "pixinsight-one-run-stage/7";
var RUNNER_EVENT_VERSION = 2;
var RUNNER_EVENT_PREFIX = "PIPROC_EVENT ";
