// Incremental line framing tolerates arbitrary ExternalProcess stdout chunks.
function gmEventParser(receive) {
   var pending = "";
   function line(text) {
      var prefix = RUNNER_EVENT_PREFIX;
      if (text.indexOf(prefix) !== 0) return;
      var event = JSON.parse(text.substring(prefix.length));
      if (event.version !== RUNNER_EVENT_VERSION ||
          ["info", "stage", "preflight", "quality-review", "master-review", "result", "error"].indexOf(event.type) < 0 ||
          !event.data || typeof event.data !== "object")
         throw new Error("Unsupported GenerateMasters runner event");
      receive(event);
   }
   return {
      push: function(chunk) {
         pending += chunk;
         var end;
         while ((end = pending.indexOf("\n")) >= 0) {
            line(pending.substring(0, end));
            pending = pending.substring(end + 1);
         }
      },
      finish: function() { if (pending) line(pending); pending = ""; }
   };
}
