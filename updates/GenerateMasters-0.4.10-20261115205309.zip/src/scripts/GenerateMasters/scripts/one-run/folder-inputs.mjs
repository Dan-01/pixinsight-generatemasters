import { basename, dirname, isAbsolute, relative, resolve, sep } from "node:path";
import { userInfo } from "node:os";
import { normalizeTarget } from "@piproc/shared";
import { scanSource } from "./inventory.mjs";
import { buildProfileDraft } from "./profile-wizard.mjs";

// A fresh description of this capture, never a saved profile's folders or masters.
export async function folderInputs(options) {
  if (!options.source?.trim()) throw new Error("Choose the lights folder");
  const source = resolve(options.source);
  const calibrationSource = resolve(options["calibration-source"] || source);
  const fromCalibration = relative(calibrationSource, source);
  const enclosingRoot = !isAbsolute(fromCalibration) && fromCalibration !== ".." && !fromCalibration.startsWith(".." + sep)
    ? calibrationSource : source;
  const output = resolve(options.output || resolve(dirname(enclosingRoot), basename(source) + " Masters"));
  const sourceIndex = await scanSource(source);
  const lights = sourceIndex.filter(item => item.metadata.frameType === "LIGHT");
  if (!lights.length) throw new Error("No LIGHT FITS frames found in " + source);
  const targets = new Set(lights.map(item => normalizeTarget(item.metadata.targetName ?? "")));
  if (targets.size !== 1)
    throw new Error("The lights folder contains multiple targets. Choose one target's folder: " +
      [...new Set(lights.map(item => item.metadata.targetName || "(missing OBJECT)"))].join(", "));
  const sample = lights[0];
  const { draft: profile } = await buildProfileDraft(sample.path, source, output,
    options.operator || userInfo().username,
    [sample.metadata.telescopeName, sample.metadata.cameraName].filter(Boolean).join(" / "), sourceIndex);
  // Flats are chosen from the actual folders below, independently of light duration.
  profile.flatExposureSeconds = {};
  profile.calibrationSourceRoot = calibrationSource;
  return { profile, sourceIndex, source, output };
}
