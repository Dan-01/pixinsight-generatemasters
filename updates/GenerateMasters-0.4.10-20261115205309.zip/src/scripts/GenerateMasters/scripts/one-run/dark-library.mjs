import { readFile, readdir } from "node:fs/promises";
import { resolve } from "node:path";
import { readFitsMetadata } from "@piproc/fits";
import { canonicalJson, fileChecksum, verifyChecksum } from "@piproc/shared";
import { exposureGroups } from "./profile.mjs";
import { verifyImage, readXisfExposure } from "./images.mjs";
import { assertMasterAcquisition, assertSameSettings, calibrationAcquisition, temperatureTolerance } from "./identity.mjs";
import { loadStandaloneDarks } from "./standalone-darks.mjs";

async function* manifests(root) {
  for (const entry of await readdir(root, { withFileTypes: true })) {
    const path = resolve(root, entry.name);
    if (entry.isDirectory()) yield* manifests(path);
    else if (entry.isFile() && entry.name === "master-dark-library.json") yield path;
  }
}

// Preparation records retain source identities; raw subs are not required to
// reuse a finished master. Check the actual images and recorded acquisition.
export async function loadDarkLibraries(roots, profile, lights, options = {}) {
  const explicit = options.paths?.length ? await loadStandaloneDarks([], profile, lights, options) : {};
  const result = { ...explicit };
  const needed = new Set(exposureGroups(profile).map((g) => String(g.exposureSeconds)));
  const seen = new Set();
  for (const root of roots) for await (const path of manifests(root)) {
    if (seen.has(path)) continue;
    seen.add(path);
    const library = JSON.parse(await readFile(path, "utf8"));
    if (library.schema !== "DanAstroPhoto.master-dark-library/1")
      throw new Error("Unsupported master-dark library: " + path);
    const exposure = String(library.exposureSeconds);
    if (!needed.has(exposure)) continue;
    if (explicit[exposure]) continue;
    const master = library.master;
    if (!master?.path || !master.nativePath || !master.registrationId ||
        master.preparation?.method !== "INTEGRATED_RAW" ||
        !master.preparation.operator || !master.preparation.toolVersion ||
        !Array.isArray(master.preparation.parentMasters) ||
        !Number.isInteger(library.frameCount) || library.frameCount < 3)
      throw new Error("Incomplete master-dark library: " + path);
    for (const key of ["cameraName", "cameraDriver", "readoutMode", "binX", "binY", "width", "height"])
      if (library.equipment?.[key] !== profile.equipment[key])
        throw new Error(`Saved ${exposure}s dark equipment mismatch: ${key}`);
    if (!Number.isFinite(library.equipment.electronsPerAdu) ||
        Math.abs(library.equipment.electronsPerAdu - profile.equipment.electronsPerAdu) > 1e-6)
      throw new Error(`Saved ${exposure}s dark gain mismatch`);
    for (const [file, checksum] of [[master.path, master.checksum],
      [master.nativePath, master.nativeChecksum],
      ...["profileRequest", "profileReceipt"].map((kind) => [
        master.preparation[kind + "Path"], master.preparation[kind + "Checksum"]]),
      ...["low", "high"].map((kind) => [master.rejectionMaps?.[kind]?.path,
        master.rejectionMaps?.[kind]?.checksum])]) {
      if (!file || !/^[a-f0-9]{64}$/i.test(checksum ?? ""))
        throw new Error("Incomplete saved dark checksum or provenance: " + path);
      await verifyChecksum(file, checksum);
    }
    const request = JSON.parse(await readFile(master.preparation.profileRequestPath, "utf8"));
    const receipt = JSON.parse(await readFile(master.preparation.profileReceiptPath, "utf8"));
    if (request.schema !== "DanAstroPhoto.master-dark-request/1" ||
        receipt.schema !== "DanAstroPhoto.master-dark-receipt/1" ||
        !receipt.success || receipt.pixelCheck?.invalidPixels !== 0 ||
        request.exposureSeconds !== library.exposureSeconds ||
        receipt.exposureSeconds !== library.exposureSeconds ||
        receipt.frameCount !== library.frameCount ||
        receipt.fits?.checksum !== master.checksum || receipt.native?.checksum !== master.nativeChecksum ||
        receipt.statistics?.numberOfImages !== library.frameCount ||
        request.inputs?.length !== library.frameCount ||
        new Set(request.inputs.map((f) => f.checksum)).size !== library.frameCount ||
        canonicalJson(request.inputs.map((f) => f.checksum).sort()) !==
        canonicalJson([...(master.preparation.inputChecksums ?? [])].sort()) ||
        canonicalJson(calibrationAcquisition(request.inputs.map((f) => f.metadata), "DARK")) !==
        canonicalJson(master.acquisition))
      throw new Error("Saved dark preparation records are inconsistent: " + path);
    for (const input of request.inputs) {
      if (input.metadata.frameType !== "DARK" || input.metadata.exposureSeconds !== library.exposureSeconds)
        throw new Error("Saved dark has incompatible source exposure: " + path);
      for (const key of Object.keys(library.equipment))
        if (input.metadata[key] !== library.equipment[key])
          throw new Error("Saved dark has inconsistent source equipment: " + path);
    }
    const metadata = await readFitsMetadata(master.path);
    assertSameSettings(metadata, master.acquisition, master.path);
    for (const key of ["cameraName", "cameraDriver", "readoutMode", "binX", "binY", "width", "height"])
      if (metadata[key] !== library.equipment[key])
        throw new Error("Saved dark image identity differs from its record: " + key);
    if (metadata.rawHeaders.DAPMASTR !== "DARK" ||
        !Number.isFinite(metadata.electronsPerAdu) ||
        Math.abs(metadata.electronsPerAdu - library.equipment.electronsPerAdu) > 1e-6 ||
        !Number.isFinite(metadata.sensorTemperature) ||
        metadata.sensorTemperature < master.acquisition.temperatureRangeC[0] ||
        metadata.sensorTemperature > master.acquisition.temperatureRangeC[1] ||
        metadata.rawHeaders.NCOMBINE !== library.frameCount ||
        metadata.exposureSeconds !== library.exposureSeconds ||
        await readXisfExposure(master.nativePath) !== library.exposureSeconds)
      throw new Error("Saved dark image exposure or frame count is inconsistent: " + path);
    for (const file of [master.path, master.nativePath, master.rejectionMaps.low.path, master.rejectionMaps.high.path])
      await verifyImage(file, profile.equipment);
    const groupLights = lights.filter((f) => f.exposureSeconds === library.exposureSeconds);
    if (groupLights.length && !assertMasterAcquisition(master, groupLights,
      temperatureTolerance(profile), `${exposure}s dark`))
      throw new Error("Saved dark has no acquisition identity: " + path);
    if (result[exposure] && result[exposure].nativeChecksum !== master.nativeChecksum)
      throw new Error(`Multiple different ${exposure}s master darks; select one calibration folder`);
    result[exposure] = { ...master, opticalTrainId: profile.opticalTrainId,
      libraryPath: path, libraryChecksum: await fileChecksum(path) };
  }
  if (!options.paths?.length) {
    const standalone = await loadStandaloneDarks(roots, profile, lights, { ...options,
      ignorePaths: Object.values(result).flatMap(master => [master.nativePath, master.path]) });
    for (const [exposure, master] of Object.entries(standalone)) {
      if (result[exposure] && result[exposure].nativeChecksum !== master.nativeChecksum)
        throw new Error(`Multiple different ${exposure}s master darks. Use Select master darks to choose the one to use.`);
      result[exposure] ??= master;
    }
  }
  return result;
}
