#!/usr/bin/env node
import { writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { normalizeTarget } from "@piproc/shared";
import { readFitsMetadata } from "@piproc/fits";
import { commonFilterAliases, filterKey, validateProfile } from "./profile.mjs";
import { scanSource } from "./inventory.mjs";

function canonicalFilter(value) {
  const key = filterKey(value);
  return Object.entries(commonFilterAliases).find(([name, aliases]) =>
    [name, ...aliases].some((alias) => filterKey(alias) === key))?.[0];
}

export async function buildProfileDraft(samplePath, sourceRoot, outputRoot,
  operator, opticalTrainId, sourceIndex = null) {
  const sample = sourceIndex?.find(item => item.path === samplePath)?.metadata ??
    await readFitsMetadata(samplePath);
  if (sample.frameType !== "LIGHT")
    throw new Error("Choose a representative LIGHT FITS frame");
  for (const key of ["targetName", "cameraName", "cameraDriver", "readoutMode",
    "electronsPerAdu", "binX", "binY", "width", "height"])
    if (sample[key] === null || sample[key] === undefined || sample[key] === "")
      throw new Error("Representative FITS header is missing " + key);
  if (!operator?.trim() || !opticalTrainId?.trim())
    throw new Error("Provide an operator and optical-train ID");
  const index = sourceIndex ?? await scanSource(sourceRoot);
  const lights = index.filter(({ metadata }) => metadata.frameType === "LIGHT" &&
    normalizeTarget(metadata.targetName ?? "") ===
      normalizeTarget(sample.targetName));
  if (!lights.length) throw new Error("No matching LIGHT frames in the source folder");
  const groups = new Map();
  for (const item of lights) {
    const m = item.metadata;
    if (["cameraName", "cameraDriver", "readoutMode", "electronsPerAdu",
      "binX", "binY", "width", "height"].some((key) => m[key] !== sample[key]))
      throw new Error("Conflicting light equipment identity in " + item.path);
    if (m.gain !== sample.gain || m.offset !== sample.offset)
      throw new Error("Conflicting light gain/offset in " + item.path);
    const filter = canonicalFilter(m.filterName);
    if (!filter) throw new Error("Unsupported or ambiguous filter " +
      m.filterName + " in " + item.path);
    if (!(m.exposureSeconds > 0))
      throw new Error("Missing light exposure in " + item.path);
    if (!groups.has(filter)) groups.set(filter, new Set());
    groups.get(filter).add(m.exposureSeconds);
  }
  const filters = [...groups.keys()].sort((a, b) =>
    ["L", "R", "G", "B", "Ha", "OIII", "SII"].indexOf(a) -
    ["L", "R", "G", "B", "Ha", "OIII", "SII"].indexOf(b));
  const flatExposureSeconds = {};
  const warnings = [];
  for (const filter of filters) {
    const exposures = [...new Set(index.filter(({ metadata }) =>
      metadata.frameType === "FLAT" &&
      canonicalFilter(metadata.filterName) === filter)
      .map(({ metadata }) => metadata.exposureSeconds))];
    if (exposures.length === 1) flatExposureSeconds[filter] = exposures[0];
    else warnings.push(exposures.length
      ? `${filter} has multiple flat exposures; select one before preflight.`
      : `${filter} has no flat in the source folder.`);
  }
  if (sample.gain === null || sample.offset === null)
    warnings.push("Numeric gain/offset are missing; driver, readout mode, and EGAIN will be used for identity.");
  if (lights.some(({ metadata }) => !Number.isFinite(metadata.sensorTemperature)))
    warnings.push("Some lights have no measured sensor temperature; raw dark matching will stop until acquisition identity is resolved.");
  const draft = { version: 1,
    name: `${sample.targetName} — ${sample.cameraName}`,
    target: sample.targetName, operator: operator.trim(),
    sourceRoot: resolve(sourceRoot), defaultOutput: resolve(outputRoot),
    opticalTrainId: opticalTrainId.trim(), filters,
    referenceFilter: filters.includes("L") ? "L" : filters[0],
    lightExposureSeconds: Object.fromEntries(filters.map((filter) => {
      const values = [...groups.get(filter)].sort((a, b) => b - a);
      return [filter, values.length === 1 ? values[0] : values];
    })), flatExposureSeconds,
    equipment: { cameraName: sample.cameraName,
      cameraDriver: sample.cameraDriver, readoutMode: sample.readoutMode,
      electronsPerAdu: sample.electronsPerAdu,
      gain: sample.gain ?? null, offset: sample.offset ?? null,
      temperatureToleranceC: 2, binX: sample.binX, binY: sample.binY,
      width: sample.width, height: sample.height },
    integration: { normalization: "ADDITIVE_WITH_SCALING",
      weighting: "EQUAL", rejection: "ESD", sigmaLow: 4, sigmaHigh: 3 },
    excludeChecksums: [], knownApprovedChecksums: [],
    knownCalibrationChecksums: [] };
  validateProfile(draft, true);
  return { draft, warnings, inventory: { lightFrames: lights.length,
    filters, exposures: draft.lightExposureSeconds } };
}

async function main(args) {
  const options = {};
  for (let i = 0; i < args.length; i += 2) {
    if (!["--sample", "--source", "--output", "--operator", "--optical-train",
      "--profile-out"].includes(args[i]) || !args[i + 1])
      throw new Error("Expected --sample, --source, --output, --operator, --optical-train, and --profile-out");
    options[args[i].slice(2)] = args[i + 1];
  }
  for (const key of ["sample", "source", "output", "operator", "optical-train",
    "profile-out"])
    if (!options[key]) throw new Error("Missing --" + key);
  const result = await buildProfileDraft(options.sample, options.source,
    options.output, options.operator, options["optical-train"]);
  const profilePath = resolve(options["profile-out"]);
  await writeFile(profilePath, JSON.stringify(result.draft, null, 2) + "\n",
    { flag: "wx", mode: 0o600 });
  console.log(JSON.stringify({ profilePath, warnings: result.warnings,
    inventory: result.inventory }));
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url))
  main(process.argv.slice(2)).catch((error) => {
    console.error(error.message); process.exitCode = 1;
  });
