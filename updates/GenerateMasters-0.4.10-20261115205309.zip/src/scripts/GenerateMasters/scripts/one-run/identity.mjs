const finite = (value) => typeof value === "number" && Number.isFinite(value);

export function acquisitionSettings(frame, label = frame.path ?? "frame") {
  const gainKnown = finite(frame.gain);
  const offsetKnown = finite(frame.offset);
  if (gainKnown !== offsetKnown)
    throw new Error(`Incomplete gain/offset identity in ${label}`);
  return gainKnown
    ? { mode: "NUMERIC", gain: frame.gain, offset: frame.offset }
    : { mode: "DRIVER_READOUT_EGAIN", gain: null, offset: null };
}

export function assertSameSettings(frame, expected, label = frame.path ?? "frame") {
  const actual = acquisitionSettings(frame, label);
  if (actual.mode !== expected.mode || actual.gain !== expected.gain ||
      actual.offset !== expected.offset)
    throw new Error(`Gain/offset mismatch in ${label}`);
}

export function lightAcquisition(lights, profile) {
  if (!lights.length) throw new Error("No selected lights for acquisition identity");
  const expected = acquisitionSettings(lights[0]);
  for (const light of lights) assertSameSettings(light, expected);
  const configured = profile.equipment;
  if (configured.gain !== undefined || configured.offset !== undefined) {
    const requested = acquisitionSettings(configured, "profile equipment");
    if (requested.mode !== expected.mode || requested.gain !== expected.gain ||
        requested.offset !== expected.offset)
      throw new Error("Selected light gain/offset differs from profile equipment");
  }
  return expected;
}

export function temperatureTolerance(profile) {
  const value = profile.equipment.temperatureToleranceC ?? 2;
  if (!finite(value) || value < 0 || value > 20)
    throw new Error("Equipment temperatureToleranceC must be between 0 and 20 C");
  return value;
}

export function assertTemperatures(referenceFrames, darkFrames, tolerance, label) {
  for (const reference of referenceFrames) {
    if (!finite(reference.sensorTemperature))
      throw new Error(`Measured sensor temperature missing in ${reference.path}`);
    for (const dark of darkFrames) {
      if (!finite(dark.sensorTemperature))
        throw new Error(`Measured sensor temperature missing in ${dark.path}`);
      if (Math.abs(reference.sensorTemperature - dark.sensorTemperature) > tolerance + 1e-9)
        throw new Error(`${label} measured temperature exceeds ${tolerance} C tolerance: ${dark.path}`);
    }
  }
}

export function calibrationAcquisition(frames, kind) {
  if (!frames.length) throw new Error("Empty calibration group");
  const settings = acquisitionSettings(frames[0]);
  for (const frame of frames) assertSameSettings(frame, settings);
  const temperatures = frames.map((frame) => frame.sensorTemperature);
  if ((kind === "DARK" || kind === "DARKFLAT") && temperatures.some((value) => !finite(value)))
    throw new Error(`Measured sensor temperature missing in ${kind} calibration group`);
  return {
    ...settings,
    ...(kind === "DARK" || kind === "DARKFLAT"
      ? { temperatureRangeC: [Math.min(...temperatures), Math.max(...temperatures)] }
      : {}),
  };
}

export function assertMasterAcquisition(master, lights, tolerance, label) {
  const acquisition = master.acquisition;
  if (!acquisition) return false;
  const expected = acquisitionSettings(lights[0]);
  if (acquisition.mode !== expected.mode || acquisition.gain !== expected.gain ||
      acquisition.offset !== expected.offset)
    throw new Error(`Saved ${label} gain/offset does not match selected lights`);
  if (label.includes("dark")) {
    const range = acquisition.temperatureRangeC;
    if (!Array.isArray(range) || range.length !== 2 || range.some((v) => !finite(v)))
      throw new Error(`Saved ${label} lacks measured temperature range`);
    for (const light of lights) {
      if (!finite(light.sensorTemperature))
        throw new Error(`Measured sensor temperature missing in ${light.path}`);
      if (range.some((value) => Math.abs(light.sensorTemperature - value) > tolerance + 1e-9))
        throw new Error(`Saved ${label} measured temperature exceeds ${tolerance} C tolerance`);
    }
  }
  return true;
}
