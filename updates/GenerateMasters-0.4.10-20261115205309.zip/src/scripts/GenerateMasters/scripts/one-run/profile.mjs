export const defaultFilters = ["Ha", "OIII", "SII"];
export const filterKey = (value) =>
  String(value ?? "")
    .toLowerCase()
    .replace(/\s+/g, "");
export const commonFilterAliases = {
  L: ["L", "Lum", "Luminance"],
  R: ["R", "Red"],
  G: ["G", "Green"],
  B: ["B", "Blue"],
  Ha: ["Ha", "H-alpha", "Halpha", "Hα"],
  OIII: ["OIII", "O3"],
  SII: ["SII", "S2"],
};
export function filtersFor(profile) {
  const filters = profile.filters ?? Object.keys(profile.masters?.flats ?? {});
  if (
    !Array.isArray(filters) ||
    !filters.length ||
    filters.some(
      (f) => typeof f !== "string" || !/^[A-Za-z0-9]{1,12}$/.test(f),
    ) ||
    new Set(filters.map(filterKey)).size !== filters.length
  )
    throw new Error("Profile needs unique alphanumeric filter names");
  return filters;
}
export function matchFilter(value, profile) {
  const key = filterKey(value);
  return filtersFor(profile).find((filter) =>
    [
      filter,
      ...(profile.filterAliases?.[filter] ?? commonFilterAliases[filter] ?? []),
    ].some((alias) => filterKey(alias) === key),
  );
}
export function lightExposures(profile, filter) {
  const value =
    typeof profile.lightExposureSeconds === "number"
      ? profile.lightExposureSeconds
      : profile.lightExposureSeconds?.[filter];
  const values = Array.isArray(value) ? value : [value];
  if (
    !values.length ||
    values.some(
      (seconds) =>
        typeof seconds !== "number" ||
        !Number.isFinite(seconds) ||
        !(seconds > 0),
    ) ||
    new Set(values.map(String)).size !== values.length
  )
    throw new Error(`Provide unique positive light exposures for ${filter}`);
  return [...values].sort((a, b) => b - a);
}
export function lightExposure(profile, filter) {
  return lightExposures(profile, filter)[0];
}
export function exposureGroups(profile) {
  return filtersFor(profile).flatMap((filter) =>
    lightExposures(profile, filter).map((exposureSeconds) => ({
      filter,
      exposureSeconds,
    })),
  );
}
export function groupKey(profile, filter, exposureSeconds) {
  return lightExposures(profile, filter).length === 1
    ? filter
    : `${filter}_${exposureSeconds}s`;
}
export function configuredExposures(profile) {
  return Object.fromEntries(
    filtersFor(profile).map((filter) => {
      const values = lightExposures(profile, filter);
      return [filter, values.length === 1 ? values[0] : values];
    }),
  );
}
export function darkFor(
  profile,
  filter,
  exposure = lightExposure(profile, filter),
) {
  return (
    profile.masters?.darkByExposure?.[String(exposure)] ??
    profile.masters?.darks?.[filter]?.[String(exposure)] ??
    (!Array.isArray(profile.masters?.darks?.[filter]) &&
    profile.masters?.darks?.[filter]?.path &&
    lightExposures(profile, filter).length === 1
      ? profile.masters.darks[filter]
      : undefined) ??
    (lightExposures(profile, filter).length === 1
      ? profile.masters?.dark
      : undefined)
  );
}
export function parseArguments(argv) {
  const options = {};
  for (let i = 0; i < argv.length; ++i) {
    const arg = argv[i];
    if (
      [
        "--events",
        "--auto-calibration",
        "--dry-run",
        "--check-native",
        "--current-instance",
        "--retry-failed",
        "--rebuild-masters",
        "--rebuild-dark-masters",
        "--include-unreviewed",
        "--measure-unreviewed",
        "--confirm-optical-train",
        "--confirm-calibration-identity",
        "--skip-quality-measurement",
      ].includes(arg)
    ) {
      options[arg.slice(2)] = true;
      continue;
    }
    if (
      ![
        "--source",
        "--calibration-source",
        "--master-dark-files",
        "--output",
        "--profile",
        "--config",
        "--target",
        "--filters",
        "--exposures",
        "--flat-exposures",
        "--reference-filter",
        "--optical-train",
        "--operator",
        "--pixinsight-executable",
        "--quality-decisions",
        "--master-acceptance",
        "--drizzle",
      ].includes(arg)
    )
      throw new Error("Unknown option: " + arg);
    if (argv[i + 1] === undefined || argv[i + 1].startsWith("--") ||
        (argv[i + 1] === "" && arg !== "--calibration-source"))
      throw new Error("Missing value for " + arg);
    options[arg.slice(2)] = argv[++i];
    if (arg === "--master-dark-files") {
      const paths = JSON.parse(options["master-dark-files"]);
      if (!Array.isArray(paths) || paths.some(path => typeof path !== "string" || !path.trim()))
        throw new Error("Master dark files must be a JSON array of file paths");
      options["master-dark-files"] = paths;
    }
  }
  if (options["current-instance"] && !options.events)
    throw new Error("--current-instance requires --events and the GenerateMasters desktop host");
  return options;
}

export function parseExposures(value, filters) {
  const result = {};
  for (const pair of value.split(",")) {
    const parts = pair.trim().split("=");
    const filter = filters.find((f) => filterKey(f) === filterKey(parts[0]));
    const seconds = parts[1]?.split("+").map(Number);
    if (
      parts.length !== 2 ||
      !filter ||
      result[filter] !== undefined ||
      !seconds?.length ||
      seconds.some((item) => !(item > 0) || !Number.isFinite(item)) ||
      new Set(seconds.map(String)).size !== seconds.length
    )
      throw new Error(
        "Exposures must be filter=seconds or filter=long+short with unique positive durations",
      );
    result[filter] =
      seconds.length === 1 ? seconds[0] : seconds.sort((a, b) => b - a);
  }
  if (Object.keys(result).length !== filters.length)
    throw new Error("Provide light exposures for every selected filter");
  return result;
}

export function parseOptionalExposures(value, filters) {
  if (!value.trim()) return {};
  const result = {};
  for (const pair of value.split(",")) {
    const parts = pair.trim().split("=");
    const filter = filters.find((f) => filterKey(f) === filterKey(parts[0]));
    const seconds = Number(parts[1]);
    if (
      parts.length !== 2 ||
      !filter ||
      result[filter] !== undefined ||
      !(seconds > 0) ||
      !Number.isFinite(seconds)
    )
      throw new Error(
        "Flat exposures must be unique selected-filter=seconds pairs",
      );
    result[filter] = seconds;
  }
  return result;
}

// An exposure exception is an explicit, content-bound operator decision, never
// a wider matching tolerance. Keep it reusable in profiles and provenance.
export function validateDarkFlatExposureApprovals(profile) {
  const approvals = profile.darkFlatExposureApprovals;
  if (approvals === undefined) return;
  if (!approvals || typeof approvals !== "object" || Array.isArray(approvals))
    throw new Error("Invalid dark-flat exposure approvals");
  const filters = filtersFor(profile);
  for (const [filter, approval] of Object.entries(approvals)) {
    if (!filters.includes(filter) || !approval ||
        ["operator", "reason"].some((key) =>
          typeof approval[key] !== "string" || !approval[key].trim()) ||
        ["flatExposureSeconds", "darkFlatExposureSeconds"].some((key) =>
          typeof approval[key] !== "number" || !Number.isFinite(approval[key]) || approval[key] <= 0) ||
        ["flatChecksums", "darkFlatChecksums"].some((key) =>
          !Array.isArray(approval[key]) || approval[key].length < 3 ||
          approval[key].some((checksum) => typeof checksum !== "string" || !/^[a-f0-9]{64}$/.test(checksum)) ||
          new Set(approval[key]).size !== approval[key].length))
      throw new Error(`Invalid ${filter} dark-flat exposure approval`);
  }
}

export function validateProfile(profile, rebuildMasters = false) {
  if (profile.version !== 1 || !profile.target || !profile.equipment)
    throw new Error("Unsupported or incomplete one-run profile");
  if (!profile.opticalTrainId)
    throw new Error("Profile requires an optical-train identity");
  if (typeof profile.operator !== "string" || !profile.operator.trim())
    throw new Error("Profile requires an operator name");
  const filters = filtersFor(profile);
  if (profile.referenceChecksum !== undefined && profile.referenceChecksum !== null &&
      !/^[a-f0-9]{64}$/i.test(profile.referenceChecksum))
    throw new Error("Registration reference checksum must be SHA-256");
  validateDarkFlatExposureApprovals(profile);
  if ((profile.equipment.gain !== undefined || profile.equipment.offset !== undefined) &&
      !((typeof profile.equipment.gain === "number" && Number.isFinite(profile.equipment.gain) &&
         typeof profile.equipment.offset === "number" && Number.isFinite(profile.equipment.offset)) ||
        (profile.equipment.gain === null && profile.equipment.offset === null)))
    throw new Error("Equipment gain and offset must both be numeric or both null");
  if (profile.equipment.temperatureToleranceC !== undefined &&
      (typeof profile.equipment.temperatureToleranceC !== "number" ||
       !Number.isFinite(profile.equipment.temperatureToleranceC) ||
       profile.equipment.temperatureToleranceC < 0 ||
       profile.equipment.temperatureToleranceC > 20))
    throw new Error("Equipment temperatureToleranceC must be between 0 and 20 C");
  for (const filter of filters) lightExposures(profile, filter);
  if (!rebuildMasters)
    for (const [name, master] of [
      ...exposureGroups(profile).map(({ filter, exposureSeconds }) => [
        `${filter} ${exposureSeconds}s dark`,
        darkFor(profile, filter, exposureSeconds),
      ]),
      ...filters.map((filter) => [
        filter + " flat",
        profile.masters?.flats?.[filter],
      ]),
    ]) {
      if (
        !master?.path ||
        !/^[a-f0-9]{64}$/i.test(master.checksum ?? "") ||
        !master.nativePath ||
        !/^[a-f0-9]{64}$/i.test(master.nativeChecksum ?? "") ||
        !master.registrationId ||
        master.opticalTrainId !== profile.opticalTrainId ||
        !master.preparation?.method ||
        !master.preparation?.operator ||
        !master.preparation?.toolVersion ||
        !Array.isArray(master.preparation?.inputChecksums) ||
        !master.preparation.inputChecksums.length ||
        !Array.isArray(master.preparation.parentMasters) ||
        (master.preparation.method === "IMPORTED_MASTER" && !name.endsWith(" dark"))
      )
        throw new Error(
          "Profile requires a validated " +
            name +
            " registration and preparation lineage; select --rebuild-masters for raw calibration frames",
        );
    }
  if (
    !["ADDITIVE_WITH_SCALING", "LOCAL_NORMALIZATION"].includes(profile.integration?.normalization) ||
    !["EQUAL", "PSF_SIGNAL"].includes(profile.integration?.weighting) ||
    !["ESD", "WINSORIZED_SIGMA"].includes(profile.integration?.rejection) ||
    !(profile.integration.sigmaLow > 0) ||
    !(profile.integration.sigmaHigh > 0) ||
    (profile.integration.localNormalizationScale !== undefined &&
      (!Number.isInteger(profile.integration.localNormalizationScale) ||
       profile.integration.localNormalizationScale < 128 ||
       profile.integration.localNormalizationScale > 4096))
  )
    throw new Error("Unsupported integration recipe");
  if (!Array.isArray(profile.excludeChecksums))
    throw new Error("Profile requires an explicit exclusion list");
  const claimedAliases = new Map();
  for (const filter of filters) {
    const choices =
      profile.filterAliases?.[filter] ?? commonFilterAliases[filter] ?? [];
    if (
      !Array.isArray(choices) ||
      choices.some((alias) => typeof alias !== "string")
    )
      throw new Error("Invalid aliases for " + filter);
    for (const alias of [filter, ...choices]) {
      const key = filterKey(alias);
      if (claimedAliases.has(key) && claimedAliases.get(key) !== filter)
        throw new Error("Filter aliases overlap in profile: " + alias);
      claimedAliases.set(key, filter);
    }
  }
  return profile;
}

export function assertEquipment(metadata, profile, path) {
  const expected = profile.equipment;
  for (const key of [
    "cameraName",
    "cameraDriver",
    "readoutMode",
    "binX",
    "binY",
    "width",
    "height",
  ]) {
    if (metadata[key] !== expected[key])
      throw new Error(`Equipment mismatch in ${path}: ${key}`);
  }
  if (
    !Number.isFinite(metadata.electronsPerAdu) ||
    Math.abs(metadata.electronsPerAdu - expected.electronsPerAdu) > 1e-6
  )
    throw new Error(`Equipment mismatch in ${path}: electronsPerAdu`);
  const filter = matchFilter(metadata.filterName, profile);
  if (!filter)
    throw new Error(`Unsupported filter in ${path}: ${metadata.filterName}`);
  if (
    !Number.isFinite(metadata.exposureSeconds) ||
    !lightExposures(profile, filter).some(
      (exposure) => Math.abs(metadata.exposureSeconds - exposure) <= 1e-4,
    )
  )
    throw new Error(`Exposure mismatch in ${path}`);
}
