import { createHash, randomUUID } from "node:crypto";
import { mkdir, open, readFile, rename, rm, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { hostname } from "node:os";
import { verifyChecksum } from "@piproc/shared";

export async function atomicJson(path, value) {
  await mkdir(dirname(path), { recursive: true });
  const tmp = path + "." + randomUUID() + ".tmp";
  const handle = await open(tmp, "wx", 0o600);
  try {
    await handle.writeFile(JSON.stringify(value, null, 2) + "\n");
    await handle.sync();
  } finally {
    await handle.close();
  }
  await rename(tmp, path);
}

export async function loadJournal(path, fingerprint) {
  try {
    const value = JSON.parse(await readFile(path, "utf8"));
    if (value.fingerprint !== fingerprint)
      throw new Error("Run fingerprint mismatch");
    return value;
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    return {
      version: 1,
      fingerprint,
      status: "RUNNING",
      stages: {},
      attempts: [],
      createdAt: new Date().toISOString(),
    };
  }
}

// The caller holds the original run lock throughout recovery and execution.
// Keep completed runs and their reviews intact; a replacement gets its own
// fingerprint, staging, reviews and publication directory. The persisted link
// makes subsequent Generate / resume calls continue that same replacement.
export async function loadRecoverableJournal(path, fingerprint) {
  const visited = new Set();
  let recovery = null;
  for (;;) {
    if (visited.has(fingerprint)) throw new Error("Regeneration journal cycle");
    visited.add(fingerprint);
    const journal = await loadJournal(path, fingerprint);
    if (journal.regenerationFingerprint) {
      const next = journal.regenerationFingerprint;
      if (!/^[a-f0-9]{64}$/.test(next))
        throw new Error("Invalid regeneration fingerprint");
      path = resolve(dirname(path), next + ".json");
      fingerprint = next;
      continue;
    }
    if (journal.status !== "SUCCEEDED" && journal.status !== "PUBLISHED")
      return { journal, journalPath: path, fingerprint, recovery };
    try {
      await verifyChecksum(journal.publication.manifestPath,
        journal.publication.manifestChecksum);
      for (const item of journal.publication.files)
        await verifyChecksum(item.path, item.checksum);
      return { journal, journalPath: path, fingerprint, recovery };
    } catch (error) {
      // Only missing published products trigger regeneration. Corruption,
      // permissions and unavailable storage still need their actual error.
      if (error.code !== "ENOENT") throw error;
      const next = createHash("sha256").update(fingerprint + randomUUID()).digest("hex");
      const nextPath = resolve(dirname(path), next + ".json");
      recovery = { previousJournalPath: path, missingPath: error.path };
      const replacement = await loadJournal(nextPath, next);
      replacement.regeneratedFrom = { fingerprint, ...recovery };
      await atomicJson(nextPath, replacement);
      journal.regenerationFingerprint = next;
      await atomicJson(path, journal);
      path = nextPath;
      fingerprint = next;
    }
  }
}

export async function acquireRunLock(journalPath) {
  const dir = journalPath + ".lock";
  await mkdir(dirname(dir), { recursive: true });
  for (let attempt = 0; attempt < 2; ++attempt) {
    try {
      await mkdir(dir);
      try {
        await writeFile(
          resolve(dir, "owner.json"),
          JSON.stringify({
            pid: process.pid,
            host: hostname(),
            createdAt: new Date().toISOString(),
          }),
          { flag: "wx" },
        );
      } catch (error) {
        await rm(dir, { recursive: true, force: true });
        throw error;
      }
      return async () => {
        await rm(dir, { recursive: true, force: true });
      };
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      let owner;
      try {
        owner = JSON.parse(await readFile(resolve(dir, "owner.json"), "utf8"));
      } catch (ownerError) {
        throw new Error("Run lock has no readable owner: " + dir, {
          cause: ownerError,
        });
      }
      if (owner.host !== hostname())
        throw new Error("Run lock belongs to another host: " + dir, {
          cause: error,
        });
      try {
        process.kill(owner.pid, 0);
        throw new Error(
          `Another one-run process owns ${journalPath} (PID ${owner.pid})`,
          { cause: error },
        );
      } catch (probe) {
        if (probe.code !== "ESRCH") throw probe;
      }
      await rm(dir, { recursive: true });
    }
  }
  throw new Error("Unable to acquire one-run lock: " + dir);
}
