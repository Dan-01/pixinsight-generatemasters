import { readFile } from "node:fs/promises";
import { basename } from "node:path";
import { fileChecksum } from "@piproc/shared";
import { exposureGroups, groupKey } from "./profile.mjs";

export function buildMasterReview(run, journal, profile) {
  const groups = exposureGroups(profile).map(({ filter, exposureSeconds }) => {
    const key = groupKey(profile, filter, exposureSeconds);
    const entry = journal.stages["INTEGRATE_" + key];
    if (entry?.status !== "SUCCEEDED" ||
        entry.statistics?.numberOfImages !== run.integrationStacks[key]?.length)
      throw new Error("Master review lacks a complete integration for " + key);
    const outputs = Object.fromEntries(entry.outputs.map((item) =>
      [basename(item.path), item]));
    for (const name of ["master.xisf", "rejection-low.xisf",
      "rejection-high.xisf"])
      if (!outputs[name]) throw new Error("Master review lacks " + name + " for " + key);
    const drizzle = run.drizzle ? journal.stages["DRIZZLE_" + key] : null;
    const drizzleOutputs = Object.fromEntries((drizzle?.outputs ?? []).map(item => [basename(item.path), item]));
    if (run.drizzle && (drizzle?.status !== "SUCCEEDED" || !drizzleOutputs["drizzle-master.xisf"] ||
        !drizzleOutputs["drizzle-weight.xisf"] || drizzle.statistics.numberOfImages !== run.integrationStacks[key].length))
      throw new Error("Master review lacks complete drizzle outputs for " + key);
    return { key, filter, exposureSeconds, policy: profile.integration,
      sourceFrames: run.integrationStacks[key], statistics: entry.statistics,
      master: drizzleOutputs["drizzle-master.xisf"] ?? outputs["master.xisf"],
      ...(run.drizzle ? { drizzle: run.drizzle, drizzleStatistics: drizzle.statistics,
        conventionalMaster: outputs["master.xisf"], drizzleWeight: drizzleOutputs["drizzle-weight.xisf"] } : {}),
      rejectionLow: outputs["rejection-low.xisf"],
      rejectionHigh: outputs["rejection-high.xisf"] };
  });
  return { version: 1, kind: "one-run-master-review",
    fingerprint: run.fingerprint, target: run.target,
    referenceChecksum: run.referenceChecksum,
    referenceSelection: run.referenceSelection,
    registrationReview: run.registrationReview,
    failedRegistrations: run.failedRegistrations,
    groups, note: "Inspect each full-size linear master and both rejection maps. Check stars, edges, background, faint structure, residual trails, stack count, and registration flags before accepting." };
}

export async function readMasterAcceptance(path, review, reviewChecksum) {
  const decision = JSON.parse(await readFile(path, "utf8"));
  if (decision.version !== 1 || decision.kind !== "one-run-master-acceptance" ||
      decision.fingerprint !== review.fingerprint ||
      decision.reviewChecksum !== reviewChecksum ||
      typeof decision.operator !== "string" || !decision.operator.trim() ||
      decision.decision !== "ACCEPT" ||
      typeof decision.rationale !== "string" || decision.rationale.trim().length < 20)
    throw new Error("Master acceptance must match this exact candidate and include a specific rationale of at least 20 characters");
  return { decision, checksum: await fileChecksum(path) };
}

export async function savedMasterAcceptancePath(reviewPath, checksum, journal) {
  if (journal.masterAcceptancePath) return journal.masterAcceptancePath;
  let draft;
  try { draft = JSON.parse(await readFile(reviewPath + ".draft.json", "utf8")); }
  catch (error) { if (error.code === "ENOENT") return null; throw error; }
  if (draft.reviewChecksum !== checksum) throw new Error("Saved master acceptance differs from these integrated masters");
  return draft.acceptancePath ?? null;
}
