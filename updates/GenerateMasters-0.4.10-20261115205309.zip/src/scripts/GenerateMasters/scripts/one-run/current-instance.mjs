import { copyFile, mkdir, mkdtemp, readFile, rm } from "node:fs/promises";
import { constants } from "node:fs";
import { createHash } from "node:crypto";
import { tmpdir } from "node:os";
import { resolve } from "node:path";
import { setTimeout as delay } from "node:timers/promises";
import { RealPixInsightClient } from "@piproc/pixinsight-client";

// Each journal owns its command queue. Keep receipts and interrupted claims
// across launcher restarts; native image paths remain unchanged for old runs.
export async function connectCurrentInstance(config, report, journalPath) {
  const path = journalPath ? resolve(config.path, "desktop", createHash("sha256").update(journalPath).digest("hex")) :
    await mkdtemp(resolve(tmpdir(), "dap-current-instance-"));
  await mkdir(path, { recursive: true });
  const close = async () => {
    report("info", { currentInstanceBridgeStop: true });
    for (let attempt = 0; attempt < 100; ++attempt) {
      try { await readFile(resolve(path, "bridge.lock")); }
      catch (error) {
        if (error.code !== "ENOENT") throw error;
        if (!journalPath) await rm(path, { recursive: true, force: true });
        return;
      }
      await delay(50);
    }
    throw new Error("The current PixInsight instance has not released its processing session; its files are preserved for resume.");
  };
  let announced = false;
  try {
    const lockPath = resolve(path, "bridge.lock");
    let lock;
    try { lock = await readFile(lockPath, "utf8"); }
    catch (error) { if (error.code !== "ENOENT") throw error; }
    if (lock) {
      const owner = JSON.parse(lock);
      if (!Number.isSafeInteger(owner.pid) || owner.pid <= 0)
        throw new Error("The saved PixInsight session has an invalid lock");
      try { process.kill(owner.pid, 0); }
      catch (error) {
        if (error.code !== "ESRCH") throw error;
        if (await readFile(lockPath, "utf8") !== lock) throw new Error("PixInsight session lock changed", { cause: error });
        await rm(lockPath); lock = null;
      }
      if (lock) throw new Error("This run still has an active PixInsight processing session. Finish or stop it before resuming.");
    }
    // A previous session's stopped heartbeat is not this new connection.
    await rm(resolve(path, "heartbeat.json"), { force: true });
    const client = new RealPixInsightClient({ ...config, path });
    // A run started by an older external bridge may already have a native
    // receipt or an unfinished claim. Reuse the receipt; never replay a claim.
    const execute = client.execute.bind(client);
    client.execute = async (operation, parameters, identity) => {
      if (journalPath && operation === "one_run_stage" && identity) {
        for (const dir of ["results", "failed", "processing", "commands"]) {
          const legacy = resolve(config.path, dir, identity.id + ".json");
          try { await readFile(legacy); }
          catch (error) { if (error.code === "ENOENT") continue; throw error; }
          if (dir === "processing" || dir === "commands")
            throw new Error("INTERRUPTED_REVIEW_REQUIRED: an earlier external bridge owns this stage. Inspect its receipt before retrying.");
          try { await copyFile(legacy, resolve(path, dir, identity.id + ".json"), constants.COPYFILE_EXCL); }
          catch (error) { if (error.code !== "EEXIST") throw error; }
          break;
        }
      }
      return execute(operation, parameters, identity);
    };
    announced = true;
    report("info", { message: "Using the current PixInsight instance",
      currentInstanceBridge: { path, jobRoot: config.path, timeoutSeconds: config.timeoutSeconds } });
    for (let attempt = 0; attempt < 60; ++attempt) {
      const status = await client.getStatus();
      if (status.state === "idle") return { client, close };
      if (status.state === "error") throw new Error(status.heartbeat?.message || status.reason || "PixInsight could not start its processing session");
      await delay(100);
    }
    throw new Error("The current PixInsight instance did not connect. Reopen GenerateMasters and resume; no external instance was started.");
  } catch (error) { if (announced) await close(); throw error; }
}
