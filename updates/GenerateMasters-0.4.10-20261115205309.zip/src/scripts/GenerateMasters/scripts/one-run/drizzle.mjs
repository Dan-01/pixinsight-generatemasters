import { readFile } from "node:fs/promises";
import { exposureGroups, groupKey } from "./profile.mjs";

export function drizzleSettings(value = "off") {
  if (value === "off") return null;
  if (value !== "2x") throw new Error("Drizzle must be off or 2x");
  return { scale: 2, dropShrink: 0.9, kernel: "SQUARE", rejection: true };
}

function median(values) {
  const sorted = values.filter(Number.isFinite).sort((a, b) => a - b);
  if (!sorted.length) return null;
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

// Screening rules, not a guarantee of recovered resolution. Pixel scale alone
// cannot establish undersampling or prove that the capture was dithered.
export function drizzleRecommendation(profile, lights, measurements = [], phases = []) {
  return exposureGroups(profile).map(({ filter, exposureSeconds }) => {
    const group = lights.filter(item => item.filter === filter && item.exposureSeconds === exposureSeconds);
    const checksums = new Set(group.map(item => item.checksum));
    const fwhm = measurements.filter(item => checksums.has(item.sourceChecksum)).map(item => item.metrics.fwhm);
    const medianFwhmPixels = fwhm.length === group.length ? median(fwhm) : null;
    const offsets = phases.filter(item => checksums.has(item.sourceChecksum));
    const quadrants = new Set(offsets.map(item => Math.floor(item.phase[0] * 2) + 2 * Math.floor(item.phase[1] * 2)));
    const phaseCells = new Set(offsets.map(item => Math.floor(item.phase[0] * 4) + 4 * Math.floor(item.phase[1] * 4)));
    let status = "CHECK_SAMPLING", reason = "Star sampling has not been measured yet. Pixel scale alone cannot establish a drizzle benefit.";
    if (group.length < 20) {
      status = "LOW_FRAME_COUNT"; reason = "Fewer than 20 frames in this exposure group; a 2x comparison may have uneven coverage or extra noise.";
    } else if (medianFwhmPixels !== null) {
      if (medianFwhmPixels >= 2.5) {
        status = "NOT_RECOMMENDED"; reason = "Measured stars are already reasonably sampled; a 2x resolution benefit is less likely.";
      } else if (offsets.length === group.length && quadrants.size >= 3 && phaseCells.size >= 6) {
        status = "RECOMMENDED_COMPARISON"; reason = "Small measured star profiles and varied subpixel offsets make a 2x comparison worth inspecting.";
      } else if (offsets.length === group.length) {
        status = "NOT_RECOMMENDED"; reason = "Registered offsets show limited subpixel diversity; 2x drizzle may add size without useful detail.";
      } else {
        status = "CONSIDER_IF_DITHERED"; reason = "Measured stars suggest undersampling. Consider 2x only if the capture has varied subpixel offsets; dithering is not verified.";
      }
    }
    return { key: groupKey(profile, filter, exposureSeconds), filter, exposureSeconds,
      frames: group.length, medianFwhmPixels,
      phaseQuadrants: offsets.length === group.length ? quadrants.size : null,
      phaseCells4x4: offsets.length === group.length ? phaseCells.size : null,
      status, reason, heuristic: { minimumFrames: 20, undersampledFwhmPixels: 2.5,
        minimumPhaseQuadrants: 3, minimumPhaseCells4x4: 6 } };
  });
}

export function readDrizzleXml(xml, { source, target, geometry, rejection = false }) {
  if (!/<xdrz\b[^>]*version="1\.[01]"/.test(xml)) throw new Error("Expected XDRZ 1.0 or 1.1 alignment data");
  const tag = name => {
    const matches = [...xml.matchAll(new RegExp("<" + name + ">([^<]*)</" + name + ">", "g"))];
    if (matches.length !== 1) throw new Error("Expected one XDRZ " + name);
    return matches[0][1].replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'");
  };
  const sourcePath = tag("SourceImage"), targetPath = tag("AlignmentTargetImage");
  if (sourcePath !== source || targetPath !== target) throw new Error("Drizzle source/registration path differs from the verified stack");
  const matrix = tag("AlignmentMatrix").split(",").map(Number);
  if (matrix.length !== 9 || matrix.some(value => !Number.isFinite(value))) throw new Error("Invalid drizzle alignment matrix");
  const x = geometry.width / 2, y = geometry.height / 2;
  const denominator = matrix[6] * x + matrix[7] * y + matrix[8];
  if (!denominator) throw new Error("Singular drizzle alignment matrix");
  const phase = [(matrix[0] * x + matrix[1] * y + matrix[2]) / denominator - x,
    (matrix[3] * x + matrix[4] * y + matrix[5]) / denominator - y].map(value => ((value % 1) + 1) % 1);
  if (phase.some(value => !Number.isFinite(value))) throw new Error("Invalid drizzle subpixel phase");
  if (rejection) {
    const map = xml.match(/<RejectionMap\b([^>]*)>([\s\S]*?)<\/RejectionMap>/);
    if (!map || !new RegExp('\\bwidth="' + geometry.width + '"').test(map[1]) ||
        !new RegExp('\\bheight="' + geometry.height + '"').test(map[1]) ||
        !/\bnumberOfChannels="1"/.test(map[1]) || !/<ChannelData\b[^>]*>\s*<Subblock\b/.test(map[2]))
      throw new Error("Drizzle data lacks the full per-frame pixel rejection map");
    for (const name of ["LocationEstimates", "ReferenceLocation", "ScaleFactors", "Weights"]) {
      const value = Number(tag(name));
      if (!Number.isFinite(value) || (["ScaleFactors", "Weights"].includes(name) && !(value > 0)))
        throw new Error("Drizzle data lacks valid " + name);
    }
  }
  return { sourcePath, targetPath, phase };
}
export async function verifyDrizzleData(path, expected) {
  return readDrizzleXml(await readFile(path, "utf8"), expected);
}
