import { RUNNER_EVENT_PREFIX, RUNNER_EVENT_VERSION } from "@piproc/shared";
// One record per line. Human logs may coexist; only this exact prefix is machine data.
export const eventPrefix = RUNNER_EVENT_PREFIX;
export function encodeEvent(type, data = {}) {
  if (!["info", "stage", "preflight", "quality-review", "master-review", "result", "error"].includes(type))
    throw new Error("Unknown runner event type: " + type);
  return (
    eventPrefix + JSON.stringify({ version: RUNNER_EVENT_VERSION, type, data })
  );
}
export function eventReporter(enabled, write = (line) => console.log(line)) {
  return (type, data) => {
    if (enabled) write(encodeEvent(type, data));
  };
}
