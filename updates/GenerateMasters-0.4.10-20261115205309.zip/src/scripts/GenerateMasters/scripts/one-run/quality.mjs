import { readFile } from "node:fs/promises";
import { fileChecksum } from "@piproc/shared";

const metrics = ["fwhm", "eccentricity", "snrWeightMetric", "noise", "stars"];

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2
    ? sorted[middle]
    : (sorted[middle - 1] + sorted[middle]) / 2;
}

export function buildQualityReview(fingerprint, frames, knownApprovedChecksums = []) {
  for (const frame of frames)
    if (frame.metrics.psfSignalWeight === null &&
        !frame.metrics.unavailableMetrics?.includes("psfSignalWeight"))
      throw new Error(`Missing PSF signal weight has no native diagnostic for ${frame.sourcePath}`);
  for (const frame of frames)
    for (const key of metrics)
      if (typeof frame.metrics[key] !== "number" || !Number.isFinite(frame.metrics[key]))
        throw new Error(`Invalid ${key} measurement for ${frame.sourcePath}`);
  if (new Set(frames.map((frame) => frame.sourceChecksum)).size !== frames.length)
    throw new Error("Quality review has duplicate source checksums");
  const known = new Set(knownApprovedChecksums);
  const groupKey = (frame) => `${frame.filter}:${frame.exposureSeconds}`;
  const baselines = Object.fromEntries([...new Set(frames.map(groupKey))]
    .map((key) => {
      const group = frames.filter((frame) => groupKey(frame) === key);
      return [key, Object.fromEntries(metrics.map((key) => [key,
        median(group.map((frame) => frame.metrics[key]))]))];
    }));
  const rows = frames.map((frame) => {
    const base = baselines[groupKey(frame)];
    const flags = [];
    if (frame.metrics.psfSignalWeight === null &&
        frame.metrics.unavailableMetrics?.includes("psfSignalWeight"))
      flags.push("PSF_SIGNAL_WEIGHT_UNAVAILABLE");
    if (base.fwhm > 0 && frame.metrics.fwhm > base.fwhm * 1.5)
      flags.push("FWHM_HIGH_RELATIVE_TO_STACK");
    if (frame.metrics.eccentricity > 0.7)
      flags.push("ECCENTRICITY_HIGH");
    if (base.snrWeightMetric > 0 && frame.metrics.snrWeightMetric < base.snrWeightMetric * 0.5)
      flags.push("SNR_LOW_RELATIVE_TO_STACK");
    if (base.noise > 0 && frame.metrics.noise > base.noise * 1.5)
      flags.push("NOISE_HIGH_RELATIVE_TO_STACK");
    if (base.stars > 0 && frame.metrics.stars < base.stars * 0.5)
      flags.push("STAR_COUNT_LOW_RELATIVE_TO_STACK");
    return {
      sourcePath: frame.sourcePath,
      sourceChecksum: frame.sourceChecksum,
      filter: frame.filter,
      exposureSeconds: frame.exposureSeconds,
      metrics: frame.metrics,
      flags,
      priorApproval: known.has(frame.sourceChecksum),
      needsDecision: !known.has(frame.sourceChecksum) || flags.length > 0,
    };
  });
  return { version: 1, kind: "one-run-quality-review", fingerprint,
    baselines, frames: rows,
    pendingChecksums: rows.filter((row) => row.needsDecision)
      .map((row) => row.sourceChecksum) };
}

export async function readQualityDecisions(path, review, reviewChecksum) {
  const decision = JSON.parse(await readFile(path, "utf8"));
  if (decision.version !== 1 || decision.kind !== "one-run-quality-decisions" ||
      decision.fingerprint !== review.fingerprint ||
      decision.reviewChecksum !== reviewChecksum ||
      typeof decision.operator !== "string" || !decision.operator.trim() ||
      !Array.isArray(decision.decisions))
    throw new Error("Quality decisions do not match this measured review");
  const pending = new Set(review.pendingChecksums);
  const seen = new Set();
  for (const item of decision.decisions) {
    if (!pending.has(item.sourceChecksum) || seen.has(item.sourceChecksum) ||
        !["ACCEPT", "SUSPECT", "REJECT"].includes(item.classification) ||
        typeof item.rationale !== "string" || item.rationale.trim().length < 12)
      throw new Error("Quality decisions need one supported class and rationale for each pending source checksum");
    seen.add(item.sourceChecksum);
  }
  if (seen.size !== pending.size)
    throw new Error(`Quality decisions cover ${seen.size} of ${pending.size} frames needing review`);
  return { decision, checksum: await fileChecksum(path) };
}

export function acceptedQualityChecksums(review, decisions) {
  const classified = new Map((decisions?.decisions ?? []).map((item) =>
    [item.sourceChecksum, item.classification]));
  return new Set(review.frames.filter((frame) =>
    (classified.get(frame.sourceChecksum) ??
      (frame.priorApproval && !frame.needsDecision ? "ACCEPT" : null)) === "ACCEPT")
    .map((frame) => frame.sourceChecksum));
}

// Recover the exact approval after a launcher restart or a native stage failure.
export async function savedQualityDecisionPath(reviewPath, checksum, journal, operator) {
  if (journal.qualityDecisionPath) return journal.qualityDecisionPath;
  let draft;
  try { draft = JSON.parse(await readFile(reviewPath + ".draft.json", "utf8")); }
  catch (error) { if (error.code === "ENOENT") return null; throw error; }
  if (draft.reviewChecksum !== checksum) throw new Error("Saved quality review differs from this measured run");
  if (draft.finalDecisionPath) return draft.finalDecisionPath;
  if (!operator || !(draft.blinkResume || draft.blinkFilter)) return null;
  // Generate / resume is the operator's request to apply the saved Blink
  // selection. Do this before emitting another frame-review event.
  const { resumeBlinkReview, completeBlinkReview } = await import("./blink-review.mjs");
  const preview = await resumeBlinkReview(reviewPath, checksum);
  if (preview.state !== "AWAITING_BLINK") return null;
  const review = JSON.parse(await readFile(reviewPath, "utf8"));
  const covered = new Set([...preview.decisions, ...(draft.decisions ?? [])]
    .map(item => item.sourceChecksum));
  if (review.frames.some(frame => frame.needsDecision && !covered.has(frame.sourceChecksum) &&
      !(preview.filter === "FLAGGED" && !frame.flags.length))) return null;
  const completed = await completeBlinkReview(reviewPath, checksum, operator, draft.blinkNote, true);
  return completed.decisionPath;
}
