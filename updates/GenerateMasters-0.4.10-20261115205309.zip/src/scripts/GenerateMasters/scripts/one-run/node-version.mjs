export function assertSupportedNodeVersion(version = process.versions.node) {
  const match = /^26\.(\d+)\.(\d+)$/.exec(String(version));
  if (!match || Number(match[1]) < 13 ||
      (Number(match[1]) === 13 && Number(match[2]) < 1))
    throw new Error("GenerateMasters requires Node.js 26.13.1 or a newer Node 26 patch");
}
