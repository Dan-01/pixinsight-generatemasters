import { resolve } from "node:path";
import { createInterface } from "node:readline/promises";

export async function askPath(label, current) {
  if (!process.stdin.isTTY) {
    if (current) return resolve(current);
    throw new Error(label + " is required in noninteractive mode");
  }
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = await rl.question(`${label} [${current ?? ""}]: `);
    return resolve(answer.trim() || current || "");
  } finally {
    rl.close();
  }
}

export async function askSetting(label, current) {
  if (!process.stdin.isTTY) return current;
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = await rl.question(`${label} [${current}]: `);
    return answer.trim() || current;
  } finally {
    rl.close();
  }
}

export async function approveUnknown(count, explicit) {
  if (!count || explicit) return;
  if (!process.stdin.isTTY)
    throw new Error(
      `${count} new lights have no saved quality decision; use --measure-unreviewed to calibrate them for individual review`,
    );
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = await rl.question(
      `${count} new lights have no saved quality decision. Calibrate and measure them before individual review? [y/N]: `,
    );
    if (!/^y(es)?$/i.test(answer.trim()))
      throw new Error("Run stopped before measuring new unreviewed lights");
  } finally {
    rl.close();
  }
}

export async function approveNewCalibration(count, explicit) {
  if (!count || explicit) return;
  if (!process.stdin.isTTY)
    throw new Error(
      `${count} raw calibration frames are new to this profile; use --confirm-optical-train only if the flat optical train is unchanged`,
    );
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = await rl.question(
      `${count} calibration frames are new. Confirm the flats share the lights' optical train? [y/N]: `,
    );
    if (!/^y(es)?$/i.test(answer.trim()))
      throw new Error("Run stopped before preparing calibration masters");
  } finally {
    rl.close();
  }
}

export async function approveLegacyCalibration(warnings, explicit) {
  if (!warnings.length || explicit) return;
  if (!process.stdin.isTTY)
    throw new Error("Saved masters lack recorded acquisition identity; review the preflight warnings and use --confirm-calibration-identity only after checking their preparation lineage");
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  try {
    for (const warning of warnings) console.warn(warning);
    const answer = await rl.question(
      "Confirm these saved masters were prepared with compatible gain, offset, and temperature? [y/N]: ",
    );
    if (!/^y(es)?$/i.test(answer.trim()))
      throw new Error("Run stopped before using saved masters with unverified acquisition identity");
  } finally {
    rl.close();
  }
}
