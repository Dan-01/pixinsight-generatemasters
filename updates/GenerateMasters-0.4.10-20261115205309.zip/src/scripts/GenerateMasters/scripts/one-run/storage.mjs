import { stat, statfs } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { exposureGroups } from "./profile.mjs";

async function existingAncestor(path) {
  let current = resolve(path);
  for (;;) {
    try { await stat(current); return current; }
    catch (error) {
      if (error.code !== "ENOENT") throw error;
      const parent = dirname(current);
      if (parent === current) throw error;
      current = parent;
    }
  }
}

async function capacity(path) {
  const ancestor = await existingAncestor(path);
  const [filesystem, info] = await Promise.all([
    statfs(ancestor, { bigint: true }), stat(ancestor),
  ]);
  return { location: resolve(path), measuredAt: ancestor,
    device: String(info.dev),
    availableBytes: Number(filesystem.bavail * filesystem.bsize) };
}

export function storageMessages(storage) {
  const gib = (bytes) => (bytes / 1073741824).toFixed(1) + " GiB";
  if (storage.status === "SUFFICIENT") return [];
  const insufficient = storage.status === "INSUFFICIENT";
  if (storage.sameDevice) {
    const required = insufficient ? storage.combinedMinimumBytes :
      storage.combinedEstimatedPeakBytes;
    return ["Worker staging (" + storage.staging.location + ") and final masters (" +
      storage.output.location + ") share a disk: " + gib(Math.min(
        storage.staging.availableBytes, storage.output.availableBytes)) +
      " free; " + gib(required) + (insufficient ? " minimum required." : " estimated peak.") +
      " Choose a worker folder on a disk with more space by setting bridge.path in the runtime settings file."];
  }
  const messages = [];
  for (const [label, area, estimate, remedy] of [
    ["Worker staging", storage.staging, storage.staging.estimatedPeakBytes,
      "Set bridge.path in the runtime settings file to a worker folder on a disk with more space. Changing the final masters folder alone does not move worker images."],
    ["Final masters", storage.output, storage.output.estimatedBytes,
      "Choose a final masters folder on a disk with more space."],
  ]) {
    const required = insufficient ? area.minimumBytes : estimate;
    if (area.availableBytes < required)
      messages.push(label + " at " + area.location + ": " + gib(area.availableBytes) +
        " free; " + gib(required) + (insufficient ? " minimum required. " : " estimated peak. ") + remedy);
  }
  return messages;
}

export async function storagePreflight(source, output, bridge, selected, raw,
  profile, drizzle = null) {
  const pixelBytes = selected[0].width * selected[0].height * 4;
  const lightBytes = selected.length * pixelBytes;
  const groups = exposureGroups(profile);
  const largestInputBatch = Math.max(...groups.map(({ filter, exposureSeconds }) =>
    selected.filter((item) => item.filter === filter &&
      item.exposureSeconds === exposureSeconds)
      .reduce((sum, item) => sum + item.size, 0)));
  const rawSourceBytes = raw?.selected.reduce((sum, item) => sum + item.size, 0) ?? 0;
  const calibrationMasterCount = raw
    ? Object.keys(raw.groups.masterDarks).length + Object.keys(raw.savedDarks ?? {}).length + 2 * profile.filters.length : 0;
  const calibrationProducts = calibrationMasterCount * 3 * pixelBytes;
  const drizzleProducts = drizzle ? groups.length * 2 * drizzle.scale ** 2 * pixelBytes : 0;
  const drizzleDataEstimate = drizzle ? lightBytes : 0;
  const lightProducts = groups.length * 3 * pixelBytes + drizzleProducts;
  const normalizationDataEstimate = profile.integration.normalization ===
    "LOCAL_NORMALIZATION" ? Math.ceil(lightBytes * 0.1) : 0;
  const stagingMinimumBytes = 2 * lightBytes + largestInputBatch + drizzleProducts + drizzleDataEstimate;
  const stagingEstimatedPeakBytes = 3 * lightBytes + largestInputBatch +
    rawSourceBytes + calibrationProducts + normalizationDataEstimate + drizzleProducts + drizzleDataEstimate;
  const outputEstimatedBytes = lightProducts + calibrationProducts +
    normalizationDataEstimate;
  const [staging, destination] = await Promise.all([
    capacity(bridge), capacity(output),
  ]);
  const sameDevice = staging.device === destination.device;
  const combinedMinimum = stagingMinimumBytes + lightProducts;
  const combinedEstimate = stagingEstimatedPeakBytes + outputEstimatedBytes;
  const available = sameDevice ? Math.min(staging.availableBytes,
    destination.availableBytes) : null;
  const blocked = sameDevice
    ? available < combinedMinimum
    : staging.availableBytes < stagingMinimumBytes ||
      destination.availableBytes < lightProducts;
  const caution = sameDevice
    ? available < combinedEstimate
    : staging.availableBytes < stagingEstimatedPeakBytes ||
      destination.availableBytes < outputEstimatedBytes;
  return { staging: { ...staging, minimumBytes: stagingMinimumBytes,
    estimatedPeakBytes: stagingEstimatedPeakBytes },
    output: { ...destination, minimumBytes: lightProducts,
      estimatedBytes: outputEstimatedBytes }, sameDevice,
    combinedMinimumBytes: sameDevice ? combinedMinimum : null,
    combinedEstimatedPeakBytes: sameDevice ? combinedEstimate : null,
    status: blocked ? "INSUFFICIENT" : caution ? "LOW_MARGIN" : "SUFFICIENT",
    assumptions: "Float32 calibrated and registered stacks, source snapshots, integration scratch, rejection maps, raw calibration products, and an optional 10% XNML allowance." +
      (drizzle ? " Includes 2x drizzle masters, coverage maps and a per-frame rejection-data allowance." : "") +
      " PixInsight may use additional temporary space." };
}
