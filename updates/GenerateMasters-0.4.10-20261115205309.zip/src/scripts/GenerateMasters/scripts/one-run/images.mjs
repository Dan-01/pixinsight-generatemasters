import { setTimeout as delay } from "node:timers/promises";
import { Buffer } from "node:buffer";
import { open, stat } from "node:fs/promises";
import { extname } from "node:path";
import { readFitsMetadata } from "@piproc/fits";

export async function readXisfHeader(path) {
  const handle = await open(path, "r");
  try {
    const prefix = Buffer.alloc(16);
    if ((await handle.read(prefix, 0, 16, 0)).bytesRead !== 16)
      throw new Error("Truncated XISF prefix: " + path);
    if (prefix.toString("ascii", 0, 8) !== "XISF0100")
      throw new Error("Invalid XISF signature: " + path);
    const length = prefix.readUInt32LE(8);
    if (length < 100 || length > 2 * 1024 * 1024)
      throw new Error("Unsupported XISF header size: " + path);
    const header = Buffer.alloc(length);
    let read = 0;
    while (read < length) {
      const part = await handle.read(header, read, length - read, 16 + read);
      if (!part.bytesRead) throw new Error("Truncated XISF header: " + path);
      read += part.bytesRead;
    }
    return header.toString("utf8");
  } finally {
    await handle.close();
  }
}

export async function readXisfGeometry(path) {
  const images = (await readXisfHeader(path)).match(/<Image\b[^>]*>/g) ?? [];
  if (images.length !== 1) throw new Error("XISF must contain exactly one image: " + path);
  const image = images;
  const geometry = image?.[0].match(/geometry="(\d+):(\d+):(\d+)"/);
  const sample = image?.[0].match(/sampleFormat="([^"]+)"/);
  const location = image?.[0].match(/location="attachment:(\d+):(\d+)"/);
  if (!geometry || !sample || !location)
    throw new Error("XISF image header missing: " + path);
  return {
    width: Number(geometry[1]),
    height: Number(geometry[2]),
    channels: Number(geometry[3]),
    sampleFormat: sample[1],
    attachmentEnd: Number(location[1]) + Number(location[2]),
  };
}

// User-supplied calibration images can use any normal PixInsight sample format,
// including compressed XISF. Generated outputs retain the stricter Float32 gate.
export async function verifyCalibrationImage(path, geometry) {
  if (/\.(fits?|fts)$/i.test(path)) {
    const metadata = await readFitsMetadata(path);
    if (metadata.width !== geometry.width || metadata.height !== geometry.height || metadata.rawHeaders.NAXIS !== 2)
      throw new Error("Master dark must be monochrome and match the light dimensions: " + path);
  } else if (extname(path).toLowerCase() === ".xisf") {
    const metadata = await readXisfGeometry(path);
    if (metadata.width !== geometry.width || metadata.height !== geometry.height || metadata.channels !== 1 ||
        !["Float32", "Float64", "UInt8", "UInt16", "UInt32", "UInt64"].includes(metadata.sampleFormat))
      throw new Error("Master dark must be monochrome and match the light dimensions: " + path);
    if ((await stat(path)).size < metadata.attachmentEnd)
      throw new Error("XISF image attachment is incomplete: " + path);
  } else throw new Error("Select a XISF or FITS master dark: " + path);
}

export async function readXisfExposure(path) {
  const keywords =
    (await readXisfHeader(path)).match(/<FITSKeyword\b[^>]*\/?\s*>/g) ?? [];
  for (const keyword of keywords) {
    const name = keyword.match(/\bname="([^"]+)"/)?.[1];
    if (name !== "EXPOSURE" && name !== "EXPTIME") continue;
    const value = keyword.match(/\bvalue="([^"]+)"/)?.[1];
    const exposure = Number(value?.replace(/^'+|'+$/g, ""));
    if (Number.isFinite(exposure) && exposure > 0) return exposure;
  }
  throw new Error("XISF master has no positive exposure keyword: " + path);
}

export async function verifyImage(path, geometry) {
  if (extname(path).toLowerCase() === ".fits") {
    const metadata = await readFitsMetadata(path);
    if (
      metadata.width !== geometry.width ||
      metadata.height !== geometry.height ||
      Number(metadata.rawHeaders.NAXIS) !== 2 ||
      Number(metadata.rawHeaders.BITPIX) !== -32
    )
      throw new Error("FITS output geometry or format mismatch: " + path);
  } else if (extname(path).toLowerCase() === ".xisf") {
    const metadata = await readXisfGeometry(path);
    if (
      metadata.width !== geometry.width ||
      metadata.height !== geometry.height ||
      metadata.channels !== 1 ||
      metadata.sampleFormat !== "Float32"
    )
      throw new Error("XISF output geometry or format mismatch: " + path);
    if ((await stat(path)).size < metadata.attachmentEnd)
      throw new Error("XISF image attachment is incomplete: " + path);
  } else throw new Error("Unsupported native image output: " + path);
}

export async function waitForStageImages(paths, geometry) {
  // A native batch can report paths while an output writer is still finishing.
  const deadline = Date.now() + 30_000;
  let previous = null;
  while (true) {
    try {
      const current = await Promise.all(
        paths.map(async (path) => {
          await verifyImage(path, geometry);
          const info = await stat(path);
          return `${info.size}:${info.mtimeMs}`;
        }),
      );
      if (
        previous &&
        current.every((value, index) => value === previous[index])
      )
        return;
      previous = current;
    } catch (error) {
      if (
        !/XISF image header missing|XISF image attachment is incomplete|Truncated XISF|ENOENT/.test(
          String(error),
        )
      )
        throw error;
      if (Date.now() >= deadline) throw error;
      previous = null;
    }
    if (Date.now() >= deadline)
      throw new Error(
        "Native image outputs did not stabilize before verification",
      );
    await delay(500);
  }
}
