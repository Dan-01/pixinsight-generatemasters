import { execFile } from "node:child_process";
import { existsSync } from "node:fs";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { resolve } from "node:path";
import { promisify } from "node:util";
import { projectRoot, stageAdapter } from "./constants.mjs";

export function nativeCapabilityBlockers(capability, requirements) {
  const blockers = [];
  if (!capability?.supported || capability.adapter !== stageAdapter ||
      (requirements.prepareMasters && !capability.masterPreparationSupported))
    blockers.push("PixInsight lacks required GenerateMasters capabilities: " +
      (capability?.reasons ?? ["probe unavailable"]).join("; "));
  if (requirements.reuseDark && !capability?.savedMasterDarkReuseSupported)
    blockers.push("Update the PixInsight bridge: saved master-dark reuse support is required");
  if (requirements.darkFlatApproval && !capability?.darkFlatExposureApprovalSupported)
    blockers.push("Update the PixInsight bridge: dark-flat exposure approval support is required");
  if (requirements.measurement && !capability?.subframeMeasurementSupported)
    blockers.push("Subframe measurement is unavailable in this PixInsight build: " +
      (capability?.subframeMeasurementReasons ?? ["probe unavailable"]).join("; "));
  if (requirements.localNormalization && !capability?.localNormalizationSupported)
    blockers.push("LocalNormalization is unavailable in this PixInsight build: " +
      (capability?.localNormalizationReasons ?? ["probe unavailable"]).join("; "));
  if (requirements.drizzle && !capability?.drizzleSupported)
    blockers.push("Drizzle is unavailable in this PixInsight instance: " +
      (capability?.drizzleReasons ?? ["restart the updated bridge"]).join("; "));
  return blockers;
}

// Explicit UI preflight: inspect native process contracts without processing images
// or touching the output folder. Plain CLI --dry-run remains inventory-only.
export async function probeNativePreflight(executable) {
  const directory = await mkdtemp(resolve(tmpdir(), "dap-native-preflight-"));
  const output = resolve(directory, "capabilities.json");
  const script = resolve(directory, "probe.js");
  const operations = existsSync(resolve(projectRoot, "runtime/operations"))
    ? resolve(projectRoot, "runtime/operations") : resolve(projectRoot, "pixinsight/operations");
  const includes = ["master-preparation-v1", "subframe-measurement-v1", "local-normalization-v1", "one-run-stage-v1"]
    .map(name => '#include "' + resolve(operations, name + ".js") + '"').join("\n");
  try {
    await writeFile(script, '#engine v8\n' + includes + '\n' +
      'var environment={pixInsightVersion:masterPreparationVersion()};\n' +
      'File.writeTextFile(' + JSON.stringify(output) + ',JSON.stringify(probeOneRun()));\n');
    const result = await promisify(execFile)(executable,
      ["-n", "--automation-mode", "--no-focus-stealing", "--no-startup-scripts", "-r=" + script, "--force-exit"],
      { timeout: 60_000, maxBuffer: 1024 * 1024 });
    if (!existsSync(output)) throw new Error("Native capability probe did not return a result: " + result.stderr.slice(-1000));
    return JSON.parse(await readFile(output, "utf8"));
  } finally { await rm(directory, { recursive: true, force: true }); }
}
