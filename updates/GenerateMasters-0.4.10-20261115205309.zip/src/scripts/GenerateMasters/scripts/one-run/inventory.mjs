import { readdir, stat } from "node:fs/promises";
import { extname, resolve } from "node:path";
import { readFitsMetadata } from "@piproc/fits";
import { fileChecksum, normalizeTarget, verifyChecksum } from "@piproc/shared";
import {
  filtersFor,
  matchFilter,
  lightExposures,
  exposureGroups,
  darkFor,
  assertEquipment,
  validateDarkFlatExposureApprovals,
} from "./profile.mjs";
import { verifyImage, verifyCalibrationImage, readXisfExposure } from "./images.mjs";
import { readDarkMetadata } from "./standalone-darks.mjs";
import {
  assertSameSettings,
  assertTemperatures,
  lightAcquisition,
  temperatureTolerance,
  assertMasterAcquisition,
} from "./identity.mjs";

function compatibleEquipment(metadata, profile) {
  return ["cameraName", "cameraDriver", "readoutMode", "binX", "binY", "width", "height"]
    .every(key => metadata[key] === profile.equipment[key]) &&
    Number.isFinite(metadata.electronsPerAdu) &&
    Math.abs(metadata.electronsPerAdu - profile.equipment.electronsPerAdu) <= 1e-6 &&
    ["gain", "offset"].every(key => (metadata[key] ?? null) === (profile.equipment[key] ?? null));
}

export async function* fitsFiles(root) {
  const entries = await readdir(root, { withFileTypes: true });
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    const path = resolve(root, entry.name);
    if (entry.isDirectory()) yield* fitsFiles(path);
    else if (entry.isFile() && /\.(fit|fits|fts)$/i.test(entry.name))
      yield path;
  }
}

export async function scanSource(source) {
  const entries = [];
  for await (const path of fitsFiles(source))
    entries.push({ path, metadata: await readFitsMetadata(path) });
  return entries;
}

async function sourceDetails(entry) {
  if (!entry.checksum) entry.checksum = await fileChecksum(entry.path);
  if (entry.size === undefined) {
    const info = await stat(entry.path);
    entry.size = info.size;
    entry.mtimeMs = info.mtimeMs;
  }
  return entry;
}

export async function inventory(source, target, profile, index = null) {
  const excluded = new Set(profile.excludeChecksums);
  const candidates = [];
  for (const entry of index ?? await scanSource(source)) {
    const { path, metadata } = entry;
    if (
      metadata.frameType !== "LIGHT" ||
      normalizeTarget(metadata.targetName ?? "") !== normalizeTarget(target)
    )
      continue;
    const filter = matchFilter(metadata.filterName, profile);
    if (!filter) continue;
    assertEquipment(metadata, profile, path);
    await sourceDetails(entry);
    const exposureSeconds = lightExposures(profile, filter).find(
      (exposure) => Math.abs(metadata.exposureSeconds - exposure) <= 1e-4,
    );
    candidates.push({
      path,
      checksum: entry.checksum,
      filter,
      exposureSeconds,
      width: metadata.width,
      height: metadata.height,
      capturedAtUtc: metadata.capturedAtUtc,
      size: entry.size,
      mtimeMs: entry.mtimeMs,
      gain: metadata.gain,
      offset: metadata.offset,
      sensorTemperature: metadata.sensorTemperature,
      excluded: excluded.has(entry.checksum),
    });
  }
  if (!candidates.length)
    throw new Error("No matching light FITS frames found");
  const selected = candidates.filter((item) => !item.excluded);
  lightAcquisition(selected, profile);
  for (const { filter, exposureSeconds } of exposureGroups(profile))
    if (
      selected.filter(
        (item) =>
          item.filter === filter && item.exposureSeconds === exposureSeconds,
      ).length < 3
    )
      throw new Error(
        `Fewer than three approved ${filter} ${exposureSeconds}s lights`,
      );
  return { candidates, selected };
}

export async function inventoryRawCalibration(source, profile, lights = [], index = null, savedDarks = {}, { automatic = false, sourcePaths = new Set() } = {}) {
  validateDarkFlatExposureApprovals(profile);
  const filters = filtersFor(profile);
  const entries = index ?? await scanSource(source);
  const localFlatFilters = new Set(entries.filter(item => sourcePaths.has(item.path) &&
    item.metadata.frameType === "FLAT" && compatibleEquipment(item.metadata, profile))
    .map(item => matchFilter(item.metadata.filterName, profile)));
  const relevantExposures = [...exposureGroups(profile).map(group => group.exposureSeconds),
    ...entries.filter(item => item.metadata.frameType === "FLAT" &&
      filters.includes(matchFilter(item.metadata.filterName, profile)) &&
      (!localFlatFilters.has(matchFilter(item.metadata.filterName, profile)) || sourcePaths.has(item.path)))
      .map(item => item.metadata.exposureSeconds)];
  const all = [];
  for (const entry of entries) {
    const { path, metadata } = entry;
    if (!["DARK", "DARKFLAT", "FLAT"].includes(metadata.frameType)) continue;
    if (automatic && (metadata.rawHeaders?.DAPMASTR || /^MASTER/i.test(metadata.rawHeaders?.IMAGETYP ?? "") ||
        /master[ _-]*dark|dark[ _-]*master/i.test(path.split("/").at(-1)))) continue;
    if (automatic && (metadata.frameType === "FLAT"
      ? !matchFilter(metadata.filterName, profile) ||
        (localFlatFilters.has(matchFilter(metadata.filterName, profile)) && !sourcePaths.has(path))
      : !relevantExposures.some(exposure => Math.abs(metadata.exposureSeconds - exposure) <= 1e-4))) continue;
    if (automatic && !compatibleEquipment(metadata, profile)) continue;
    for (const key of [
      "cameraName",
      "cameraDriver",
      "readoutMode",
      "binX",
      "binY",
      "width",
      "height",
    ])
      if (metadata[key] !== profile.equipment[key])
        throw new Error(`Calibration equipment mismatch in ${path}: ${key}`);
    if (
      !Number.isFinite(metadata.electronsPerAdu) ||
      Math.abs(metadata.electronsPerAdu - profile.equipment.electronsPerAdu) >
        1e-6
    )
      throw new Error(`Calibration gain mismatch in ${path}`);
    if (!(metadata.exposureSeconds > 0))
      throw new Error(`Missing calibration exposure in ${path}`);
    await sourceDetails(entry);
    // An additional folder can contain copies of calibration frames already in
    // the target folder. Count each physical exposure once by file content.
    if (all.some((item) => item.checksum === entry.checksum)) continue;
    all.push({
      path,
      metadata,
      checksum: entry.checksum,
      size: entry.size,
      mtimeMs: entry.mtimeMs,
    });
  }
  const matchesExposure = (item, exposure) =>
    Math.abs(item.metadata.exposureSeconds - exposure) <= 1e-4;
  const matchesTemperature = (item, references) => !automatic || references.every(reference =>
    Number.isFinite(reference.sensorTemperature) && Number.isFinite(item.metadata.sensorTemperature) &&
    Math.abs(reference.sensorTemperature - item.metadata.sensorTemperature) <= temperatureTolerance(profile) + 1e-9);
  const groups = { masterDarks: {}, filters: {} };
  const selected = [];
  for (const { exposureSeconds: exposure } of exposureGroups(profile)) {
    const key = String(exposure);
    if (savedDarks[key]) continue;
    if (groups.masterDarks[key]) continue;
    const darks = all.filter(
      (item) =>
        item.metadata.frameType === "DARK" && matchesExposure(item, exposure) &&
        matchesTemperature(item, lights.filter(light => light.exposureSeconds === exposure)),
    );
    if (darks.length < 3) {
      const darkExposures = new Map();
      for (const item of all.filter((item) => ["DARK", "DARKFLAT"].includes(item.metadata.frameType))) {
        const duration = item.metadata.exposureSeconds;
        darkExposures.set(duration, (darkExposures.get(duration) ?? 0) + 1);
      }
      const detected = [...darkExposures].sort(([a], [b]) => a - b)
        .map(([duration, count]) => `${duration}s (${count} frames)`).join(", ") || "none";
      const flats = all.filter((item) => item.metadata.frameType === "FLAT");
      const onlyFlatDarks = darkExposures.size > 0 && [...darkExposures.keys()].every(
        (duration) => flats.some((item) => matchesExposure(item, duration)));
      throw new Error(
        `At least three exact-exposure ${exposure}s dark frames for the lights are required; found ${darks.length}.\n` +
        `Source folder: ${source}\n` +
        (profile.calibrationSourceRoot ? `Calibration folder: ${profile.calibrationSourceRoot}\n` : "") +
        `Detected dark exposures: ${detected}.\n` +
        (onlyFlatDarks ? "The detected darks match the flat exposures (dark-flats). They calibrate the flats, not these light frames.\n" : "") +
        `Choose a calibration folder containing a compatible ${exposure}s MasterDark FITS/XISF image or at least three ${exposure}s dark frames. Camera, gain/readout, binning and temperature must match the lights.`,
      );
    }
    groups.masterDarks[key] = darks.map((item) => all.indexOf(item));
    selected.push(...darks);
  }
  for (const filter of filters) {
    let possibleFlats = all.filter(
      (item) =>
        item.metadata.frameType === "FLAT" &&
        matchFilter(item.metadata.filterName, profile) === filter,
    );
    // Flats beside the capture take priority over a shared calibration library.
    if (automatic && possibleFlats.some(item => sourcePaths.has(item.path)))
      possibleFlats = possibleFlats.filter(item => sourcePaths.has(item.path));
    const requested = profile.flatExposureSeconds?.[filter];
    const flats = requested
      ? possibleFlats.filter((item) => matchesExposure(item, requested))
      : possibleFlats;
    if (flats.length < 3)
      throw new Error(`At least three ${filter} flats are required`);
    const exposure = flats[0].metadata.exposureSeconds;
    if (flats.some((item) => !matchesExposure(item, exposure)))
      throw new Error(`${filter} flats have ambiguous exposure durations`);
    const approval = profile.darkFlatExposureApprovals?.[filter];
    const darkFlatExposure = approval?.darkFlatExposureSeconds ?? exposure;
    const darkFlats = all.filter(
      (item) =>
        ["DARK", "DARKFLAT"].includes(item.metadata.frameType) &&
        (automatic || matchFilter(item.metadata.filterName, profile) === filter) &&
        matchesExposure(item, darkFlatExposure) &&
        matchesTemperature(item, flats.map(item => item.metadata)),
    );
    if (darkFlats.length < 3)
      throw new Error(
        `At least three exact-exposure ${filter} dark-flats are required`,
      );
    if (approval) {
      if (flats.some((item) => item.metadata.exposureSeconds !== approval.flatExposureSeconds) ||
          darkFlats.some((item) => item.metadata.exposureSeconds !== approval.darkFlatExposureSeconds))
        throw new Error(`${filter} dark-flat approval has different source exposures`);
      for (const [kind, items, checksums] of [
        ["flat", flats, approval.flatChecksums],
        ["dark-flat", darkFlats, approval.darkFlatChecksums],
      ]) {
        if (JSON.stringify(items.map((item) => item.checksum).sort()) !==
            JSON.stringify([...checksums].sort()))
          throw new Error(`${filter} sources differ from approved ${kind} checksums`);
      }
    }
    groups.filters[filter] = {
      exposureSeconds: exposure,
      darkFlatExposureSeconds: darkFlats[0].metadata.exposureSeconds,
      ...(approval ? { darkFlatExposureApproval: approval } : {}),
      lightExposureSeconds: lightExposures(profile, filter),
      flats: flats.map((item) => all.indexOf(item)),
      darkFlats: darkFlats.map((item) => all.indexOf(item)),
    };
    selected.push(...flats, ...darkFlats);
  }
  if (lights.length) {
    const settings = lightAcquisition(lights, profile);
    const tolerance = temperatureTolerance(profile);
    for (const frame of selected)
      assertSameSettings(frame.metadata, settings, frame.path);
    for (const [exposure, indices] of Object.entries(groups.masterDarks)) {
      const matchingLights = lights.filter((item) => String(item.exposureSeconds) === exposure);
      assertTemperatures(matchingLights,
        indices.map((index) => ({ ...all[index].metadata, path: all[index].path })),
        tolerance, `${exposure}s dark`);
    }
    for (const [filter, group] of Object.entries(groups.filters))
      assertTemperatures(
        group.flats.map((index) => ({ ...all[index].metadata, path: all[index].path })),
        group.darkFlats.map((index) => ({ ...all[index].metadata, path: all[index].path })),
        tolerance, `${filter} dark-flat`);
  }
  return { all, selected: [...new Map(selected.map(item => [item.checksum, item])).values()], groups, savedDarks };
}

export async function verifySources(candidates, masters) {
  for (const item of candidates) {
    const info = await stat(item.path);
    if (info.size !== item.size || info.mtimeMs !== item.mtimeMs)
      throw new Error("Original frame changed: " + item.path);
    await verifyChecksum(item.path, item.checksum);
  }
  for (const item of masters) await verifyChecksum(item.path, item.checksum);
}

export async function verifySavedMasterProvenance(masters, geometry, profile, lights = []) {
  const checked = new Set();
  const warnings = [];
  for (const master of masters) {
    await verifyChecksum(master.nativePath, master.nativeChecksum);
    if (master.preparation.method === "IMPORTED_MASTER") {
      await verifyCalibrationImage(master.nativePath, geometry);
      if (master.preparation.sourceChecksum !== master.nativeChecksum ||
          master.checksum !== master.nativeChecksum ||
          !Number.isFinite(master.preparation.exposureSeconds) ||
          !Array.isArray(master.preparation.confirmedMissingFields))
        throw new Error("Imported master identity record is incomplete: " + master.path);
      continue;
    }
    await verifyImage(master.nativePath, geometry);
    for (const kind of ["profileRequest", "profileReceipt"]) {
      const path = master.preparation[kind + "Path"];
      const checksum = master.preparation[kind + "Checksum"];
      if (!path || !/^[a-f0-9]{64}$/i.test(checksum ?? ""))
        throw new Error(
          "Master preparation record is incomplete: " + master.path,
        );
      if (!checked.has(path)) {
        await verifyChecksum(path, checksum);
        checked.add(path);
      }
    }
  }
  for (const { filter, exposureSeconds } of exposureGroups(profile)) {
    const dark = darkFor(profile, filter, exposureSeconds);
    const groupLights = lights.filter((item) => item.filter === filter &&
      item.exposureSeconds === exposureSeconds);
    if (groupLights.length && !assertMasterAcquisition(dark, groupLights,
      temperatureTolerance(profile), `${filter} ${exposureSeconds}s dark`))
      warnings.push(`Saved ${filter} ${exposureSeconds}s dark has no recorded gain/offset and measured-temperature identity; verify its preparation lineage before using it.`);
    const flat = profile.masters.flats[filter];
    if (groupLights.length && !assertMasterAcquisition(flat, groupLights,
      temperatureTolerance(profile), `${filter} flat`))
      warnings.push(`Saved ${filter} flat has no recorded gain/offset identity; verify its preparation lineage before using it.`);
    const exposure = dark.preparation.method === "IMPORTED_MASTER" ?
      (await readDarkMetadata(dark.nativePath)).exposureSeconds ?? dark.preparation.exposureSeconds :
      extname(dark.path).toLowerCase() === ".xisf"
        ? await readXisfExposure(dark.path)
        : (await readFitsMetadata(dark.path)).exposureSeconds;
    if (Math.abs(exposure - exposureSeconds) > 1e-4)
      throw new Error(
        `Saved ${filter} ${exposureSeconds}s dark exposure does not match selected lights`,
      );
  }
  return [...new Set(warnings)];
}
