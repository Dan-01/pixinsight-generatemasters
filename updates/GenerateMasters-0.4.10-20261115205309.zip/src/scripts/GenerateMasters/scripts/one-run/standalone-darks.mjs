import { readdir } from "node:fs/promises";
import { basename, extname, resolve } from "node:path";
import { mapFitsHeaders, readFitsMetadata } from "@piproc/fits";
import { fileChecksum } from "@piproc/shared";
import { exposureGroups } from "./profile.mjs";
import { readXisfHeader, readXisfGeometry, verifyCalibrationImage } from "./images.mjs";
import { acquisitionSettings, assertMasterAcquisition, temperatureTolerance } from "./identity.mjs";

function xmlValue(value) {
  return value.replace(/&#x([0-9a-f]+);|&#(\d+);|&(quot|apos|lt|gt|amp);/gi,
    (_, hex, decimal, entity) => hex || decimal ? String.fromCodePoint(parseInt(hex || decimal, hex ? 16 : 10)) :
      ({ quot: '"', apos: "'", lt: "<", gt: ">", amp: "&" })[entity.toLowerCase()]);
}
function attribute(tag, name) {
  const match = tag.match(new RegExp("\\b" + name + "\\s*=\\s*([\"'])(.*?)\\1"));
  return match ? xmlValue(match[2]) : undefined;
}
export async function readDarkMetadata(path) {
  if (extname(path).toLowerCase() !== ".xisf") return readFitsMetadata(path);
  const header = await readXisfHeader(path), geometry = await readXisfGeometry(path);
  const headers = {};
  for (const tag of header.match(/<FITSKeyword\b[^>]*>/g) ?? []) {
    const key = attribute(tag, "name"), text = attribute(tag, "value");
    if (!key || text === undefined) continue;
    if (Object.hasOwn(headers, key)) throw new Error("Duplicate XISF FITS keyword: " + key);
    headers[key] = text.startsWith("'") && text.endsWith("'")
      ? text.slice(1, -1).replace(/''/g, "'").trim()
      : /^[+-]?(?:\d+\.?\d*|\.\d+)(?:[de][+-]?\d+)?$/i.test(text.trim())
        ? Number(text.replace(/[dD]/, "e")) : text;
  }
  return mapFitsHeaders({ ...headers, NAXIS1: geometry.width, NAXIS2: geometry.height });
}
async function* images(root) {
  for (const entry of await readdir(root, { withFileTypes: true })) {
    const path = resolve(root, entry.name);
    if (entry.isDirectory()) yield* images(path);
    else if (entry.isFile() && /\.(xisf|fits?|fts)$/i.test(entry.name) &&
      !/rejection|processinstance/i.test(entry.name)) yield path;
  }
}

// Import an existing image, without pretending its original integration was audited.
// Missing acquisition values may be supplied by the user's capture-record confirmation.
export async function loadStandaloneDarks(roots, profile, lights, { paths = [], ignorePaths = [], confirmMissing = false, automatic = false } = {}) {
  const needed = new Set(exposureGroups(profile).map(g => String(g.exposureSeconds)));
  const candidates = new Set(paths.map(path => resolve(path)));
  if (!paths.length) for (const root of roots) for await (const path of images(root)) {
    if (/master[ _-]*dark|dark[ _-]*master/i.test(basename(path))) candidates.add(path);
  }
  const ignored = new Set(ignorePaths), result = {};
  for (const path of candidates) {
    if (ignored.has(path)) continue;
    // Published libraries commonly contain both formats of the same integration.
    // Use its native image directly; old library JSON can contain moved paths.
    if (!paths.length && extname(path).toLowerCase() !== ".xisf" &&
        [...candidates].some(candidate => candidate.toLowerCase() ===
          path.replace(/\.(fits?|fts)$/i, ".xisf").toLowerCase())) continue;
    const metadata = await readDarkMetadata(path);
    const declaredType = String(metadata.rawHeaders.IMAGETYP ?? "").toUpperCase().replace(/[ _-]/g, "");
    if (declaredType && !["DARK", "DARKFRAME", "MASTERDARK", "MASTERDARKFRAME"].includes(declaredType))
      throw new Error("Selected master dark is labelled as another image type: " + path);
    let exposure = metadata.exposureSeconds;
    const missing = [];
    if (!(exposure > 0)) {
      exposure = Number(basename(path).match(/(?:^|[_\s-])(\d+(?:\.\d+)?)s(?:[_\s.-]|$)/i)?.[1]);
      if (!(exposure > 0) && paths.length && needed.size === 1) exposure = Number([...needed][0]);
      if (!(exposure > 0)) throw new Error("Master dark has no exposure metadata. Name it MasterDark_300s.xisf (using its actual exposure): " + path);
      missing.push("exposure (using " + exposure + "s)");
    }
    if (!needed.has(String(exposure))) {
      if (paths.length) throw new Error("Selected " + exposure + "s master dark does not match any selected light exposure: " + path);
      continue;
    }
    const groupLights = lights.filter(light => light.exposureSeconds === exposure);
    const expected = { ...profile.equipment, ...acquisitionSettings(groupLights[0] ?? profile.equipment) };
    if (automatic && !paths.length && (
      ["cameraName", "cameraDriver", "readoutMode", "binX", "binY", "width", "height", "gain", "offset"]
        .some(key => metadata[key] !== undefined && expected[key] !== undefined &&
          (metadata[key] ?? null) !== (expected[key] ?? null)) ||
      (Number.isFinite(metadata.electronsPerAdu) &&
        Math.abs(metadata.electronsPerAdu - expected.electronsPerAdu) > 1e-6) ||
      (Number.isFinite(metadata.sensorTemperature) && groupLights.some(light =>
        Math.abs(light.sensorTemperature - metadata.sensorTemperature) > temperatureTolerance(profile)))
    )) continue;
    await verifyCalibrationImage(path, profile.equipment);
    for (const key of ["cameraName", "cameraDriver", "readoutMode", "electronsPerAdu", "binX", "binY", "gain", "offset"]) {
      const actual = metadata[key], required = expected[key];
      if (actual === undefined) {
        if (required !== null && required !== undefined) missing.push(key);
      } else if (required !== undefined && required !== null &&
        (key === "electronsPerAdu" ? Math.abs(actual - required) > 1e-6 : actual !== required))
        throw new Error("Master dark " + key + " does not match the lights: " + path);
      else if ((key === "gain" || key === "offset") && required === null)
        throw new Error("Master dark gain/offset identity differs from selected lights: " + path);
    }
    let temperature = metadata.sensorTemperature;
    if (!Number.isFinite(temperature)) {
      missing.push("sensor temperature");
      temperature = groupLights[0]?.sensorTemperature;
    }
    if (missing.length && !confirmMissing)
      throw new Error("Master dark is missing " + missing.join(", ") + ". Check its capture records, then enable Confirm missing master-dark metadata in Advanced: " + path);
    const acquisition = { ...acquisitionSettings(expected), temperatureRangeC: [temperature, temperature] };
    if (groupLights.length) assertMasterAcquisition({ acquisition }, groupLights, temperatureTolerance(profile), `${exposure}s dark`);
    const checksum = await fileChecksum(path);
    const master = { path, checksum, nativePath: path, nativeChecksum: checksum,
      registrationId: checksum, opticalTrainId: profile.opticalTrainId, acquisition,
      preparation: { method: "IMPORTED_MASTER", exposureSeconds: exposure, operator: profile.operator,
        tool: "Existing master dark import", toolVersion: "1", inputChecksums: [checksum], parentMasters: [],
        sourcePath: path, sourceChecksum: checksum, metadata, confirmedMissingFields: missing },
      warnings: missing.length ? ["Imported " + exposure + "s dark: " + missing.join(", ") + " confirmed by " + profile.operator + " from capture records."] : [] };
    if (result[String(exposure)] && result[String(exposure)].checksum !== checksum)
      throw new Error(`Multiple different ${exposure}s master darks. Choose a calibration folder containing one compatible master per exposure, or use --master-dark-files to select one explicitly.`);
    result[String(exposure)] = master;
  }
  return result;
}
