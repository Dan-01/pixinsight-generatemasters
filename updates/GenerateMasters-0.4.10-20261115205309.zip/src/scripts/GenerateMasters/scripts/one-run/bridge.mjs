import { setTimeout as delay } from "node:timers/promises";
import { randomUUID } from "node:crypto";
import { execFile, spawn } from "node:child_process";
import { constants, existsSync } from "node:fs";
import { access, mkdir, open, rm, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { promisify } from "node:util";
import { projectRoot } from "./constants.mjs";

const execute = promisify(execFile);

// Capture the launcher by its PID before the worker starts. A terminal-run job
// has no PixInsight parent and must not activate an unrelated desktop instance.
export async function desktopRestoration(
  executable,
  parentPid = process.ppid,
  run = execute,
) {
  const enumerate = async () => {
    const { stdout } = await run(executable, ["--enumerate"], {
      timeout: 5000,
      maxBuffer: 64 * 1024,
    });
    return stdout
      .split(/\r?\n/)
      .map((line) => /^\s*(\d+)\s+(\d+)\s*$/.exec(line))
      .find((row) => row && Number(row[2]) === parentPid)?.[1];
  };
  let instance;
  try {
    instance = await enumerate();
  } catch (error) {
    console.warn(
      "Could not identify the PixInsight launcher window: " + error.message,
    );
  }
  return async () => {
    if (!instance) return;
    try {
      // The launcher may have closed while processing. Never yield to a slot
      // now occupied by another process, or start a replacement application.
      if ((await enumerate()) !== instance) return;
      await run(executable, ["--yield=" + instance], {
        timeout: 5000,
        maxBuffer: 64 * 1024,
      });
    } catch (error) {
      console.warn(
        "Could not restore the PixInsight launcher window: " + error.message,
      );
    }
  };
}

export async function ensureBridge(
  client,
  config,
  profile,
  journalPath,
  launcherPid = process.ppid,
) {
  const status = await client.getStatus();
  if (status.state !== "offline" && status.state !== "error")
    return async () => {};
  const executable =
    profile.pixInsightExecutable ??
    "/Applications/PixInsight/PixInsight.app/Contents/MacOS/PixInsight";
  await access(executable, constants.X_OK);
  const restoreDesktop = await desktopRestoration(executable, launcherPid);
  const token = randomUUID();
  const logPath = journalPath + ".pixinsight.log";
  const launcherPath = journalPath + "." + token + ".launch.js";
  await mkdir(dirname(logPath), { recursive: true });
  const bundledBridge = resolve(projectRoot, "runtime/bridge/bridge.js");
  const bridgeScript = existsSync(bundledBridge)
    ? bundledBridge
    : resolve(projectRoot, "pixinsight/bridge/bridge.js");
  await writeFile(
    launcherPath,
    `#engine v8\nParameters.set("bridgePath", ${JSON.stringify(config.bridge.path)});\n` +
      `Parameters.set("autoStopToken", ${JSON.stringify(token)});\n` +
      `Parameters.set("sessionSeconds", 14400);\n` +
      `#include "${bridgeScript}"\n`,
    { flag: "wx", mode: 0o600 },
  );
  const log = await open(logPath, "a");
  const child = spawn(
    executable,
    [
      "-n",
      "--force-exit",
      "--automation-mode",
      "--no-focus-stealing",
      "-r=" + launcherPath,
    ],
    {
      stdio: ["ignore", log.fd, log.fd],
      detached: false,
    },
  );
  let startupError;
  let logClosed = false;
  const closeLog = () => {
    if (!logClosed) {
      logClosed = true;
      void log.close().catch(() => {});
      void rm(launcherPath, { force: true }).catch(() => {});
    }
  };
  child.once("error", (error) => {
    startupError = error;
    closeLog();
  });
  child.once("exit", closeLog);
  try {
    for (let i = 0; i < 120; ++i) {
      if (startupError) throw startupError;
      if (child.exitCode !== null)
        throw new Error(
          "PixInsight exited before bridge startup; see " + logPath,
        );
      await delay(500);
      const current = await client.getStatus();
      // Readiness is followed by the strict versioned adapter/capability probe in main.
      // Transport schema validation remains the client's responsibility.
      if (current.state === "idle") {
        console.log("Started PixInsight bridge automatically");
        return async () => {
          try {
            await writeFile(
              resolve(config.bridge.path, `one-run-stop-${token}.json`),
              JSON.stringify({ token }),
              { flag: "wx" },
            );
            for (let j = 0; j < 60 && child.exitCode === null; ++j)
              await delay(500);
            if (child.exitCode === null)
              console.warn(
                "PixInsight did not stop promptly; inspect " + logPath,
              );
          } finally {
            await restoreDesktop();
          }
        };
      }
    }
    child.kill("SIGTERM");
    throw new Error(
      "PixInsight bridge did not start within 60 seconds; see " + logPath,
    );
  } catch (error) {
    await restoreDesktop();
    throw error;
  }
}
