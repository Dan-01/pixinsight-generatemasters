import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import {
  chmod,
  copyFile,
  mkdir,
  readFile,
  rm,
  writeFile,
} from "node:fs/promises";
import { dirname, extname, resolve } from "node:path";
import { assertOutputRoot, fileChecksum, verifyChecksum } from "@piproc/shared";
import { verifyImage, waitForStageImages } from "./images.mjs";
import { atomicJson } from "./journal.mjs";
import { stageAdapter } from "./constants.mjs";
import { verifyDrizzleData } from "./drizzle.mjs";

export async function stage(
  name,
  request,
  mapping,
  run,
  journal,
  journalPath,
  client,
  config,
  retryFailed,
) {
  const measurementStage = request.stage === "MEASURE";
  const normalizationStage = request.stage === "NORMALIZE";
  const imageStage = !measurementStage && !normalizationStage;
  const geometry = request.stage === "DRIZZLE"
    ? { width: run.geometry.width * request.scale, height: run.geometry.height * request.scale } : run.geometry;
  const records = () => Object.values(journal.stages).filter(item => item.status === "SUCCEEDED")
    .flatMap(item => [...item.outputs, ...(item.drizzleData ?? [])]);
  run.report?.("stage", {
    stage: name,
    frames: request.inputs.length,
    journalPath,
  });
  let prior = journal.stages[name];
  if (prior?.status === "SUCCEEDED") {
    for (const item of prior.outputs) {
      await verifyChecksum(item.path, item.checksum);
      if (imageStage) await verifyImage(item.path, geometry);
    }
    for (const item of prior.drizzleData ?? []) {
      await verifyChecksum(item.path, item.checksum);
      await verifyChecksum(item.sourcePath, item.sourceChecksum);
      await verifyChecksum(item.targetPath, item.targetChecksum);
      await verifyDrizzleData(item.path, { source: item.sourcePath, target: item.targetPath,
        geometry: run.geometry, rejection: request.stage === "INTEGRATE" });
    }
    return prior;
  }
  if (prior?.status === "FAILED" && !retryFailed)
    throw new Error(
      `${name} previously failed; inspect ${journalPath}, then use --retry-failed`,
    );
  if (prior?.status === "PREPARING") {
    const base = resolve(config.bridge.path, "jobs", prior.id);
    const marker = await readFile(resolve(base, "one-run.marker"), "utf8");
    if (marker.trim() !== run.fingerprint)
      throw new Error("Unfinished stage marker mismatch: " + base);
    await rm(base, { recursive: true });
    journal.attempts = journal.attempts.filter((id) => id !== prior.id);
    delete journal.stages[name];
    prior = undefined;
    await atomicJson(journalPath, journal);
  }
  let entry = prior?.status === "RUNNING" ? prior : undefined;
  if (!entry) {
    const id = randomUUID();
    const base = resolve(config.bridge.path, "jobs", id);
    await assertOutputRoot(base, [run.source, run.output, ...(run.calibrationSource ? [run.calibrationSource] : [])]);
    await mkdir(resolve(base, "output"), { recursive: true, mode: 0o700 });
    await writeFile(resolve(base, "one-run.marker"), run.fingerprint + "\n", {
      flag: "wx",
    });
    entry = {
      id,
      createdAt: new Date().toISOString(),
      status: "PREPARING",
      requestPath: resolve(base, "request.json"),
    };
    journal.stages[name] = entry;
    journal.attempts.push(id);
    await atomicJson(journalPath, journal);
    const inputs = [];
    const completedOutputs = new Map(records().map(item => [item.path, item.checksum]));
    for (let i = 0; i < request.inputs.length; ++i) {
      const input = request.inputs[i];
      if (mapping === "ALIAS") {
        const alias = resolve(
          base,
          "input",
          `${name}-${String(i).padStart(4, "0")}.fits`,
        );
        await mkdir(dirname(alias), { recursive: true });
        const checksum = run.sourceChecksums.get(input);
        if (!checksum)
          throw new Error("Uncatalogued source snapshot: " + input);
        await verifyChecksum(input, checksum);
        await copyFile(
          input,
          alias,
          constants.COPYFILE_EXCL | constants.COPYFILE_FICLONE,
        );
        await chmod(alias, 0o444);
        await verifyChecksum(alias, checksum);
        inputs.push(alias);
      } else {
        const checksum = completedOutputs.get(input);
        if (!checksum) throw new Error("Unverified staged input: " + input);
        await verifyChecksum(input, checksum);
        inputs.push(input);
      }
    }
    if (request.stage === "ALIGN" || normalizationStage) {
      const checksum = completedOutputs.get(request.referencePath);
      if (!checksum) throw new Error("Unverified alignment reference");
      await verifyChecksum(request.referencePath, checksum);
    }
    const native = {
      ...request,
      inputs,
      adapter: stageAdapter,
      expectedVersion: run.pixInsightVersion,
      outputDirectory: resolve(base, "output"),
    };
    if (request.stage === "INTEGRATE" && request.drizzleDataPaths?.length) {
      if (request.drizzleDataPaths.length !== request.inputs.length) throw new Error("Incomplete drizzle stack");
      entry.drizzleParents = [];
      native.drizzleDataPaths = [];
      for (let index = 0; index < request.inputs.length; ++index) {
        const path = request.drizzleDataPaths[index];
        const record = Object.values(journal.stages).flatMap(item => item.drizzleData ?? []).find(item => item.path === path);
        if (!record || record.targetPath !== request.inputs[index]) throw new Error("Drizzle alignment record does not match its registered light");
        await verifyChecksum(path, record.checksum);
        await verifyChecksum(record.sourcePath, record.sourceChecksum);
        await verifyDrizzleData(path, { source: record.sourcePath, target: record.targetPath, geometry: run.geometry });
        const snapshot = resolve(base, "drizzle", index + ".xdrz");
        await mkdir(dirname(snapshot), { recursive: true });
        // ImageIntegration writes rejection data into this private writable copy.
        await copyFile(path, snapshot, constants.COPYFILE_EXCL);
        await chmod(snapshot, 0o644);
        entry.drizzleParents.push(record); native.drizzleDataPaths.push(snapshot);
      }
    }
    if (request.stage === "DRIZZLE") {
      for (const path of inputs) {
        const record = Object.values(journal.stages).filter(item => item.status === "SUCCEEDED")
          .flatMap(item => item.drizzleData ?? []).find(item => item.path === path);
        if (!record?.rejection) throw new Error("Drizzle requires verified per-frame rejection data");
        await verifyChecksum(record.sourcePath, record.sourceChecksum);
        await verifyChecksum(record.targetPath, record.targetChecksum);
        await verifyDrizzleData(path, { source: record.sourcePath, target: record.targetPath,
          geometry: run.geometry, rejection: true });
      }
    }
    if (request.stage === "CALIBRATE") {
      for (const key of ["darkPath", "flatPath"]) {
        const source = request[key];
        const checksum = run.masterChecksums.get(source);
        if (!checksum)
          throw new Error("Uncatalogued calibration master: " + source);
        await verifyChecksum(source, checksum);
        await verifyImage(source, run.geometry);
        const snapshot = resolve(
          base,
          "masters",
          key + extname(source).toLowerCase(),
        );
        await mkdir(dirname(snapshot), { recursive: true });
        await copyFile(
          source,
          snapshot,
          constants.COPYFILE_EXCL | constants.COPYFILE_FICLONE,
        );
        await chmod(snapshot, 0o444);
        await verifyChecksum(snapshot, checksum);
        native[key] = snapshot;
      }
    }
    if (request.stage === "INTEGRATE" && request.normalization === "LOCAL_NORMALIZATION") {
      if (!Array.isArray(request.normalizationDataPaths) ||
          request.normalizationDataPaths.length !== request.inputs.length)
        throw new Error("Missing normalization data for the integration stack");
      for (const dataPath of request.normalizationDataPaths) {
        const checksum = completedOutputs.get(dataPath);
        if (!checksum) throw new Error("Unverified LocalNormalization data: " + dataPath);
        await verifyChecksum(dataPath, checksum);
      }
    }
    await writeFile(resolve(base, "request.json"), JSON.stringify(native), {
      flag: "wx",
      mode: 0o600,
    });
    entry.requestChecksum = await fileChecksum(entry.requestPath);
    entry.status = "RUNNING";
    await atomicJson(journalPath, journal);
  }
  if (prior?.status === "RUNNING") {
    await verifyChecksum(entry.requestPath, entry.requestChecksum);
    const native = JSON.parse(await readFile(entry.requestPath, "utf8"));
    if (
      native.adapter !== stageAdapter ||
      native.stage !== request.stage ||
      native.inputs?.length !== request.inputs.length ||
      native.outputDirectory !==
        resolve(config.bridge.path, "jobs", entry.id, "output")
    )
      throw new Error("Resumed native request differs from its run stage");
    for (let i = 0; i < native.inputs.length; ++i) {
      const source = request.inputs[i];
      const expected =
        mapping === "ALIAS"
          ? run.sourceChecksums.get(source)
          : records()
              .find((item) => item.path === source)?.checksum;
      if (!expected || (mapping === "DIRECT" && native.inputs[i] !== source))
        throw new Error("Resumed stage input is not catalogued: " + source);
      await verifyChecksum(native.inputs[i], expected);
    }
    if (request.stage === "CALIBRATE") {
      for (const key of ["darkPath", "flatPath"])
        await verifyChecksum(
          native[key],
          run.masterChecksums.get(request[key]),
        );
    }
    if (normalizationStage) {
      if (native.referencePath !== request.referencePath ||
          native.scale !== request.scale)
        throw new Error("Resumed normalization reference or scale changed");
      const reference = Object.values(journal.stages)
        .flatMap((item) => item.outputs ?? [])
        .find((item) => item.path === request.referencePath);
      if (!reference) throw new Error("Resumed normalization reference is unverified");
      await verifyChecksum(native.referencePath, reference.checksum);
    }
    if (request.stage === "INTEGRATE") {
      if (native.normalization !== request.normalization ||
          native.weighting !== request.weighting ||
          native.rejection !== request.rejection ||
          native.sigmaLow !== request.sigmaLow ||
          native.sigmaHigh !== request.sigmaHigh ||
          JSON.stringify(native.normalizationDataPaths ?? []) !==
            JSON.stringify(request.normalizationDataPaths ?? []))
        throw new Error("Resumed integration policy or normalization data changed");
      for (const dataPath of native.normalizationDataPaths ?? []) {
        const record = Object.values(journal.stages)
          .flatMap((item) => item.outputs ?? [])
          .find((item) => item.path === dataPath);
        if (!record) throw new Error("Resumed normalization data is unverified");
        await verifyChecksum(dataPath, record.checksum);
      }
      for (const record of entry.drizzleParents ?? []) await verifyChecksum(record.path, record.checksum);
      if (JSON.stringify((entry.drizzleParents ?? []).map(item => item.path)) !== JSON.stringify(request.drizzleDataPaths ?? []))
        throw new Error("Resumed drizzle alignment stack changed");
    }
    if ((request.stage === "ALIGN" && Boolean(native.drizzle) !== Boolean(request.drizzle)) ||
        (request.stage === "DRIZZLE" && (native.scale !== request.scale || native.dropShrink !== request.dropShrink)))
      throw new Error("Resumed drizzle settings changed");
  }
  console.log(`${name}: running ${request.inputs.length} image(s)`);
  try {
    const receipt = await client.execute(
      "one_run_stage",
      {
        adapter: stageAdapter,
        jobId: entry.id,
        requestPath: entry.requestPath,
      },
      { id: entry.id, createdAt: entry.createdAt },
    );
    const data = receipt.data;
    if (
      !data ||
      data.adapter !== stageAdapter ||
      data.stage !== request.stage ||
      !Array.isArray(data.outputs)
    )
      throw new Error("Malformed one-run native receipt");
    const base = resolve(config.bridge.path, "jobs", entry.id, "output");
    for (const path of data.outputs) {
      if (typeof path !== "string" || !resolve(path).startsWith(base + "/"))
        throw new Error("Native output escaped stage directory");
      if (extname(path).toLowerCase() !==
          (measurementStage ? ".json" : normalizationStage ? ".xnml" : ".xisf"))
        throw new Error(
          "GenerateMasters stage produced an unexpected output format: " + path,
        );
    }
    if (imageStage) await waitForStageImages(data.outputs, geometry);
    const outputs = [];
    for (const path of data.outputs) {
      if (imageStage) await verifyImage(path, geometry);
      const checksum = await fileChecksum(path);
      await chmod(path, 0o444);
      outputs.push({ path, checksum });
    }
    if (!outputs.length) throw new Error("Native stage produced no images");
    if (measurementStage) {
      if (outputs.length !== 1 ||
          !Array.isArray(data.measurements) ||
          data.measurements.length !== request.inputs.length)
        throw new Error("Native measurement receipt is incomplete");
      const report = JSON.parse(await readFile(outputs[0].path, "utf8"));
      if (report.adapter !== stageAdapter ||
          JSON.stringify(report.measurements) !== JSON.stringify(data.measurements))
        throw new Error("Native measurement report differs from receipt");
      entry.measurements = data.measurements;
    }
    if (normalizationStage &&
        (outputs.length !== request.inputs.length ||
         new Set(outputs.map((item) => item.path)).size !== outputs.length))
      throw new Error("LocalNormalization returned an incomplete or duplicate data set");
    if (["INTEGRATE", "DRIZZLE"].includes(request.stage) &&
        (data.statistics?.numberOfImages !== request.inputs.length ||
         !Number.isFinite(data.statistics.totalRejectedLow) ||
         !Number.isFinite(data.statistics.totalRejectedHigh)))
      throw new Error("Native integration statistics do not match its input stack");
    if (request.stage === "ALIGN") {
      if (!Array.isArray(data.alignments) ||
          data.alignments.length !== request.inputs.length)
        throw new Error("Native alignment diagnostics are incomplete");
      const reported = new Set(data.outputs);
      for (let index = 0; index < data.alignments.length; ++index) {
        const row = data.alignments[index];
        if (row.inputPath !== request.inputs[index] ||
            row.succeeded !== reported.has(row.outputPath) ||
            (row.succeeded && !row.diagnostics) ||
            (!row.succeeded && row.diagnostics))
          throw new Error("Native alignment diagnostics differ from verified outputs");
      }
      entry.alignments = data.alignments;
    }
    const wantsDrizzleData = request.stage === "ALIGN" && request.drizzle || request.stage === "INTEGRATE" && request.drizzleDataPaths?.length;
    if (wantsDrizzleData) {
      const native = JSON.parse(await readFile(entry.requestPath, "utf8"));
      const targets = request.stage === "ALIGN" ? data.outputs : request.inputs;
      if (data.drizzleDataPaths?.length !== targets.length || new Set(data.drizzleDataPaths).size !== targets.length)
        throw new Error("Missing or duplicate drizzle records");
      entry.drizzleData = [];
      const known = new Map([...records(), ...outputs].map(item => [item.path, item.checksum]));
      for (let index = 0; index < targets.length; ++index) {
        const targetPath = targets[index], path = data.drizzleDataPaths[index];
        const sourcePath = request.stage === "ALIGN"
          ? data.alignments.find(item => item.outputPath === targetPath)?.inputPath : entry.drizzleParents[index].sourcePath;
        const expectedPath = request.stage === "ALIGN" ? targetPath.replace(/\.xisf$/i, ".xdrz") : native.drizzleDataPaths[index];
        if (path !== expectedPath || !resolve(path).startsWith(dirname(base) + "/") || !known.has(sourcePath) || !known.has(targetPath))
          throw new Error("Unverified drizzle record path or image reference");
        const details = await verifyDrizzleData(path, { source: sourcePath, target: targetPath,
          geometry: run.geometry, rejection: request.stage === "INTEGRATE" });
        const checksum = await fileChecksum(path); await chmod(path, 0o444);
        entry.drizzleData.push({ path, checksum, ...details, sourceChecksum: known.get(sourcePath),
          targetChecksum: known.get(targetPath), rejection: request.stage === "INTEGRATE" });
      }
    }
    entry.status = "SUCCEEDED";
    entry.outputs = outputs;
    entry.failed = data.failed ?? [];
    entry.statistics = data.statistics ?? null;
    entry.masters = data.masters ?? null;
    entry.processInstancePath = data.processInstancePath;
    await atomicJson(journalPath, journal);
    return entry;
  } catch (error) {
    entry.status = "FAILED";
    entry.error = error instanceof Error ? error.message : String(error);
    await atomicJson(journalPath, journal);
    throw error;
  }
}
