import { constants } from "node:fs";
import { chmod, copyFile, lstat, mkdir, readFile, rename, rm, unlink, writeFile } from "node:fs/promises";
import { basename, dirname, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { randomUUID } from "node:crypto";
import { fileChecksum, verifyChecksum } from "@piproc/shared";
import { atomicJson } from "./journal.mjs";
import { sha } from "./constants.mjs";
import { acceptedQualityChecksums, readQualityDecisions } from "./quality.mjs";

async function context(reviewPath, checksum) {
  reviewPath = resolve(reviewPath);
  await verifyChecksum(reviewPath, checksum);
  const review = JSON.parse(await readFile(reviewPath, "utf8"));
  if (review.kind !== "one-run-quality-review" || !/^[a-f0-9]{64}$/.test(review.fingerprint) ||
      basename(reviewPath) !== review.fingerprint + ".quality-review.json")
    throw new Error("Blink requires a matching measured frame review");
  const root = reviewPath.replace(/\.quality-review\.json$/, ".blink-review");
  const output = basename(dirname(reviewPath)) === ".piproc-runs" ? dirname(dirname(reviewPath)) : dirname(reviewPath);
  const visibleRoot = resolve(output, "Blink Review", review.fingerprint);
  for (const path of [root, dirname(visibleRoot), visibleRoot]) {
    try {
      const folder = await lstat(path);
      if (!folder.isDirectory() || folder.isSymbolicLink()) throw new Error("Unexpected Blink review root");
    } catch (error) { if (error.code !== "ENOENT") throw error; }
  }
  return { reviewPath, checksum, review, root, visibleRoot };
}

async function optionalJson(path) {
  try { return JSON.parse(await readFile(path, "utf8")); }
  catch (error) { if (error.code === "ENOENT") return null; throw error; }
}

function selectedFrames(review, filter) {
  return review.frames.filter(frame => frame.needsDecision &&
    (filter === "ALL" || (filter === "FLAGGED" ? frame.flags?.length > 0 : frame.filter === filter)));
}

async function validateSet(ctx, manifestPath, expectedFilter, allowMissingDirectory = false) {
  const set = JSON.parse(await readFile(manifestPath, "utf8"));
  if (set.kind !== "one-run-blink-review" || set.version !== 1 ||
      set.fingerprint !== ctx.review.fingerprint || set.reviewChecksum !== ctx.checksum ||
      (expectedFilter !== undefined && set.filter !== expectedFilter) ||
      basename(manifestPath) !== sha(set.filter).slice(0, 16) + ".json" ||
      dirname(resolve(manifestPath)) !== ctx.root ||
      ![ctx.root, ctx.visibleRoot].includes(dirname(resolve(set.directory))) || !Array.isArray(set.frames) || !set.frames.length)
    throw new Error("Blink review set does not match this measured run");
  const pending = new Map(selectedFrames(ctx.review, set.filter).map(f => [f.sourceChecksum, f]));
  const seen = new Set();
  for (const frame of set.frames) {
    const source = pending.get(frame.sourceChecksum);
    if (!source || seen.has(frame.sourceChecksum) || source.metrics.filePath !== frame.calibratedPath ||
        dirname(resolve(frame.copyPath)) !== set.directory || !/^[a-f0-9]{64}$/.test(frame.calibratedChecksum))
      throw new Error("Blink review contains an unexpected frame or copy path");
    seen.add(frame.sourceChecksum);
  }
  if (seen.size !== pending.size) throw new Error("Blink review set does not cover the complete selected group");
  let folder;
  try { folder = await lstat(set.directory); }
  catch (error) {
    if (error.code === "ENOENT" && allowMissingDirectory) return { ...set, missingDirectory: true };
    if (error.code === "ENOENT") throw new Error("The Blink review folder was removed. Click Open review set in Blink to prepare it again before inspecting and importing.", { cause: error });
    throw error;
  }
  if (!folder.isDirectory() || folder.isSymbolicLink()) throw new Error("Blink review folder is unavailable");
  const marker = JSON.parse(await readFile(resolve(set.directory, "review-set.json"), "utf8"));
  if (marker.reviewChecksum !== ctx.checksum || marker.fingerprint !== ctx.review.fingerprint)
    throw new Error("Blink review folder marker differs from this run");
  return set;
}

async function makeSetVisible(ctx, manifestPath, set) {
  if (dirname(set.directory) === ctx.visibleRoot) return set;
  await mkdir(ctx.visibleRoot, { recursive: true });
  const directory = resolve(ctx.visibleRoot, basename(set.directory));
  try { await lstat(directory); throw new Error("Blink review destination already exists"); }
  catch (error) { if (error.code !== "ENOENT") throw error; }
  const moved = { ...set, directory, frames: set.frames.map(frame => ({ ...frame,
    copyPath: resolve(directory, basename(frame.copyPath)) })) };
  // Move the existing set intact, including rejected files and absent copies.
  // Recreating it would lose the user's inspection decisions.
  await rename(set.directory, directory);
  try { await atomicJson(manifestPath, moved); }
  catch (error) { await rename(directory, set.directory); throw error; }
  return moved;
}

export async function prepareBlinkReview(reviewPath, checksum, filter = "ALL") {
  const ctx = await context(reviewPath, checksum);
  const frames = selectedFrames(ctx.review, filter);
  if (!frames.length) throw new Error("No frames need review in this Blink group");
  const manifestPath = resolve(ctx.root, sha(filter).slice(0, 16) + ".json");
  let rebuiltMissingSet = false;
  if (await optionalJson(manifestPath)) {
    const existing = await validateSet(ctx, manifestPath, filter, true);
    if (!existing.missingDirectory) {
      const set = await makeSetVisible(ctx, manifestPath, existing);
      return { manifestPath, directory: set.directory, frames: set.frames.length, filter, manifestChecksum: await fileChecksum(manifestPath) };
    }
    rebuiltMissingSet = true;
  }
  const journal = JSON.parse(await readFile(ctx.reviewPath.replace(/\.quality-review\.json$/, ".json"), "utf8"));
  if (journal.fingerprint !== ctx.review.fingerprint) throw new Error("Calibration journal mismatch");
  const outputs = new Map(Object.entries(journal.stages).filter(([name, stage]) =>
    name.startsWith("CALIBRATE_") && stage.status === "SUCCEEDED")
    .flatMap(([, stage]) => stage.outputs.map(output => [output.path, output.checksum])));
  await mkdir(ctx.root, { recursive: true });
  await mkdir(ctx.visibleRoot, { recursive: true });
  const directory = resolve(ctx.visibleRoot, "set-" + randomUUID());
  await mkdir(directory);
  try {
    await mkdir(resolve(directory, "Rejected"));
    const copies = [];
    for (const [index, frame] of frames.entries()) {
      const calibratedPath = frame.metrics.filePath, calibratedChecksum = outputs.get(calibratedPath);
      if (!calibratedChecksum) throw new Error("Blink frame has no verified calibration output");
      await verifyChecksum(calibratedPath, calibratedChecksum);
      const name = basename(frame.sourcePath).replace(/\.[^.]+$/, "").replace(/[^a-zA-Z0-9._-]/g, "_");
      const copyPath = resolve(directory, String(index + 1).padStart(4, "0") + "_" + frame.filter.replace(/[^a-zA-Z0-9_-]/g, "_") + "_" + name + ".xisf");
      await copyFile(calibratedPath, copyPath, constants.COPYFILE_EXCL | constants.COPYFILE_FICLONE);
      await verifyChecksum(copyPath, calibratedChecksum);
      await chmod(copyPath, 0o644);
      copies.push({ sourceChecksum: frame.sourceChecksum, calibratedPath, calibratedChecksum, copyPath });
    }
    const set = { version: 1, kind: "one-run-blink-review", fingerprint: ctx.review.fingerprint,
      reviewChecksum: checksum, directory, filter, frames: copies };
    await writeFile(resolve(directory, "review-set.json"), JSON.stringify({ fingerprint: set.fingerprint, reviewChecksum: checksum }), { flag: "wx" });
    await atomicJson(manifestPath, set);
    return { manifestPath, directory, frames: copies.length, filter, rebuiltMissingSet, manifestChecksum: await fileChecksum(manifestPath) };
  } catch (error) { await rm(directory, { recursive: true, force: true }); throw error; }
}

async function inspectBlinkCopies(reviewPath, checksum, filter) {
  const ctx = await context(reviewPath, checksum);
  const manifestPath = resolve(ctx.root, sha(filter).slice(0, 16) + ".json");
  const set = await validateSet(ctx, manifestPath, filter);
  const decisions = [];
  for (const frame of set.frames) {
    let exists = true;
    try {
      const info = await lstat(frame.copyPath);
      if (!info.isFile() || info.isSymbolicLink()) throw new Error("Blink review copy was replaced: " + frame.copyPath);
      await verifyChecksum(frame.copyPath, frame.calibratedChecksum);
    } catch (error) { if (error.code === "ENOENT") exists = false; else throw error; }
    decisions.push({ sourceChecksum: frame.sourceChecksum,
      classification: exists ? "ACCEPT" : "REJECT",
      rationale: exists ? "Retained after Blink inspection." : "Removed from the Blink review set." });
  }
  const receipt = { manifestPath, manifestChecksum: await fileChecksum(manifestPath), decisions,
    accepted: decisions.filter(d => d.classification === "ACCEPT").length,
    rejected: decisions.filter(d => d.classification === "REJECT").length };
  return { ...receipt, directory: set.directory, filter };
}

export async function importBlinkDecisions(reviewPath, checksum, filter, note, confirmed) {
  if (!confirmed || typeof note !== "string" || note.trim().length < 12)
    throw new Error("Confirm you reviewed every remaining frame and enter a specific inspection note");
  const receipt = await inspectBlinkCopies(reviewPath, checksum, filter);
  receipt.decisions = receipt.decisions.map(item => ({ ...item, rationale: item.rationale + " " + note.trim() }));
  await atomicJson(receipt.manifestPath.replace(/\.json$/, ".decisions.json"), receipt);
  return receipt;
}

// Reopening is read-only: counts are a preview, never approval of retained files.
export async function resumeBlinkReview(reviewPath, checksum) {
  const ctx = await context(reviewPath, checksum);
  const draft = await optionalJson(reviewPath + ".draft.json");
  if (!draft) return { state: "NONE" };
  if (draft.reviewChecksum !== checksum) throw new Error("Saved Blink review differs from this measured run");
  if (draft.finalDecisionPath) {
    await readQualityDecisions(draft.finalDecisionPath, ctx.review, checksum);
    return { state: "COMPLETED", decisionPath: draft.finalDecisionPath };
  }
  const filter = draft.blinkResume?.filter ?? draft.blinkFilter;
  if (!filter) return { state: "NONE" };
  const manifestPath = resolve(ctx.root, sha(filter).slice(0, 16) + ".json");
  if (!await optionalJson(manifestPath)) {
    if (draft.blinkResume) throw new Error("Saved Blink review set is missing");
    return { state: "NONE" };
  }
  const preview = await inspectBlinkCopies(reviewPath, checksum, filter);
  if (draft.blinkResume && (draft.blinkResume.manifestPath !== preview.manifestPath ||
      draft.blinkResume.manifestChecksum !== preview.manifestChecksum))
    throw new Error("Saved Blink set changed; reopen and inspect the intended group before continuing");
  return { ...preview, state: "AWAITING_BLINK", measurementAccepted: filter === "FLAGGED" ?
    ctx.review.frames.filter(frame => frame.needsDecision && !frame.flags.length &&
      !(draft.decisions ?? []).some(item => item.sourceChecksum === frame.sourceChecksum)).length : 0 };
}

export async function completeBlinkReview(reviewPath, checksum, operator, note, confirmed) {
  if (!confirmed || typeof operator !== "string" || !operator.trim())
    throw new Error("Apply Blink choices requires an operator and confirmation");
  const ctx = await context(reviewPath, checksum);
  const preview = await resumeBlinkReview(reviewPath, checksum);
  if (preview.state === "COMPLETED") return preview;
  if (preview.state !== "AWAITING_BLINK") throw new Error("No saved Blink review to finish");
  const draft = await optionalJson(reviewPath + ".draft.json");
  const pending = ctx.review.frames.filter(frame => frame.needsDecision);
  const decisions = new Map((draft.decisions ?? []).map(item => [item.sourceChecksum, item]));
  for (const item of preview.decisions) decisions.set(item.sourceChecksum,
    { ...item, rationale: item.rationale + (note?.trim() ? " " + note.trim() : " Applied by operator after Blink review.") });
  if (preview.filter === "FLAGGED")
    for (const frame of pending)
      if (!frame.flags.length && !decisions.has(frame.sourceChecksum))
        decisions.set(frame.sourceChecksum, { sourceChecksum: frame.sourceChecksum, classification: "ACCEPT",
          rationale: "Accepted by operator using measured quality checks: no FWHM, eccentricity, SNR, noise, star-count or PSF availability flags." });
  const remaining = pending.filter(frame => !decisions.has(frame.sourceChecksum));
  if (remaining.length) throw new Error(remaining.length + " frames still need decisions. Review all pending frames or the flagged group to finish in one step.");
  const decision = { version: 1, kind: "one-run-quality-decisions", fingerprint: ctx.review.fingerprint,
    reviewChecksum: checksum, operator, decisions: pending.map(frame => decisions.get(frame.sourceChecksum)) };
  return saveCompletedReview(ctx, decision, { ...draft, blinkResume: { filter: preview.filter,
    manifestPath: preview.manifestPath, manifestChecksum: preview.manifestChecksum, state: "COMPLETED" } });
}

export async function acceptQualityRecommendations(reviewPath, checksum, operator, confirmed) {
  if (!confirmed || typeof operator !== "string" || !operator.trim())
    throw new Error("Accept recommendations requires an operator and confirmation");
  const ctx = await context(reviewPath, checksum);
  const preview = await resumeBlinkReview(reviewPath, checksum);
  if (preview.state === "COMPLETED") return preview;
  const draft = await optionalJson(ctx.reviewPath + ".draft.json") ?? {};
  const decisions = new Map((draft.decisions ?? []).map(item => [item.sourceChecksum, item]));
  // Retaining an unopened Blink copy is not a manual acceptance. Only carry
  // over exclusions; measured recommendations decide the remaining copies.
  for (const item of preview.decisions ?? [])
    if (item.classification === "REJECT") decisions.set(item.sourceChecksum, item);
  const pending = ctx.review.frames.filter(frame => frame.needsDecision);
  for (const frame of pending) {
    if (decisions.has(frame.sourceChecksum)) continue;
    const outliers = frame.flags.filter(flag => flag !== "PSF_SIGNAL_WEIGHT_UNAVAILABLE");
    decisions.set(frame.sourceChecksum, { sourceChecksum: frame.sourceChecksum,
      classification: outliers.length ? "REJECT" : "ACCEPT",
      rationale: outliers.length ? "Excluded by operator accepting measured quality recommendations: " + outliers.join(", ") + "." :
        "Accepted by operator using measured quality recommendations: no quality outliers." +
        (frame.flags.length ? " PSF weight unavailable; other measurements passed." : "") });
  }
  const decision = { version: 1, kind: "one-run-quality-decisions", fingerprint: ctx.review.fingerprint,
    reviewChecksum: checksum, operator, decisionMode: "MEASURED_RECOMMENDATIONS",
    decisions: pending.map(frame => decisions.get(frame.sourceChecksum)) };
  return saveCompletedReview(ctx, decision, draft);
}

async function saveCompletedReview(ctx, decision, draft) {
  const accepted = acceptedQualityChecksums(ctx.review, decision);
  const groups = new Map();
  for (const frame of ctx.review.frames) {
    const key = frame.filter + " " + frame.exposureSeconds + "s";
    groups.set(key, (groups.get(key) ?? 0) + Number(accepted.has(frame.sourceChecksum)));
  }
  const insufficient = [...groups].filter(([, count]) => count < 3);
  if (insufficient.length) throw new Error("At least 3 accepted frames per filter/exposure are needed: " + insufficient.map(([key, count]) => key + ": " + count).join("; "));
  const decisionPath = ctx.reviewPath.replace(/\.quality-review\.json$/, ".quality-decisions-" + randomUUID() + ".json");
  await atomicJson(decisionPath, decision);
  try { await readQualityDecisions(decisionPath, ctx.review, ctx.checksum); }
  catch (error) { await unlink(decisionPath); throw error; }
  await atomicJson(ctx.reviewPath + ".draft.json", { ...draft, reviewChecksum: ctx.checksum,
    decisions: decision.decisions, finalDecisionPath: decisionPath });
  return { state: "COMPLETED", decisionPath, accepted: accepted.size,
    rejected: decision.decisions.filter(item => item.classification === "REJECT").length };
}

export async function cleanupBlinkReviews(reviewPath, checksum) {
  const ctx = await context(reviewPath, checksum);
  const { readdir } = await import("node:fs/promises");
  let entries;
  try { entries = await readdir(ctx.root); }
  catch (error) { if (error.code === "ENOENT") return; throw error; }
  for (const name of entries.filter(n => /^[a-f0-9]{16}\.json$/.test(n))) {
    const set = await validateSet(ctx, resolve(ctx.root, name), undefined, true);
    if (set.missingDirectory) continue;
    for (const frame of set.frames) {
      try { const info = await lstat(frame.copyPath); if (info.isSymbolicLink()) throw new Error("Unexpected Blink copy link"); await unlink(frame.copyPath); }
      catch (error) { if (error.code !== "ENOENT") throw error; }
    }
    // Blink's move action keeps rejected copies here. Remove only recognised,
    // unchanged review files; preserve any unrelated files the user added.
    const rejected = resolve(set.directory, "Rejected");
    try {
      const info = await lstat(rejected);
      if (!info.isDirectory() || info.isSymbolicLink()) throw new Error("Unexpected Blink rejection folder");
      for (const frame of set.frames) {
        const path = resolve(rejected, basename(frame.copyPath));
        try {
          const file = await lstat(path);
          if (!file.isFile() || file.isSymbolicLink()) throw new Error("Unexpected rejected Blink copy");
          await verifyChecksum(path, frame.calibratedChecksum);
          await unlink(path);
        } catch (error) { if (error.code !== "ENOENT") throw error; }
      }
    } catch (error) { if (error.code !== "ENOENT") throw error; }
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try {
    const [action, reviewPath, checksum, filter, note, confirmed, operator] = process.argv.slice(2);
    const result = action === "prepare" ? await prepareBlinkReview(reviewPath, checksum, filter) :
      action === "import" ? await importBlinkDecisions(reviewPath, checksum, filter, note, confirmed === "true") :
      action === "resume" ? await resumeBlinkReview(reviewPath, checksum) :
      action === "recommend" ? await acceptQualityRecommendations(reviewPath, checksum, operator, confirmed === "true") :
      action === "complete" ? await completeBlinkReview(reviewPath, checksum, operator, note, confirmed === "true") : null;
    if (!result) throw new Error("Unknown Blink review action");
    console.log(JSON.stringify(result));
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
