import { ONE_RUN_ADAPTER } from "@piproc/shared";
import { createHash } from "node:crypto";
import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export const projectRoot = resolve(
  dirname(fileURLToPath(import.meta.url)),
  "../..",
);
export const defaultProfile = resolve(projectRoot, "profiles/generate-masters-template.json");
export const slug = (value) => String(value).replace(/[^a-z0-9]+/gi, "");
export const sha = (value) => createHash("sha256").update(value).digest("hex");
export const stageAdapter = ONE_RUN_ADAPTER;
