import { randomUUID } from "node:crypto";
import { constants } from "node:fs";
import { copyFile, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { basename, dirname, extname, join, resolve } from "node:path";
import {
  canonicalJson,
  fileChecksum,
  publishImmutable,
  verifyChecksum,
} from "@piproc/shared";
import {
  lightExposures,
  lightExposure,
  exposureGroups,
  groupKey,
  configuredExposures,
} from "./profile.mjs";
import { stageAdapter, slug, sha } from "./constants.mjs";
import { calibrationAcquisition, lightAcquisition } from "./identity.mjs";
import { cleanupBlinkReviews } from "./blink-review.mjs";

export async function* processInstances(root, relative = "") {
  const entries = (
    await readdir(resolve(root, relative), { withFileTypes: true })
  ).sort((a, b) => a.name.localeCompare(b.name));
  for (const entry of entries) {
    const next = join(relative, entry.name);
    if (entry.isDirectory()) yield* processInstances(root, next);
    else if (entry.isFile() && entry.name.endsWith(".js"))
      yield { path: resolve(root, next), name: next.replace(/\//g, "_") };
  }
}

// Job images use bridgePath; desktop receipts live in the journal's separate
// command queue. A succeeded stage from an older external bridge can still
// have its original receipt in the shared queue. Never search other runs.
export async function preparationReceipt(run, prepared) {
  if (prepared.status !== "SUCCEEDED" ||
      prepared.requestPath !== resolve(run.bridgePath, "jobs", prepared.id, "request.json"))
    throw new Error("Master preparation stage or request path is invalid");
  await verifyChecksum(prepared.requestPath, prepared.requestChecksum);
  const request = JSON.parse(await readFile(prepared.requestPath, "utf8"));
  const directories = [...new Set([run.receiptDirectory ?? resolve(run.bridgePath, "results"),
    resolve(run.bridgePath, "results")])];
  for (const directory of directories) {
    const path = resolve(directory, prepared.id + ".json");
    let text;
    try { text = await readFile(path, "utf8"); }
    catch (error) { if (error.code === "ENOENT") continue; throw error; }
    const receipt = JSON.parse(text);
    if (receipt.protocolVersion !== 1 || receipt.id !== prepared.id ||
        receipt.operation !== "one_run_stage" || receipt.status !== "succeeded" ||
        receipt.timestamps?.createdAt !== prepared.createdAt ||
        !Number.isFinite(Date.parse(receipt.timestamps?.completedAt)) ||
        request.adapter !== stageAdapter || request.stage !== "PREPARE_MASTERS" ||
        receipt.environment?.pixInsightVersion !== request.expectedVersion ||
        receipt.requestParameters?.adapter !== stageAdapter ||
        receipt.requestParameters?.jobId !== prepared.id ||
        receipt.requestParameters?.requestPath !== prepared.requestPath ||
        receipt.data?.adapter !== stageAdapter || receipt.data?.stage !== "PREPARE_MASTERS" ||
        canonicalJson(receipt.data?.outputs ?? null) !== canonicalJson(prepared.outputs.map(item => item.path)) ||
        canonicalJson(receipt.data?.masters ?? null) !== canonicalJson(prepared.masters))
      throw new Error("Master preparation receipt does not match the verified stage: " + path);
    return { path, checksum: sha(text), receipt };
  }
  throw new Error("Master preparation receipt is missing from this run's desktop and legacy queues; preserve staged masters and restore the original receipt for " + prepared.id);
}

export async function publish(
  run,
  journal,
  profile,
  selected,
  calibrationMasters,
  raw,
  outputRoot,
) {
  const filters = run.filters;
  const prepared = journal.stages.PREPARE_MASTERS;
  // Validate provenance before copying any publication files, including when
  // resuming an older run whose image stages already succeeded.
  const preparedReceipt = prepared && raw ? await preparationReceipt(run, prepared) : null;
  const finalDir = resolve(
    outputRoot,
    `${slug(run.target)}-${run.fingerprint.slice(0, 12)}`,
  );
  const masterPaths = {};
  const integrationResults = {};
  const entries = [];
  const masterReviewPublishedPath = resolve(finalDir, "provenance",
    "master-review.json");
  const masterAcceptancePublishedPath = resolve(finalDir, "provenance",
    "master-acceptance.json");
  await publishImmutable(run.masterReviewPath, masterReviewPublishedPath,
    run.masterReviewChecksum);
  await publishImmutable(run.masterAcceptancePath,
    masterAcceptancePublishedPath, run.masterAcceptanceChecksum);
  entries.push({ filter: null, role: "MASTER_REVIEW",
    path: masterReviewPublishedPath, checksum: run.masterReviewChecksum },
  { filter: null, role: "MASTER_ACCEPTANCE",
    path: masterAcceptancePublishedPath, checksum: run.masterAcceptanceChecksum });
  const qualityReviewPublishedPath = resolve(finalDir, "provenance",
    "quality-review.json");
  await publishImmutable(run.qualityReviewPath, qualityReviewPublishedPath,
    run.qualityReviewChecksum);
  entries.push({ filter: null, role: "QUALITY_REVIEW",
    path: qualityReviewPublishedPath, checksum: run.qualityReviewChecksum });
  let qualityDecisionPublishedPath = null;
  if (run.qualityDecisionPath) {
    qualityDecisionPublishedPath = resolve(finalDir, "provenance",
      "quality-decisions.json");
    await publishImmutable(run.qualityDecisionPath, qualityDecisionPublishedPath,
      run.qualityDecisionChecksum);
    entries.push({ filter: null, role: "QUALITY_DECISIONS",
      path: qualityDecisionPublishedPath, checksum: run.qualityDecisionChecksum });
  }
  const publishedCalibration = new Map();
  for (const { filter, exposureSeconds } of exposureGroups(profile)) {
    const grouped = lightExposures(profile, filter).length > 1;
    const key = "INTEGRATE_" + groupKey(profile, filter, exposureSeconds);
    const stageEntry = journal.stages[key];
    if (stageEntry?.status !== "SUCCEEDED") throw new Error("Missing " + key);
    const group = groupKey(profile, filter, exposureSeconds);
    const normalized = journal.stages["NORMALIZE_" + group];
    const normalizationData = [];
    if (profile.integration.normalization === "LOCAL_NORMALIZATION") {
      if (normalized?.status !== "SUCCEEDED" ||
          normalized.outputs.length !== run.integrationStacks[group]?.length)
        throw new Error("Missing verified LocalNormalization data for " + group);
      for (let index = 0; index < normalized.outputs.length; ++index) {
        const item = normalized.outputs[index];
        const path = resolve(finalDir, "provenance", "normalization",
          `${group}-${String(index).padStart(4, "0")}.xnml`);
        await publishImmutable(item.path, path, item.checksum);
        entries.push({ filter, exposureSeconds, role: "LOCAL_NORMALIZATION_DATA",
          path, checksum: item.checksum });
        normalizationData.push({ path, checksum: item.checksum,
          sourceChecksum: run.integrationStacks[group][index].checksum });
      }
    }
    integrationResults[group] = { filter, exposureSeconds,
      policy: profile.integration, sourceFrames: run.integrationStacks[group],
      normalizationData, statistics: stageEntry.statistics };
    const byName = Object.fromEntries(
      stageEntry.outputs.map((item) => [basename(item.path), item]),
    );
    const names = [
      [
        "master.xisf",
        `${slug(run.target)}_${filter}${grouped ? `_${exposureSeconds}s` : ""}_master.xisf`,
      ],
      [
        "rejection-low.xisf",
        `${slug(run.target)}_${filter}${grouped ? `_${exposureSeconds}s` : ""}_rejection_low.xisf`,
      ],
      [
        "rejection-high.xisf",
        `${slug(run.target)}_${filter}${grouped ? `_${exposureSeconds}s` : ""}_rejection_high.xisf`,
      ],
    ];
    for (const [sourceName, outputName] of names) {
      const source = byName[sourceName];
      if (!source) throw new Error("Missing integrated output " + sourceName);
      const path = resolve(finalDir, outputName);
      await publishImmutable(source.path, path, source.checksum);
      entries.push({
        filter,
        exposureSeconds,
        role: run.drizzle && sourceName === "master.xisf" ? "conventional-master.xisf" : sourceName,
        path,
        checksum: source.checksum,
      });
      if (sourceName === "master.xisf")
        masterPaths[grouped ? `${filter}_${exposureSeconds}s` : filter] = path;
    }
    if (run.drizzle) {
      const drizzled = journal.stages["DRIZZLE_" + group];
      if (drizzled?.status !== "SUCCEEDED") throw new Error("Missing verified drizzle integration for " + group);
      const known = Object.fromEntries(drizzled.outputs.map(item => [basename(item.path), item]));
      for (const [name, role, suffix] of [["drizzle-master.xisf", "master.xisf", "master"],
        ["drizzle-weight.xisf", "drizzle-weight.xisf", "weight"]]) {
        const source = known[name];
        if (!source) throw new Error("Missing " + name);
        const path = resolve(finalDir, `${slug(run.target)}_${group}_drizzle_2x_${suffix}.xisf`);
        await publishImmutable(source.path, path, source.checksum);
        entries.push({ filter, exposureSeconds, role, path, checksum: source.checksum, scale: 2 });
        if (role === "master.xisf") masterPaths[group] = path;
      }
      integrationResults[group].drizzle = { ...run.drizzle, statistics: drizzled.statistics,
        data: stageEntry.drizzleData.map((item, index) => ({ checksum: item.checksum,
          sourceFrameChecksum: run.integrationStacks[group][index].checksum, phase: item.phase })) };
    }
  }
  if (prepared) {
    const known = new Map(prepared.outputs.map((item) => [item.path, item]));
    for (const master of Object.values(raw?.savedDarks ?? {})) {
      known.set(master.nativePath, { path: master.nativePath, checksum: master.nativeChecksum });
      for (const map of Object.values(master.rejectionMaps ?? {})) known.set(map.path, map);
    }
    const darks = Object.entries({ ...Object.fromEntries(
      Object.entries(raw?.savedDarks ?? {}).map(([exposure, master]) => [exposure, master.nativePath])),
    ...prepared.masters.darks });
    const definitions = [
      ...darks.map(([exposure, path]) => [
        "dark",
        darks.length === 1 ? "" : `${exposure}s`,
        path,
        raw?.savedDarks?.[exposure],
      ]),
      ...filters.map((filter) => [
        "darkflat",
        filter,
        prepared.masters.darkFlats[filter],
      ]),
      ...filters.map((filter) => [
        "flat",
        filter,
        prepared.masters.flats[filter],
      ]),
    ];
    for (const [kind, filter, nativePath, savedDark] of definitions) {
      const imageFiles = [[nativePath, savedDark ? extname(nativePath).toLowerCase() : ".xisf"]];
      for (const [map, suffix] of [["low", "_rejection_low.xisf"], ["high", "_rejection_high.xisf"]]) {
        if (!savedDark || savedDark.rejectionMaps?.[map])
          imageFiles.push([savedDark?.rejectionMaps?.[map]?.path ?? resolve(dirname(nativePath), `rejection-${map}.xisf`), suffix]);
      }
      for (const [sourcePath, extension] of imageFiles) {
        const source = known.get(sourcePath);
        if (!source)
          throw new Error("Prepared calibration master missing: " + sourcePath);
        const name = `${slug(run.target)}_${kind}${filter ? "_" + filter : ""}_master${extension}`;
        const path = resolve(finalDir, "calibration", name);
        await publishImmutable(source.path, path, source.checksum);
        const mapRole =
          extension === "_rejection_low.xisf"
            ? "_REJECTION_LOW"
            : extension === "_rejection_high.xisf"
              ? "_REJECTION_HIGH"
              : "";
        entries.push({
          filter,
          role: `CALIBRATION_${kind.toUpperCase()}${mapRole}`,
          path,
          checksum: source.checksum,
        });
        if (!mapRole)
          publishedCalibration.set(`${kind}:${filter}`, {
            path,
            checksum: source.checksum,
          });
      }
    }
  }
  for (const [stageName, stageEntry] of Object.entries(journal.stages)) {
    if (stageEntry.status !== "SUCCEEDED") continue;
    const base = resolve(run.bridgePath, "jobs", stageEntry.id);
    const marker = await readFile(resolve(base, "one-run.marker"), "utf8");
    if (marker.trim() !== run.fingerprint)
      throw new Error("Process-instance staging marker mismatch: " + base);
    for await (const instance of processInstances(resolve(base, "output"))) {
      const checksum = await fileChecksum(instance.path);
      const path = resolve(
        finalDir,
        "provenance",
        `${stageName}_${instance.name}`,
      );
      await publishImmutable(instance.path, path, checksum);
      entries.push({
        filter: null,
        role: "PROCESS_INSTANCE",
        stage: stageName,
        path,
        checksum,
      });
    }
  }
  let reusableProfile = null;
  let reusableProfilePath = null;
  if (prepared && raw) {
    const requestPath = resolve(
      finalDir,
      "provenance",
      "PREPARE_MASTERS_request.json",
    );
    const receiptPath = resolve(
      finalDir,
      "provenance",
      "PREPARE_MASTERS_receipt.json",
    );
    const { path: receiptSource, checksum: receiptChecksum, receipt } = preparedReceipt;
    const requestChecksum = await fileChecksum(prepared.requestPath);
    await publishImmutable(prepared.requestPath, requestPath, requestChecksum);
    await publishImmutable(receiptSource, receiptPath, receiptChecksum);
    entries.push({
      filter: null,
      role: "PREPARATION_REQUEST",
      path: requestPath,
      checksum: requestChecksum,
    });
    entries.push({
      filter: null,
      role: "PREPARATION_RECEIPT",
      path: receiptPath,
      checksum: receiptChecksum,
    });
    const preparedAt = receipt.timestamps?.completedAt;
    if (!preparedAt)
      throw new Error("Master preparation receipt has no completion time");
    const makeRegistration = (
      kind,
      filter,
      output,
      inputChecksums,
      parentMasters = [],
      acquisition,
    ) => {
      if (!output || !inputChecksums.length)
        throw new Error(
          "Incomplete published calibration lineage: " + kind + " " + filter,
        );
      const registrationId = sha(
        canonicalJson({
          kind,
          filter,
          checksum: output.checksum,
          opticalTrainId: profile.opticalTrainId,
          preparationFingerprint: run.fingerprint,
        }),
      );
      return {
        path: output.path,
        checksum: output.checksum,
        registrationId,
        opticalTrainId: profile.opticalTrainId,
        acquisition,
        preparation: {
          method: kind === "FLAT" ? "DARKFLAT_CORRECTED" : "INTEGRATED_RAW",
          inputChecksums,
          tool: "GenerateMasters PixInsight ImageIntegration + ImageCalibration",
          toolVersion: run.pixInsightVersion,
          preparedAt,
          operator: profile.operator,
          preparationFingerprint: run.fingerprint,
          profileRequestPath: requestPath,
          profileRequestChecksum: requestChecksum,
          profileReceiptPath: receiptPath,
          profileReceiptChecksum: receiptChecksum,
          parentMasters,
          ...(raw.groups.filters[filter]?.darkFlatExposureApproval
            ? { darkFlatExposureApproval: raw.groups.filters[filter].darkFlatExposureApproval }
            : {}),
        },
        nativePath: output.path,
        nativeChecksum: output.checksum,
      };
    };
    const outputFor = (kind, filter) =>
      publishedCalibration.get(`${kind}:${filter}`);
    const darkExposures = [...Object.keys(raw.groups.masterDarks), ...Object.keys(raw.savedDarks ?? {})];
    const darkByExposure = Object.fromEntries(
      await Promise.all(darkExposures.map(async (exposure) => {
        const name = darkExposures.length === 1 ? "" : `${exposure}s`;
        const saved = raw.savedDarks?.[exposure];
        if (saved) {
          const output = outputFor("dark", name);
          const preparation = { ...saved.preparation };
          for (const kind of saved.preparation.method === "IMPORTED_MASTER" ? [] : ["profileRequest", "profileReceipt"]) {
            const path = resolve(finalDir, "provenance", `MasterDark_${exposure}s_${kind}.json`);
            const checksum = preparation[kind + "Checksum"];
            await publishImmutable(preparation[kind + "Path"], path, checksum);
            preparation[kind + "Path"] = path;
            entries.push({ filter: null, role: "SAVED_DARK_" + kind.toUpperCase(), path, checksum });
          }
          return [exposure, { ...saved, ...output, nativePath: output.path,
            nativeChecksum: output.checksum, preparation,
            rejectionMaps: Object.fromEntries(["low", "high"].filter(kind => saved.rejectionMaps?.[kind]).map((kind) => {
              const entry = entries.find((item) => item.filter === name &&
                item.role === "CALIBRATION_DARK_REJECTION_" + kind.toUpperCase());
              return [kind, { path: entry.path, checksum: entry.checksum }];
            })) }];
        }
        const indices = raw.groups.masterDarks[exposure];
        const checksums = indices.map(
          (index) => raw.all[index].checksum,
        );
        return [
          exposure,
          makeRegistration("DARK", name, outputFor("dark", name), checksums,
            [], calibrationAcquisition(indices.map((index) => raw.all[index].metadata), "DARK")),
        ];
      })),
    );
    const darkFlats = Object.fromEntries(
      filters.map((filter) => {
        const group = raw.groups.filters[filter];
        return [
          filter,
          makeRegistration(
            "DARKFLAT",
            filter,
            outputFor("darkflat", filter),
            group.darkFlats.map((index) => raw.all[index].checksum),
            [],
            calibrationAcquisition(group.darkFlats.map((index) => raw.all[index].metadata), "DARKFLAT"),
          ),
        ];
      }),
    );
    const flats = Object.fromEntries(
      filters.map((filter) => {
        const group = raw.groups.filters[filter];
        const parent = darkFlats[filter];
        return [
          filter,
          makeRegistration(
            "FLAT",
            filter,
            outputFor("flat", filter),
            group.flats.map((index) => raw.all[index].checksum),
            [
              {
                registrationId: parent.registrationId,
                checksum: parent.checksum,
                kind: "DARKFLAT",
                opticalTrainId: profile.opticalTrainId,
              },
            ],
            calibrationAcquisition(group.flats.map((index) => raw.all[index].metadata), "FLAT"),
          ),
        ];
      }),
    );
    const darks = Object.fromEntries(
      filters.map((filter) => [
        filter,
        darkByExposure[String(lightExposure(profile, filter))],
      ]),
    );
    const lightSettings = lightAcquisition(selected, profile);
    reusableProfile = {
      ...profile,
      name: `${profile.name ?? run.target} prepared ${run.fingerprint.slice(0, 12)}`,
      equipment: { ...profile.equipment, gain: lightSettings.gain,
        offset: lightSettings.offset,
        temperatureToleranceC: profile.equipment.temperatureToleranceC ?? 2 },
      target: run.target,
      filters,
      referenceFilter: run.referenceFilter,
      referenceChecksum: run.referenceChecksum,
      sourceRoot: run.source,
      calibrationSourceRoot: run.calibrationSource || null,
      defaultOutput: outputRoot,
      lightExposureSeconds: configuredExposures(profile),
      flatExposureSeconds: Object.fromEntries(
        filters.map((filter) => [
          filter,
          raw.groups.filters[filter].exposureSeconds,
        ]),
      ),
      masters: {
        dark:
          darkExposures.length === 1
            ? darkByExposure[darkExposures[0]]
            : undefined,
        darks,
        darkByExposure,
        flats,
        darkFlats,
      },
      knownCalibrationChecksums: [
        ...new Set([
          ...(profile.knownCalibrationChecksums ?? []),
          ...raw.selected.map((item) => item.checksum),
        ]),
      ],
    };
    reusableProfilePath = resolve(finalDir, "reusable-profile.json");
    const profileText = JSON.stringify(reusableProfile, null, 2) + "\n";
    const profileTemp = resolve(finalDir, ".profile-" + randomUUID() + ".json");
    try {
      await writeFile(profileTemp, profileText, { flag: "wx", mode: 0o600 });
      await publishImmutable(
        profileTemp,
        reusableProfilePath,
        sha(profileText),
      );
    } finally {
      await rm(profileTemp, { force: true });
    }
    entries.push({
      filter: null,
      role: "REUSABLE_PROFILE",
      path: reusableProfilePath,
      checksum: sha(profileText),
    });
  }
  const manifest = {
    version: 1,
    target: run.target,
    fingerprint: run.fingerprint,
    createdAt: journal.createdAt,
    adapter: stageAdapter,
    pixInsightVersion: run.pixInsightVersion,
    profile: run.profilePath,
    profileChecksum: run.profileChecksum,
    sourceRoot: run.source,
    calibrationSourceRoot: run.calibrationSource || null,
    opticalTrainId: profile.opticalTrainId,
    filters,
    lightExposureSeconds: configuredExposures(profile),
    flatExposureSeconds: raw
      ? Object.fromEntries(
          filters.map((filter) => [
            filter,
            raw.groups.filters[filter].exposureSeconds,
          ]),
        )
      : profile.flatExposureSeconds,
    operatorDecisions: run.operatorDecisions,
    selectedSourceFrames: selected.map(
      ({ path, checksum, filter, exposureSeconds, gain, offset, sensorTemperature }) => ({
        path,
        checksum,
        filter,
        exposureSeconds,
        gain: gain ?? null,
        offset: offset ?? null,
        sensorTemperature: sensorTemperature ?? null,
      }),
    ),
    integratedSourceFrames: run.integratedSources,
    calibrationMasters: reusableProfile?.masters ?? calibrationMasters,
    reusableProfilePath,
    rawCalibrationSources:
      raw?.selected.map(({ path, checksum, metadata }) => ({ path, checksum,
        gain: metadata.gain ?? null, offset: metadata.offset ?? null,
        sensorTemperature: metadata.sensorTemperature ?? null })) ?? [],
    rawCalibrationGroups: raw
      ? {
          savedDarks: raw.savedDarks ?? {},
          masterDarks: Object.fromEntries(
            Object.entries(raw.groups.masterDarks).map(
              ([exposure, indices]) => [
                exposure,
                indices.map((index) => ({
                  path: raw.all[index].path,
                  checksum: raw.all[index].checksum,
                })),
              ],
            ),
          ),
          filters: Object.fromEntries(
            filters.map((filter) => {
              const group = raw.groups.filters[filter];
              const files = (indices) =>
                indices.map((index) => ({
                  path: raw.all[index].path,
                  checksum: raw.all[index].checksum,
                }));
              return [
                filter,
                {
                  exposureSeconds: group.exposureSeconds,
                  darkFlatExposureSeconds: group.darkFlatExposureSeconds,
                  darkFlatExposureApproval: group.darkFlatExposureApproval ?? null,
                  flats: files(group.flats),
                  darkFlats: files(group.darkFlats),
                },
              ];
            }),
          ),
        }
      : null,
    masterPreparationRecipe: raw
      ? {
          darkScaling: false,
          flatCorrection: Object.values(raw.groups.filters).some((group) => group.darkFlatExposureApproval)
            ? "EXPLICITLY_APPROVED_DARKFLAT_EXPOSURE"
            : "EXACT_EXPOSURE_DARKFLAT",
          integration: "AVERAGE_EQUAL_WEIGHT_WINSORIZED_SIGMA_4_3",
          flatNormalization: "MULTIPLICATIVE",
          flatRejectionNormalization: "EQUALIZE_FLUXES",
        }
      : null,
    referenceChecksum: run.referenceChecksum,
    referenceSelection: run.referenceSelection,
    registrationReview: run.registrationReview,
    masterReview: { path: masterReviewPublishedPath,
      checksum: run.masterReviewChecksum },
    masterAcceptance: { path: masterAcceptancePublishedPath,
      checksum: run.masterAcceptanceChecksum,
      operator: run.masterAcceptance.operator,
      rationale: run.masterAcceptance.rationale },
    integration: profile.integration,
    integrationResults,
    drizzle: run.drizzle ?? null,
    drizzleRecommendations: run.drizzleRecommendations ?? [],
    failedRegistrations: run.failedRegistrations,
    frameMeasurements: run.frameMeasurements,
    qualityMeasurementSkipped: run.qualityMeasurementSkipped,
    qualityReview: { path: qualityReviewPublishedPath,
      checksum: run.qualityReviewChecksum },
    qualityDecisions: qualityDecisionPublishedPath ? {
      path: qualityDecisionPublishedPath,
      checksum: run.qualityDecisionChecksum } : null,
    files: entries,
  };
  const manifestPath = resolve(finalDir, "manifest.json");
  const manifestText = JSON.stringify(manifest, null, 2) + "\n";
  const manifestTemp = resolve(finalDir, ".manifest-" + randomUUID() + ".json");
  try {
    await writeFile(manifestTemp, manifestText, { flag: "wx", mode: 0o600 });
    await publishImmutable(manifestTemp, manifestPath, sha(manifestText));
  } finally {
    await rm(manifestTemp, { force: true });
  }
  return {
    finalDir,
    manifestPath,
    reusableProfilePath,
    manifestChecksum: await fileChecksum(manifestPath),
    masterPaths,
    files: entries,
  };
}

export async function cleanup(journal, config, fingerprint) {
  if (journal.qualityReviewPath && journal.qualityReviewChecksum)
    await cleanupBlinkReviews(journal.qualityReviewPath, journal.qualityReviewChecksum);
  for (const id of journal.attempts) {
    const base = resolve(config.bridge.path, "jobs", id);
    let marker;
    try {
      marker = await readFile(resolve(base, "one-run.marker"), "utf8");
    } catch (error) {
      if (error.code === "ENOENT") continue;
      throw error;
    }
    if (marker.trim() !== fingerprint)
      throw new Error("Staging marker mismatch: " + base);
    await rm(base, { recursive: true });
  }
  journal.cleanedAt = new Date().toISOString();
}

export async function trimPreparationStaging(prepared, config, fingerprint) {
  if (prepared.status !== "SUCCEEDED") return;
  const base = resolve(config.bridge.path, "jobs", prepared.id);
  const marker = await readFile(resolve(base, "one-run.marker"), "utf8");
  if (marker.trim() !== fingerprint)
    throw new Error("Master staging marker mismatch");
  for (const item of prepared.outputs)
    await verifyChecksum(item.path, item.checksum);
  const filters = Object.keys(prepared.masters.flats);
  for (const filter of filters) {
    const dir = resolve(
      base,
      "output",
      `flat-${filter.toLowerCase()}`,
      "calibrated",
    );
    const instance = resolve(dir, "ImageCalibration.js");
    try {
      await copyFile(
        instance,
        resolve(
          base,
          "output",
          `flat-${filter.toLowerCase()}`,
          "FlatImageCalibration.js",
        ),
        constants.COPYFILE_EXCL,
      );
    } catch (error) {
      if (error.code !== "EEXIST" && error.code !== "ENOENT") throw error;
    }
    await rm(dir, { recursive: true, force: true });
  }
  for (const name of [
    ...Object.values(prepared.masters.darks).map((path) =>
      basename(dirname(path)),
    ),
    ...filters.flatMap((filter) => [
      `darkflat-${filter.toLowerCase()}`,
      `flat-${filter.toLowerCase()}`,
    ]),
  ]) {
    await rm(resolve(base, "output", name, "master.xisf"), { force: true });
  }
}
