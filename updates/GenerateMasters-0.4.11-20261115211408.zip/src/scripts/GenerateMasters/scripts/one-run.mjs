#!/usr/bin/env node
import { assertSupportedNodeVersion } from "./one-run/node-version.mjs";
import { eventReporter } from "./one-run/protocol.mjs";
import { constants, existsSync } from "node:fs";
import { access, readFile } from "node:fs/promises";
import { basename, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { userInfo } from "node:os";
import { loadConfig } from "@piproc/config";
import { RealPixInsightClient } from "@piproc/pixinsight-client";
import {
  assertOutputRoot,
  canonicalJson,
  fileChecksum,
  verifyChecksum,
} from "@piproc/shared";
import {
  defaultFilters,
  filtersFor,
  exposureGroups,
  groupKey,
  configuredExposures,
  darkFor,
  parseArguments,
  parseExposures,
  parseOptionalExposures,
  validateProfile,
} from "./one-run/profile.mjs";
import {
  inventory,
  scanSource,
  inventoryRawCalibration,
  verifySources,
  verifySavedMasterProvenance,
} from "./one-run/inventory.mjs";
import { atomicJson, loadRecoverableJournal, acquireRunLock } from "./one-run/journal.mjs";
import { stage } from "./one-run/stage.mjs";
import {
  buildQualityReview,
  readQualityDecisions,
  acceptedQualityChecksums,
  savedQualityDecisionPath,
} from "./one-run/quality.mjs";
import {
  publish,
  cleanup,
  trimPreparationStaging,
} from "./one-run/publication.mjs";
import { ensureBridge } from "./one-run/bridge.mjs";
import { connectCurrentInstance } from "./one-run/current-instance.mjs";
import {
  askPath,
  askSetting,
  approveUnknown,
  approveNewCalibration,
  approveLegacyCalibration,
} from "./one-run/prompts.mjs";
import {
  stageAdapter,
  sha,
  projectRoot,
} from "./one-run/constants.mjs";
import { lightAcquisition, temperatureTolerance } from "./one-run/identity.mjs";
import { alignmentReview, selectMeasuredReference } from "./one-run/reference.mjs";
import { buildMasterReview, readMasterAcceptance, savedMasterAcceptancePath } from "./one-run/master-review.mjs";
import { storageMessages, storagePreflight } from "./one-run/storage.mjs";
import { loadDarkLibraries } from "./one-run/dark-library.mjs";
import { loadStandaloneDarks } from "./one-run/standalone-darks.mjs";
import { folderInputs } from "./one-run/folder-inputs.mjs";
import { drizzleSettings, drizzleRecommendation } from "./one-run/drizzle.mjs";
import { nativeCapabilityBlockers, probeNativePreflight } from "./one-run/native-preflight.mjs";

export {
  parseArguments,
  parseExposures,
  parseOptionalExposures,
  validateProfile,
  assertEquipment,
} from "./one-run/profile.mjs";
export { inventory, inventoryRawCalibration } from "./one-run/inventory.mjs";
export { readXisfExposure, verifyImage } from "./one-run/images.mjs";

export async function main(argv = process.argv.slice(2)) {
  assertSupportedNodeVersion();
  const options = parseArguments(argv);
  const drizzle = drizzleSettings(options.drizzle);
  const report = eventReporter(options.events);
  const automatic = Boolean(options["auto-calibration"] || !options.profile);
  report("info", { message: automatic ? "Detecting lights and calibration from folders" : "Validating profile and inputs" });
  const detected = automatic ? await folderInputs(options) : null;
  const profile = detected?.profile ?? JSON.parse(await readFile(resolve(options.profile), "utf8"));
  const detectedProfileText = automatic ? JSON.stringify(profile, null, 2) + "\n" : null;
  const profileChecksum = automatic ? sha(detectedProfileText) : await fileChecksum(resolve(options.profile));
  const profilePath = automatic
    ? resolve(detected.output, ".piproc-profiles", profileChecksum + ".json") : resolve(options.profile);
  if (automatic) {
    Object.assign(options, { source: detected.source, output: detected.output,
      target: profile.target, filters: profile.filters.join(","),
      exposures: profile.filters.map(filter => {
        const value = profile.lightExposureSeconds[filter];
        return filter + "=" + (Array.isArray(value) ? value.join("+") : value);
      }).join(","), "flat-exposures": "", "reference-filter": profile.referenceFilter,
      "optical-train": profile.opticalTrainId, operator: profile.operator,
      "rebuild-masters": true, "measure-unreviewed": true, "confirm-optical-train": true });
  }
  if (options["pixinsight-executable"])
    profile.pixInsightExecutable = resolve(options["pixinsight-executable"]);
  const profileFilters =
    profile.filters ?? Object.keys(profile.masters?.flats ?? {});
  const suggestedFilters = profileFilters.length
    ? profileFilters
    : defaultFilters;
  const chosenFilters =
    options.filters ??
    (await askSetting("Filters (comma separated)", suggestedFilters.join(",")));
  profile.filters = chosenFilters.split(",").map((f) => f.trim());
  const filters = filtersFor(profile);
  const suggestedExposures = filters
    .map((filter) => {
      const value =
        typeof profile.lightExposureSeconds === "number"
          ? profile.lightExposureSeconds
          : profile.lightExposureSeconds?.[filter];
      return `${filter}=${Array.isArray(value) ? value.join("+") : (value ?? "")}`;
    })
    .join(",");
  profile.lightExposureSeconds = parseExposures(
    options.exposures ??
      (await askSetting(
        "Light exposure seconds (filter=long+short)",
        suggestedExposures,
      )),
    filters,
  );
  const suggestedFlats = Object.entries(profile.flatExposureSeconds ?? {})
    .filter(([filter]) => filters.includes(filter))
    .map(([filter, seconds]) => `${filter}=${seconds}`)
    .join(",");
  profile.flatExposureSeconds = parseOptionalExposures(
    options["flat-exposures"] ??
      (await askSetting(
        "Flat exposures if ambiguous (optional)",
        suggestedFlats,
      )),
    filters,
  );
  const target = options.target ?? (await askSetting("Target", profile.target));
  const opticalTrainId =
    options["optical-train"] ??
    (await askSetting("Optical-train ID", profile.opticalTrainId));
  profile.opticalTrainId = opticalTrainId;
  profile.operator =
    options.operator ??
    (await askSetting("Operator", profile.operator ?? userInfo().username));
  let rebuildMasters = Boolean(options["rebuild-masters"]);
  if (!rebuildMasters && process.stdin.isTTY) {
    const mode = await askSetting(
      "Calibration masters (saved/rebuild)",
      profile.masters ? "saved" : "rebuild",
    );
    if (!["saved", "rebuild"].includes(mode.toLowerCase()))
      throw new Error("Choose saved or rebuild for calibration masters");
    rebuildMasters = mode.toLowerCase() === "rebuild";
  }
  validateProfile(profile, rebuildMasters);
  if (drizzle && profile.integration.normalization === "LOCAL_NORMALIZATION")
    throw new Error("2x drizzle currently requires additive normalization");
  const referenceFilter =
    options["reference-filter"] ??
    (await askSetting(
      "Registration reference filter",
      profile.referenceFilter ?? filters[0],
    ));
  if (!filters.includes(referenceFilter))
    throw new Error(
      "Registration reference filter must be one of the selected filters",
    );
  const source = await askPath(
    "Source FITS folder",
    options.source ?? profile.sourceRoot,
  );
  const output = await askPath(
    "Final masters folder",
    options.output ?? profile.defaultOutput,
  );
  const bundledConfig = [resolve(projectRoot, "config.yaml"), resolve(projectRoot, "packaging/config.yaml")]
    .find(path => existsSync(path));
  const configPath = options.config || profile.configPath ||
    bundledConfig || null;
  const config = !options["dry-run"] || configPath
    ? await loadConfig(configPath ?? undefined) : null;
  const bridgePath = config?.bridge.path ?? resolve(userInfo().homedir,
    ".pixinsight-processor/bridge");
  const calibrationRoot = options["calibration-source"] ?? profile.calibrationSourceRoot;
  const calibrationSource = rebuildMasters && calibrationRoot ? resolve(calibrationRoot) : null;
  await access(source, constants.R_OK);
  if (calibrationSource) await access(calibrationSource, constants.R_OK);
  const savedMasters = rebuildMasters
    ? []
    : [
        ...new Map(
          [
            ...exposureGroups(profile).map(({ filter, exposureSeconds }) =>
              darkFor(profile, filter, exposureSeconds),
            ),
            ...filters.map((f) => profile.masters.flats[f]),
          ].map((master) => [master.path, master]),
        ).values(),
      ];
  await assertOutputRoot(output, [source, ...(calibrationSource ? [calibrationSource] : [])]);
  report("stage", { stage: "Inventory" });
  const sourceIndex = detected?.sourceIndex ?? await scanSource(source);
  const { candidates, selected } = await inventory(source, target, profile,
    sourceIndex);
  const requestedReferenceChecksum = selected.find(
    (item) =>
      item.filter === referenceFilter &&
      item.checksum === profile.referenceChecksum,
  )?.checksum;
  const calibrationIndex = calibrationSource && calibrationSource !== source
    ? [...new Map([...sourceIndex, ...await scanSource(calibrationSource)]
      .map((entry) => [entry.path, entry])).values()] : sourceIndex;
  const savedDarks = rebuildMasters && !options["rebuild-dark-masters"]
    ? await (automatic ? loadStandaloneDarks : loadDarkLibraries)([source, ...(calibrationSource ? [calibrationSource] : [])], profile, selected, {
      paths: options["master-dark-files"] ?? profile.masterDarkFiles ?? [],
      confirmMissing: Boolean(options["confirm-calibration-identity"]),
      automatic,
    })
    : {};
  savedMasters.push(...Object.values(savedDarks));
  const raw = rebuildMasters
    ? await inventoryRawCalibration(source, profile, selected, calibrationIndex, savedDarks,
      { automatic, sourcePaths: new Set(sourceIndex.map(item => item.path)) })
    : null;
  await verifySources([...candidates, ...(raw?.selected ?? [])], savedMasters);
  const savedMasterWarnings = !raw
    ? await verifySavedMasterProvenance(
      savedMasters,
      {
        width: profile.equipment.width,
        height: profile.equipment.height,
      },
      profile,
      selected,
    )
    : [];
  let fingerprint = sha(
    canonicalJson({
      target,
      profileChecksum,
      filters,
      referenceFilter,
      opticalTrainId,
      operator: profile.operator,
      exposures: configuredExposures(profile),
      flatExposures: profile.flatExposureSeconds,
      selected: selected
        .map((item) => [item.path, item.checksum])
        .sort((a, b) => a[0].localeCompare(b[0])),
      masters: (raw ? [...raw.selected, ...savedMasters] : savedMasters)
        .map((item) => [item.path, item.checksum])
        .sort((a, b) => a[0].localeCompare(b[0])),
      darkLibraries: Object.values(savedDarks).map((master) => [master.libraryPath, master.libraryChecksum]).sort(),
      masterPreparation: Boolean(raw),
      integration: profile.integration,
      ...(drizzle ? { drizzle } : {}),
      referenceChecksum: requestedReferenceChecksum ?? null,
      adapter: stageAdapter,
    }),
  );
  const run = {
    source,
    calibrationSource,
    output,
    target,
    fingerprint,
    profilePath,
    profileChecksum,
    filters,
    referenceFilter,
    geometry: { width: selected[0].width, height: selected[0].height },
    drizzle,
    bridgePath: null,
    sourceChecksums: new Map(
      [...candidates, ...(raw?.all ?? [])].map((item) => [
        item.path,
        item.checksum,
      ]),
    ),
  };
  const counts = Object.fromEntries(
    filters.map((filter) => [
      filter,
      selected.filter((item) => item.filter === filter).length,
    ]),
  );
  const inventoryByFilter = exposureGroups(profile).map(
    ({ filter, exposureSeconds }) => {
      const lights = candidates.filter(
        (item) =>
          item.filter === filter && item.exposureSeconds === exposureSeconds,
      );
      const approved = lights.filter((item) => !item.excluded);
      const flatGroup = raw?.groups.filters[filter];
      return {
        filter,
        lightExposureSeconds: exposureSeconds,
        selectedLights: approved.length,
        excludedLights: lights.length - approved.length,
        unreviewedLights: approved.filter(
          (item) => !profile.knownApprovedChecksums?.includes(item.checksum),
        ).length,
        utcDates: [
          ...new Set(
            lights.map((item) => item.capturedAtUtc?.slice(0, 10) ?? "Unknown"),
          ),
        ].sort(),
        flatExposureSeconds:
          flatGroup?.exposureSeconds ??
          profile.flatExposureSeconds?.[filter] ??
          null,
        flatExposureSelection: flatGroup
          ? profile.flatExposureSeconds?.[filter]
            ? "selected"
            : "auto"
          : "saved",
        flats: flatGroup?.flats.length ?? null,
        darkFlats: flatGroup?.darkFlats.length ?? null,
        darkFlatExposureSeconds: flatGroup?.darkFlatExposureSeconds ?? null,
        darkFlatExposureApproval: flatGroup?.darkFlatExposureApproval ?? null,
        lightDarks:
          savedDarks[String(exposureSeconds)] ? null : raw?.groups.masterDarks[String(exposureSeconds)]?.length ?? null,
        savedDarkPath: savedDarks[String(exposureSeconds)]?.nativePath ?? null,
      };
    },
  );
  const minimumWorkingBytes =
    selected.length * selected[0].width * selected[0].height * 4 * 2;
  const storage = await storagePreflight(source, output, bridgePath,
    selected, raw, profile, drizzle);
  const summary = {
    drizzle: { enabled: Boolean(drizzle), settings: drizzle,
      recommendations: drizzleRecommendation(profile, selected) },
    status: "READY",
    target,
    source,
    calibrationSource,
    output,
    fingerprint,
    filters,
    referenceFilter,
    opticalTrainId,
    operator: profile.operator,
    selected: counts,
    excludedKnownFrames: candidates.length - selected.length,
    inventoryByFilter,
    minimumWorkingBytes,
    storage,
    unknownQualityFrames: selected.filter(
      (item) => !profile.knownApprovedChecksums?.includes(item.checksum),
    ).length,
    usingPreparedMasters: !raw,
    savedMasterDarks: Object.values(savedDarks).map((master) => master.nativePath),
    rawCalibrationFrames: raw?.selected.length ?? 0,
    flatExposureSeconds: raw
      ? Object.fromEntries(
          filters.map((filter) => [
            filter,
            raw.groups.filters[filter].exposureSeconds,
          ]),
        )
      : null,
    newCalibrationFrames:
      raw?.selected.filter(
        (item) => !profile.knownCalibrationChecksums?.includes(item.checksum),
      ).length ?? 0,
    recipe: profile.integration,
    acquisition: {
      settings: lightAcquisition(selected, profile),
      temperatureToleranceC: temperatureTolerance(profile),
      measuredLightTemperatureRangeC: selected.every((item) =>
        Number.isFinite(item.sensorTemperature))
        ? selected.reduce((range, item) => [
            Math.min(range[0], item.sensorTemperature),
            Math.max(range[1], item.sensorTemperature),
          ], [Infinity, -Infinity])
        : null,
    },
    warnings: [...savedMasterWarnings, ...Object.values(savedDarks).flatMap(master => master.warnings ?? [])],
  };
  summary.blockers = [];
  if (storage.status === "INSUFFICIENT")
    summary.blockers.push(...storageMessages(storage));
  if (storage.status === "LOW_MARGIN")
    summary.warnings.push(...storageMessages(storage));
  if (profile.referenceChecksum && !requestedReferenceChecksum)
    summary.blockers.push("Configured registration reference checksum is missing from selected lights in the reference filter.");
  if (options["skip-quality-measurement"] && !requestedReferenceChecksum)
    summary.blockers.push("Pin an accepted registration reference checksum before skipping measurement.");
  const measureUnreviewed = options["measure-unreviewed"] ||
    options["include-unreviewed"];
  if (summary.unknownQualityFrames && !measureUnreviewed)
    summary.blockers.push(
      "Allow calibration and measured individual review of " +
        summary.unknownQualityFrames +
        " unreviewed lights in setup.",
    );
  if (summary.unknownQualityFrames && options["skip-quality-measurement"])
    summary.blockers.push("Cannot skip measurement while new lights need individual quality review.");
  if (summary.newCalibrationFrames && !options["confirm-optical-train"])
    summary.blockers.push(
      "Confirm the optical train for " +
        summary.newCalibrationFrames +
        " new calibration frames in setup.",
    );
  if (savedMasterWarnings.length && !options["confirm-calibration-identity"])
    summary.blockers.push("Confirm saved-master gain, offset, and temperature identity after reviewing its preparation lineage.");
  const nativeRequirements = {
    drizzle: Boolean(drizzle),
    prepareMasters: Boolean(raw), reuseDark: Object.keys(savedDarks).length > 0,
    darkFlatApproval: Boolean(raw && Object.values(raw.groups.filters).some(group => group.darkFlatExposureApproval)),
    measurement: !options["skip-quality-measurement"],
    localNormalization: profile.integration.normalization === "LOCAL_NORMALIZATION",
  };
  if (options["dry-run"] && options["check-native"]) {
    report("stage", { stage: "Checking PixInsight processes" });
    try {
      if (options["current-instance"]) {
        const current = await connectCurrentInstance(config.bridge, report);
        try { summary.nativeCapabilities = (await current.client.execute("probe_one_run", {})).data; }
        finally { await current.close(); }
      } else summary.nativeCapabilities = await probeNativePreflight(profile.pixInsightExecutable ??
          "/Applications/PixInsight/PixInsight.app/Contents/MacOS/PixInsight");
      summary.blockers.push(...nativeCapabilityBlockers(summary.nativeCapabilities, nativeRequirements));
    } catch (error) { summary.blockers.push("PixInsight process check failed: " + error.message); }
  }
  if (summary.blockers.length) summary.status = "REVIEW_REQUIRED";
  if (options["dry-run"]) {
    if (options.events) report("preflight", summary);
    else console.log(JSON.stringify(summary, null, 2));
    return summary;
  }
  if (summary.unknownQualityFrames && options["skip-quality-measurement"])
    throw new Error("Cannot skip measurement while new lights need individual quality review");
  if (profile.referenceChecksum && !requestedReferenceChecksum)
    throw new Error("Configured registration reference is missing from selected lights");
  if (options["skip-quality-measurement"] && !requestedReferenceChecksum)
    throw new Error("Pin a registration reference before skipping measurement");
  if (storage.status === "INSUFFICIENT")
    throw new Error("Insufficient free space for GenerateMasters:\n" + storageMessages(storage).join("\n"));
  await approveUnknown(
    summary.unknownQualityFrames,
    measureUnreviewed,
  );
  await approveNewCalibration(
    summary.newCalibrationFrames,
    options["confirm-optical-train"],
  );
  await approveLegacyCalibration(savedMasterWarnings,
    options["confirm-calibration-identity"]);
  run.operatorDecisions = {
    unreviewedLightsMeasuredForReview: summary.unknownQualityFrames > 0,
    newCalibrationOpticalTrainConfirmed: summary.newCalibrationFrames > 0,
    legacyCalibrationIdentityConfirmed: savedMasterWarnings.length > 0,
    legacyCalibrationIdentityWarnings: savedMasterWarnings,
    darkFlatExposureApprovals: profile.darkFlatExposureApprovals ?? {},
    filters,
    referenceFilter,
    operator: profile.operator,
    calibrationMode: raw ? "rebuild" : "saved",
  };
  run.bridgePath = config.bridge.path;
  run.receiptDirectory = resolve(config.bridge.path, "results");
  run.report = report;
  if (automatic) await atomicJson(profilePath, JSON.parse(detectedProfileText));
  let client;
  let journalPath = resolve(output, ".piproc-runs", fingerprint + ".json");
  const releaseLock = await acquireRunLock(journalPath);
  let stopBridge = async () => {};
  let closeCurrentInstance = async () => {};
  try {
    const recovered = await loadRecoverableJournal(journalPath, fingerprint);
    const journal = recovered.journal;
    journalPath = recovered.journalPath;
    fingerprint = run.fingerprint = recovered.fingerprint;
    if (recovered.recovery) {
      delete options["quality-decisions"];
      delete options["master-acceptance"];
      report("info", {
        message: "Published masters are missing. Regenerating from the source frames; the previous run record is preserved.",
        resetReviews: true,
        ...recovered.recovery,
      });
    }
    report("info", {
      message: "Run journal",
      journalPath,
      ...(options["current-instance"] ? {} : { logPath: journalPath + ".pixinsight.log" }),
    });
    if (!options["quality-decisions"] && journal.qualityDecisionPath)
      options["quality-decisions"] = journal.qualityDecisionPath;
    if (!options["master-acceptance"] && journal.masterAcceptancePath)
      options["master-acceptance"] = journal.masterAcceptancePath;
    if (journal.status === "SUCCEEDED" || journal.status === "PUBLISHED") {
      const submittedDecisionChecksum = options["quality-decisions"]
        ? await fileChecksum(resolve(options["quality-decisions"])) : null;
      if ((journal.qualityDecisionChecksum ?? null) !== submittedDecisionChecksum)
        throw new Error("Completed run used a different quality decision file; start a new profile revision to change its exact stack");
      const submittedAcceptanceChecksum = options["master-acceptance"]
        ? await fileChecksum(resolve(options["master-acceptance"])) : null;
      if ((journal.masterAcceptanceChecksum ?? null) !== submittedAcceptanceChecksum)
        throw new Error("Completed run used a different master acceptance file");
      if (journal.status === "PUBLISHED") {
        await cleanup(journal, config, fingerprint);
        journal.status = "SUCCEEDED";
        await atomicJson(journalPath, journal);
      }
      if (options.events) report("result", journal.publication);
      else console.log(JSON.stringify(journal.publication, null, 2));
      return journal.publication;
    }
    if (options["current-instance"]) {
      const current = await connectCurrentInstance(config.bridge, report, journalPath);
      client = current.client; closeCurrentInstance = current.close;
      run.receiptDirectory = resolve(current.path, "results");
    } else {
      client = new RealPixInsightClient(config.bridge);
      stopBridge = await ensureBridge(client, config, profile, journalPath);
    }
    const ping = await client.ping();
    if (
      !ping.capabilities.operations.includes("one_run_stage") ||
      !ping.capabilities.operations.includes("probe_one_run")
    )
      throw new Error("Restart the PixInsight bridge from this checkout");
    const capability = (await client.execute("probe_one_run", {})).data;
    if (capability?.version !== ping.capabilities.version)
      throw new Error("PixInsight capability probe version differs from the running bridge");
    const nativeBlockers = nativeCapabilityBlockers(capability, nativeRequirements);
    if (nativeBlockers.length) throw new Error(nativeBlockers.join("; "));
    run.pixInsightVersion = capability.version;
    await atomicJson(journalPath, journal);
    let calibrationMasters = raw
      ? null
      : {
          ...profile.masters,
          darks: Object.fromEntries(
            exposureGroups(profile).map(({ filter, exposureSeconds }) => [
              groupKey(profile, filter, exposureSeconds),
              darkFor(profile, filter, exposureSeconds),
            ]),
          ),
        };
    if (raw) {
      const selectedIndex = new Map(
        raw.selected.map((item, index) => [item.path, index]),
      );
      const remap = (indices) =>
        indices.map((index) => {
          const position = selectedIndex.get(raw.all[index].path);
          if (position === undefined)
            throw new Error("Calibration group escaped selected sources");
          return position;
        });
      const stageGroups = {
        masterDarks: Object.fromEntries(
          Object.entries(raw.groups.masterDarks).map(([exposure, indices]) => [
            exposure,
            remap(indices),
          ]),
        ),
        filters: Object.fromEntries(
          filters.map((filter) => {
            const group = raw.groups.filters[filter];
            return [
              filter,
              {
                exposureSeconds: group.exposureSeconds,
                darkFlatExposureSeconds: group.darkFlatExposureSeconds,
                darkFlatExposureApproval: group.darkFlatExposureApproval,
                lightExposureSeconds: group.lightExposureSeconds,
                flats: remap(group.flats),
                darkFlats: remap(group.darkFlats),
              },
            ];
          }),
        ),
      };
      const prepared = await stage(
        "PREPARE_MASTERS",
        {
          stage: "PREPARE_MASTERS",
          inputs: raw.selected.map((item) => item.path),
          groups: stageGroups,
          savedDarkExposures: Object.keys(savedDarks),
          equipmentHeader: profile.equipment,
          preparationFingerprint: fingerprint,
        },
        "ALIAS",
        run,
        journal,
        journalPath,
        client,
        config,
        options["retry-failed"],
      );
      if (!prepared.masters)
        throw new Error("Master preparation receipt omitted master paths");
      const reference = (path) => {
        const found = prepared.outputs.find((item) => item.path === path);
        if (!found) throw new Error("Prepared master is not verified: " + path);
        return { path, checksum: found.checksum };
      };
      const nativeRegistration = (path) => {
        const verified = reference(path);
        return {
          ...verified,
          nativePath: path,
          nativeChecksum: verified.checksum,
        };
      };
      const darks = Object.fromEntries(
        exposureGroups(profile).map(({ filter, exposureSeconds }) => {
          const exposure = String(exposureSeconds);
          if (savedDarks[exposure])
            return [groupKey(profile, filter, exposureSeconds), savedDarks[exposure]];
          const path = prepared.masters.darks[exposure];
          return [
            groupKey(profile, filter, exposureSeconds),
            nativeRegistration(path),
          ];
        }),
      );
      calibrationMasters = {
        darks,
        flats: Object.fromEntries(
          filters.map((filter) => [
            filter,
            nativeRegistration(prepared.masters.flats[filter]),
          ]),
        ),
        darkFlats: Object.fromEntries(
          filters.map((filter) => [
            filter,
            reference(prepared.masters.darkFlats[filter]),
          ]),
        ),
      };
      await trimPreparationStaging(prepared, config, fingerprint);
    }
    run.masterChecksums = new Map(
      exposureGroups(profile)
        .flatMap(({ filter, exposureSeconds }) => [
          calibrationMasters.darks[groupKey(profile, filter, exposureSeconds)],
          calibrationMasters.flats[filter],
        ])
        .map((item) => [item.nativePath, item.nativeChecksum]),
    );
    const calibrated = [];
    for (const { filter, exposureSeconds } of exposureGroups(profile)) {
      const group = selected.filter(
        (item) =>
          item.filter === filter && item.exposureSeconds === exposureSeconds,
      );
      const result = await stage(
        "CALIBRATE_" + groupKey(profile, filter, exposureSeconds),
        {
          stage: "CALIBRATE",
          inputs: group.map((item) => item.path),
          darkPath:
            calibrationMasters.darks[groupKey(profile, filter, exposureSeconds)]
              .nativePath,
          flatPath: calibrationMasters.flats[filter].nativePath,
        },
        "ALIAS",
        run,
        journal,
        journalPath,
        client,
        config,
        options["retry-failed"],
      );
      calibrated.push(
        ...result.outputs.map((item, index) => ({
          path: item.path,
          source: group[index],
          filter,
          exposureSeconds,
        })),
      );
    }
    run.frameMeasurements = [];
    if (!options["skip-quality-measurement"])
      for (const { filter, exposureSeconds } of exposureGroups(profile)) {
        const group = calibrated.filter((item) => item.filter === filter &&
          item.exposureSeconds === exposureSeconds);
        const measured = await stage(
          "MEASURE_" + groupKey(profile, filter, exposureSeconds),
          { stage: "MEASURE", inputs: group.map((item) => item.path),
            cameraGain: profile.equipment.electronsPerAdu },
          "DIRECT", run, journal, journalPath, client, config,
          options["retry-failed"],
        );
        run.frameMeasurements.push(...measured.measurements.map((record, index) => ({
          sourcePath: group[index].source.path,
          sourceChecksum: group[index].source.checksum,
          filter,
          exposureSeconds,
          metrics: record,
        })));
      }
    run.qualityMeasurementSkipped = Boolean(options["skip-quality-measurement"]);
    run.drizzleRecommendations = drizzleRecommendation(profile, selected, run.frameMeasurements);
    const qualityReview = buildQualityReview(fingerprint, run.frameMeasurements,
      profile.knownApprovedChecksums ?? []);
    const qualityReviewPath = resolve(output, ".piproc-runs",
      fingerprint + ".quality-review.json");
    await atomicJson(qualityReviewPath, qualityReview);
    const qualityReviewChecksum = await fileChecksum(qualityReviewPath);
    run.qualityReviewPath = qualityReviewPath;
    run.qualityReviewChecksum = qualityReviewChecksum;
    journal.qualityReviewPath = qualityReviewPath;
    journal.qualityReviewChecksum = qualityReviewChecksum;
    await atomicJson(journalPath, journal);
    let qualityDecisions = null;
    let qualityDecisionChecksum = null;
    if (qualityReview.pendingChecksums.length) {
      if (!options["quality-decisions"])
        options["quality-decisions"] = await savedQualityDecisionPath(qualityReviewPath, qualityReviewChecksum, journal, profile.operator);
      if (!options["quality-decisions"]) {
        const decisionTemplatePath = resolve(output, ".piproc-runs",
          fingerprint + ".quality-decisions-template.json");
        await atomicJson(decisionTemplatePath, {
          version: 1, kind: "one-run-quality-decisions", fingerprint,
          reviewChecksum: qualityReviewChecksum, operator: profile.operator,
          decisions: qualityReview.frames.filter((frame) => frame.needsDecision)
            .map((frame) => ({ sourceChecksum: frame.sourceChecksum,
              classification: "REVIEW", rationale: "" })),
        });
        const reviewResult = { status: "QUALITY_REVIEW_REQUIRED",
          qualityReviewPath, qualityReviewChecksum, decisionTemplatePath,
          pendingFrames: qualityReview.pendingChecksums.length, operator: profile.operator };
        reviewResult.drizzleRecommendations = run.drizzleRecommendations;
        if (options.events) report("quality-review", reviewResult);
        else console.log(JSON.stringify(reviewResult, null, 2));
        return reviewResult;
      }
      const approved = await readQualityDecisions(
        resolve(options["quality-decisions"]), qualityReview,
        qualityReviewChecksum);
      if (approved.decision.operator !== profile.operator)
        throw new Error("Quality decision operator differs from this run");
      qualityDecisions = approved.decision;
      qualityDecisionChecksum = approved.checksum;
    } else if (options["quality-decisions"])
      throw new Error("This measured run has no frames needing a quality decision file");
    if (journal.qualityDecisionChecksum &&
        journal.qualityDecisionChecksum !== qualityDecisionChecksum)
      throw new Error("Quality decision file changed after native processing began");
    journal.qualityDecisionChecksum = qualityDecisionChecksum;
    journal.qualityDecisionPath = options["quality-decisions"] ? resolve(options["quality-decisions"]) : null;
    await atomicJson(journalPath, journal);
    run.qualityDecisions = qualityDecisions;
    run.qualityDecisionChecksum = qualityDecisionChecksum;
    run.qualityDecisionPath = options["quality-decisions"]
      ? resolve(options["quality-decisions"]) : null;
    const acceptedChecksums = run.qualityMeasurementSkipped
      ? new Set(calibrated.map((item) => item.source.checksum))
      : acceptedQualityChecksums(qualityReview, qualityDecisions);
    const acceptedCalibrated = calibrated.filter((item) =>
      acceptedChecksums.has(item.source.checksum));
    for (const { filter, exposureSeconds } of exposureGroups(profile)) {
      const count = acceptedCalibrated.filter((item) => item.filter === filter &&
        item.exposureSeconds === exposureSeconds).length;
      if (count < 3)
        throw new Error(`Quality decisions leave only ${count} ${filter} ${exposureSeconds}s lights; at least three are required`);
    }
    const { item: reference, selection: referenceSelection } =
      selectMeasuredReference(acceptedCalibrated, run.frameMeasurements,
        referenceFilter, requestedReferenceChecksum);
    run.referenceChecksum = reference.source.checksum;
    run.referenceSelection = referenceSelection;
    const aligned = await stage(
      "ALIGN",
      {
        stage: "ALIGN",
        inputs: acceptedCalibrated.map((item) => item.path),
        referencePath: reference.path,
        ...(drizzle ? { drizzle: true } : {}),
      },
      "DIRECT",
      run,
      journal,
      journalPath,
      client,
      config,
      options["retry-failed"],
    );
    run.registrationReview = alignmentReview(acceptedCalibrated,
      aligned.alignments ?? []);
    const registered = new Map(
      aligned.outputs.map((item) => [item.path, item]),
    );
    run.integratedSources = [];
    run.failedRegistrations = [];
    for (const item of acceptedCalibrated) {
      const name = basename(item.path).replace(/\.[^.]+$/, "") + "_r.xisf";
      const path = resolve(
        config.bridge.path,
        "jobs",
        aligned.id,
        "output",
        name,
      );
      const source = {
        path: item.source.path,
        checksum: item.source.checksum,
        filter: item.filter,
        exposureSeconds: item.exposureSeconds,
      };
      if (registered.has(path)) run.integratedSources.push(source);
      else run.failedRegistrations.push(source);
    }
    const unexpectedFailures = run.failedRegistrations.filter((item) =>
      profile.knownApprovedChecksums?.includes(item.checksum),
    );
    if (unexpectedFailures.length)
      throw new Error(
        `${unexpectedFailures.length} previously approved frame(s) failed registration; inspect stage ${aligned.id}`,
      );
    run.integrationStacks = {};
    const drizzlePhases = [];
    for (const { filter, exposureSeconds } of exposureGroups(profile)) {
      const key = groupKey(profile, filter, exposureSeconds);
      const group = acceptedCalibrated.filter((item) =>
        item.filter === filter && item.exposureSeconds === exposureSeconds);
      const inputs = acceptedCalibrated
        .filter(
          (item) =>
            item.filter === filter && item.exposureSeconds === exposureSeconds,
        )
        .map((item) => {
          const name = basename(item.path).replace(/\.[^.]+$/, "") + "_r.xisf";
          return resolve(
            config.bridge.path,
            "jobs",
            aligned.id,
            "output",
            name,
          );
        })
        .filter((path) => registered.has(path));
      if (inputs.length < 3)
        throw new Error(
          `Only ${inputs.length} ${filter} ${exposureSeconds}s registered lights`,
        );
      run.integrationStacks[key] = group.filter((item) => {
        const name = basename(item.path).replace(/\.[^.]+$/, "") + "_r.xisf";
        return registered.has(resolve(config.bridge.path, "jobs", aligned.id,
          "output", name));
      }).map((item) => ({ path: item.source.path,
        checksum: item.source.checksum }));
      let normalizationDataPaths = [];
      if (profile.integration.normalization === "LOCAL_NORMALIZATION") {
        const normalized = await stage(
          "NORMALIZE_" + key,
          { stage: "NORMALIZE", inputs,
            referencePath: inputs[0],
            scale: profile.integration.localNormalizationScale ?? 512 },
          "DIRECT", run, journal, journalPath, client, config,
          options["retry-failed"],
        );
        normalizationDataPaths = normalized.outputs.map((item) => item.path);
      }
      const drizzleDataPaths = drizzle ? inputs.map(path => {
        const record = aligned.drizzleData?.find(item => item.targetPath === path);
        if (!record) throw new Error("Missing verified alignment data for drizzle: " + path);
        const source = acceptedCalibrated.find(item => item.path === record.sourcePath)?.source;
        if (!source) throw new Error("Missing drizzle source identity");
        drizzlePhases.push({ sourceChecksum: source.checksum, phase: record.phase });
        return record.path;
      }) : [];
      const integrated = await stage(
        "INTEGRATE_" + key,
        {
          stage: "INTEGRATE",
          inputs,
          normalization: profile.integration.normalization,
          weighting: profile.integration.weighting,
          rejection: profile.integration.rejection,
          sigmaLow: profile.integration.sigmaLow,
          sigmaHigh: profile.integration.sigmaHigh,
          normalizationDataPaths,
          ...(drizzle ? { drizzleDataPaths } : {}),
        },
        "DIRECT",
        run,
        journal,
        journalPath,
        client,
        config,
        options["retry-failed"],
      );
      if (drizzle) {
        const drizzled = await stage("DRIZZLE_" + key,
          { stage: "DRIZZLE", inputs: integrated.drizzleData.map(item => item.path),
            scale: drizzle.scale, dropShrink: drizzle.dropShrink },
          "DIRECT", run, journal, journalPath, client, config, options["retry-failed"]);
        if (drizzled.statistics.totalRejectedLow !== integrated.statistics.totalRejectedLow ||
            drizzled.statistics.totalRejectedHigh !== integrated.statistics.totalRejectedHigh)
          throw new Error("Drizzle did not retain the conventional integration's pixel rejection counts");
      }
    }
    run.drizzleRecommendations = drizzleRecommendation(profile,
      selected.filter(item => run.integratedSources.some(source => source.checksum === item.checksum)),
      run.frameMeasurements, drizzlePhases);
    await verifySources(
      [...candidates, ...(raw?.selected ?? [])],
      savedMasters,
    );
    const masterReview = buildMasterReview(run, journal, profile);
    const masterReviewPath = resolve(output, ".piproc-runs",
      fingerprint + ".master-review.json");
    await atomicJson(masterReviewPath, masterReview);
    const masterReviewChecksum = await fileChecksum(masterReviewPath);
    run.masterReviewPath = masterReviewPath;
    run.masterReviewChecksum = masterReviewChecksum;
    journal.masterReviewPath = masterReviewPath;
    journal.masterReviewChecksum = masterReviewChecksum;
    await atomicJson(journalPath, journal);
    if (!options["master-acceptance"])
      options["master-acceptance"] = await savedMasterAcceptancePath(masterReviewPath, masterReviewChecksum, journal);
    if (!options["master-acceptance"]) {
      const acceptanceTemplatePath = resolve(output, ".piproc-runs",
        fingerprint + ".master-acceptance-template.json");
      await atomicJson(acceptanceTemplatePath, { version: 1,
        kind: "one-run-master-acceptance", fingerprint,
        reviewChecksum: masterReviewChecksum, operator: profile.operator,
        decision: "REVIEW", rationale: "" });
      const result = { status: "MASTER_REVIEW_REQUIRED", masterReviewPath,
        masterReviewChecksum, acceptanceTemplatePath,
        groups: masterReview.groups.length, operator: profile.operator,
        drizzleRecommendations: run.drizzleRecommendations,
        registrationFlags: masterReview.registrationReview.filter((row) =>
          row.flags.length).length };
      if (options.events) report("master-review", result);
      else console.log(JSON.stringify(result, null, 2));
      return result;
    }
    const acceptancePath = resolve(options["master-acceptance"]);
    const accepted = await readMasterAcceptance(acceptancePath,
      masterReview, masterReviewChecksum);
    if (accepted.decision.operator !== profile.operator)
      throw new Error("Master acceptance operator differs from this run");
    if (journal.masterAcceptanceChecksum &&
        journal.masterAcceptanceChecksum !== accepted.checksum)
      throw new Error("Master acceptance changed after publication began");
    journal.masterAcceptanceChecksum = accepted.checksum;
    journal.masterAcceptancePath = acceptancePath;
    await atomicJson(journalPath, journal);
    run.masterAcceptancePath = acceptancePath;
    run.masterAcceptanceChecksum = accepted.checksum;
    run.masterAcceptance = accepted.decision;
    report("stage", { stage: "Publication" });
    const publication = await publish(
      run,
      journal,
      profile,
      selected,
      calibrationMasters,
      raw,
      output,
    );
    for (const item of publication.files)
      await verifyChecksum(item.path, item.checksum);
    journal.status = "PUBLISHED";
    journal.publication = publication;
    await atomicJson(journalPath, journal);
    await cleanup(journal, config, fingerprint);
    journal.status = "SUCCEEDED";
    await atomicJson(journalPath, journal);
    if (options.events) report("result", publication);
    else console.log(JSON.stringify(publication, null, 2));
    return publication;
  } finally {
    try {
      await stopBridge();
    } finally {
      try { await closeCurrentInstance(); }
      finally { await releaseLock(); }
    }
  }
}

if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
)
  main().catch((error) => {
    const message = error instanceof Error ? error.message : String(error);
    eventReporter(process.argv.includes("--events"))("error", { message });
    console.error(message);
    process.exitCode = 1;
  });
