export function assertSupportedNodeVersion(version = process.versions.node) {
  const match = /^24\.(\d+)\.(\d+)$/.exec(String(version));
  if (!match || Number(match[1]) < 22 ||
      (Number(match[1]) === 22 && Number(match[2]) < 3))
    throw new Error("GenerateMasters requires Node.js 24.22.3 or a newer Node 24 patch");
}
