// Minimum patched Node 24 runtime supported by GenerateMasters.
function gmNodeSupportedVersion(version) {
   var match = /^v24\.(\d+)\.(\d+)$/.exec(String(version).trim());
   return match !== null && (Number(match[1]) > 22 ||
      (Number(match[1]) === 22 && Number(match[2]) >= 3));
}
